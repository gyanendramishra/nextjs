import React from "react";
import axios from "axios";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { EInternationalLables } from "../../utils";
import { TTranslation, TCLocation, TCategory } from "../../types";
import { forRentLocations, forSaleLocations, internationalLocations } from "../../services";


/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    propertyFor: string;
    categories : TCategory[];
    translation: TTranslation;   
}

interface States {
    activeKSACategory: number;
    activeInternationalCategory: string;
    ksaCategoryLocations: TCLocation[];
    internationalCategoryLocations: TCLocation[];
}

class LocationSearch extends React.Component<Props, States>  {

    /**
     * New component instance
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            activeKSACategory : 0,
            activeInternationalCategory : EInternationalLables.HIGH_INVESTMENT_RETURN,
            ksaCategoryLocations: [],
            internationalCategoryLocations: [],
        }
    }

    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Swith the KSA search category
     * @return void
     */
    switchKSACategory = async (category: number) => {
        const { propertyFor, translation } = this.props;
        this.setState({
            ...this.state,
            activeKSACategory: category,
            ksaCategoryLocations: []
        });
        if(propertyFor === "sale"){
            this.getForRentLocations(translation.language, category);
        }else{
            this.getForSaleLocations(translation.language, category);
        }
    }

    /**
     * Swith the international category
     * @return void
     */
    switchInternationalCategory = async (category: string) => {
        const { translation } = this.props;
        this.setState({
            ...this.state,
            activeInternationalCategory: category,
            internationalCategoryLocations: []
        });
        const result = await internationalLocations(translation.language, category);
        if(result.status === true){
            this.setState({
                ...this.state,
                activeInternationalCategory:category,
                "internationalCategoryLocations": result.data
            });
        }else{
            console.error(result.message);
        }
        
    }

    /**
     * Get the locations of the category
     * @return
     */
    getForRentLocations = async (locale: string, category: number) => {
        const result = await forSaleLocations(locale, category);
        if(result.status === true){
            this.setState({ ksaCategoryLocations: result.data });
        }else{
            console.error(result.message);
        }
    }

    /**
     * Get the locations of the category
     * @return
     */
    getForSaleLocations = async (locale: string, category: number) => {
        const result = await forSaleLocations(locale, category);
        if(result.status === true){
            this.setState({ 
                ...this.state,
                activeKSACategory:category,
                ksaCategoryLocations: result.data 
            });
        }else{
            console.error(result.message);
        }
    }

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = () => {
        const { categories } = this.props;
        if(Object.keys(categories).length){
            let categoryId = categories[0].id;
            this.switchKSACategory(categoryId);
        }
    }
    /**
     * Render the html in dom
     */
    render() {
        const { categories, propertyFor } = this.props;
        const { activeKSACategory, activeInternationalCategory, internationalCategoryLocations, ksaCategoryLocations} = this.state;

        let locationComponent;
        if (propertyFor === "international") {
            locationComponent = (
                <div className={styles.advance_search_block}>
                    <div className={`${styles.custom_tab}`}>
                        <ul className={styles.prop_tab}>
                            <li>
                                <a 
                                    className={`${(activeInternationalCategory === EInternationalLables.HIGH_INVESTMENT_RETURN) ? styles.active : ""}`} 
                                    onClick={() => this.switchInternationalCategory(EInternationalLables.HIGH_INVESTMENT_RETURN)}
                                >
                                    High Investment Return
                                </a>
                            </li>
                            <li>
                                <a 
                                    className={`${(activeInternationalCategory === EInternationalLables.GREAT_PRICE) ? styles.active : ""}`} 
                                    onClick={() => this.switchInternationalCategory(EInternationalLables.GREAT_PRICE)}
                                >
                                    Great Price
                                </a>
                            </li>
                            <li>
                                <a 
                                    className={`${(activeInternationalCategory === EInternationalLables.FEATURED) ? styles.active : ""}`} 
                                    onClick={() => this.switchInternationalCategory(EInternationalLables.FEATURED)}
                                >
                                    Featured
                                </a>
                            </li>     
                        </ul>
                        {internationalCategoryLocations &&
                            <div className={`${styles.tab_content}`}>
                                <ul className={styles.link2}>
                                    {internationalCategoryLocations.map((location:TCLocation, index:number) => {
                                        return (
                                            <li key={index}>
                                                <a href="#">{location.name}</a>
                                            </li>
                                        )
                                    })}
                                </ul>
                                <div className={styles.all_properties}>
                                    <a href="#">View all properties</a>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            );
        }else if(Object.keys(categories).length){
            locationComponent = (
                <div className={styles.advance_search_block}>
                    <div className={`${styles.custom_tab}`}>
                        <ul className={styles.prop_tab}>
                            { categories.map((category, index)=>{
                                return (
                                    <li key={index}>
                                        <a className={`${(activeKSACategory == category.id) ? styles.active : ''}`} onClick={() => this.switchKSACategory(category.id)}>
                                            {category.name}
                                        </a>
                                    </li>
                                )
                            })}
                        </ul>
                        {ksaCategoryLocations &&
                            <div className={`${styles.tab_content}`}>
                                <ul className={styles.link2}>
                                    {ksaCategoryLocations.map((location:TCLocation, index:number) => {
                                        return (
                                            <li key={index}>
                                                <a href="#">{location.name}</a>
                                            </li>
                                        )
                                    })}
                                </ul>
                                <div className={styles.all_properties}>
                                    <a href="#">View all properties</a>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            );
        }
        return (
            <>
                { locationComponent }
            </>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("main-search")(LocationSearch))