import App from "next/app";
import NProgress from "nprogress";
import { wrapper } from "../stores";
import { Router } from "next/router";
import { appWithTranslation } from "../i18n";
import type { AppProps, AppContext } from "next/app";

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/theme.scss";

function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}



MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

if (typeof window !== "undefined") {
  
  NProgress.configure({ showSpinner: true });

  Router.events.on("routeChangeStart", () => {
    NProgress.start();
  });

  Router.events.on("routeChangeComplete", () => {
    NProgress.done();
  });

  Router.events.on("routeChangeError", () => {
    NProgress.done();
  });
}

//export default appWithTranslation(MyApp);
export default wrapper.withRedux(appWithTranslation(MyApp));
