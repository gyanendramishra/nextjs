import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useTranslation } from 'react-i18next';

/**
 * component styles
 */
import styles from '../../../styles/shared/header.module.scss';

const PageHeader = () => {
    const { t, i18n } = useTranslation();
    const router = useRouter();
    const { locale } = router;
    const { language } = i18n;

    const headerNavRef:React.RefObject<HTMLDivElement> = React.createRef();

    /**
     * Switch language
     * @return void
     */

    const switchLocale = async () => {
        const lang = (language === "en") ? "ar" : "en";
        await i18n.changeLanguage(lang);
        router.push(router.asPath, undefined, { locale: lang });
    }

    /**
     * Open the side nav
     * @return void
     */
    const openSideNav = ():void => {
        if(headerNavRef.current){
            headerNavRef.current.classList.add(styles.nav_open);
        }
    }

    /**
     * Close the side nav
     * @return void
     */
    const closeSideNav = ():void => {
        if(headerNavRef.current){
            headerNavRef.current.classList.remove(styles.nav_open);
        }
    }

    /**
     * Toggle sub nav's
     * @return void
     */
    const toggleSubNav = (event:React.MouseEvent<HTMLLIElement, MouseEvent>):void => {
        
        if(headerNavRef.current){
            if(headerNavRef.current.classList.contains(styles.nav_open)){
                const elements = event.currentTarget.getElementsByClassName(styles.sub_nav_outer);
                if(elements.length){
                    if(elements[0].hasAttribute('style')){
                        elements[0].removeAttribute('style')
                    }else{
                        elements[0].style.display = "block";
                    }
                }
            }
        }
        
    }

    /**
     * Render the html
     * @return void
     */
    return (
        <header className={styles.header}>
            <div className={styles.container}>
                <div className={styles.hdr_btm_inr}>
                    <Link href={ `/${locale as string}` }>
                        <a className={styles.logo}>
                            <img src="/images/logo.svg" alt=""/>
                        </a>
                    </Link>
                    <a className={`${styles.menu_button}`} onClick={ openSideNav }>
                        <img src="/images/berger-menu.svg" alt=""/>
                    </a>
                    <div className={styles.menu} ref={ headerNavRef }>
                        <div className={styles.mobile_scroll}>
                            <ul className={styles.nav1}>
                                <li className={styles.sub_nav} onClick={ (event)=> toggleSubNav(event) }>
                                    <a href="#">{ t("MAIN_NAVIGATIONS.FOR_SALE.LABEL") }</a>
                                    <div className={styles.sub_nav_outer}>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.RIYADH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.JEDDAH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MEDINA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.DAMMAM") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MECCA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_KHOBAR") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TABUK") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.YANBU") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TAIF") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_JUBAIL") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.ABHA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.NAJRAN") }
                                                </a>
                                            </li>
                                        </ul>
                                        <a className={styles.all_link} href="#">
                                            { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                        </a>
                                    </div>
                                </li>
                                <li className={styles.sub_nav} onClick={ (event)=> toggleSubNav(event) }>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.FOR_RENT.LABEL") }
                                    </a>
                                    <div className={styles.sub_nav_outer}>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.RIYADH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.JEDDAH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MEDINA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.DAMMAM") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MECCA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_KHOBAR") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TABUK") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.YANBU") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TAIF") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_JUBAIL") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.ABHA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.NAJRAN") }
                                                </a>
                                            </li>
                                        </ul>
                                        <a className={styles.all_link} href="#">
                                            { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                        </a>
                                    </div>
                                </li>
                                <li className={styles.sub_nav} onClick={ (event)=> toggleSubNav(event) }>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.LABEL") }
                                    </a>
                                    <div className={styles.sub_nav_outer}>
                                        <div className={styles.nav_hd}>
                                            { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.LABEL") }
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.OPTIONS.HIGH_INVESTMENT_RETURN") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.OPTIONS.GREAT_PRICE") }
                                                </a>
                                            </li>
                                        </ul>
                                        <div className={styles.nav_hd}>
                                            { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.LABEL") }
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.BOSINA_AND_HERZEGOVINA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.UNITED_ARAB_AMIRATES") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.MALTA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.UNITED_KINGDOM") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.MONACO") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.SWITZERLAND") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.CYPRUS") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.FRANCE") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.SPAIN") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.GREECE") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.ITALY") }
                                                </a>
                                            </li>
                                        </ul>
                                        <a className={styles.all_link} href="#">
                                            { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                        </a>
                                    </div>
                                </li>
                                <li className={styles.sub_nav}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.SERVICES.LABEL") }
                                    </a>
                                </li>
                                <li className={styles.sub_nav}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.EXPERIENCE.LABEL") }
                                    </a>
                                </li>
                            </ul>
                            <ul className={styles.nav2}>
                                <li className={styles.setting}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.RIGHT_NAVIGATIONS.SETTING") }
                                    </a>
                                </li>
                                <li className={styles.saved}>
                                    <a href="#"> 
                                        { t("MAIN_NAVIGATIONS.RIGHT_NAVIGATIONS.SAVED") }
                                        <i className="icon-heart"></i>
                                    </a>
                                </li>
                                <li className={styles.name}>
                                    <a onClick={ switchLocale }>
                                        { t("MAIN_NAVIGATIONS.RIGHT_NAVIGATIONS.LANGUAGE") }
                                    </a>
                                </li>
                                <li className={styles.sign_btn}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.RIGHT_NAVIGATIONS.LOGIN") }
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a className={`${styles.button_line} ${styles.button_line_mobile}`} href="#">
                            { t("MAIN_NAVIGATIONS.LIST_YOUR_PROPERTY.LABEL") }
                        </a>
                        <a className={styles.button_close} onClick={ closeSideNav }>
                            <img src="/images/close.svg" alt=""/>
                        </a>
                        <div className={styles.app_download_btn_mobile}>
                            <a href="#">
                                <img src="/images/app-store.svg" alt=""/>
                            </a>
                            <a href="#">
                                <img src="/images/google-pay.svg" alt=""/>
                            </a>
                        </div>
                    </div>
                    <a className={styles.button_line} href="#">
                        { t("MAIN_NAVIGATIONS.LIST_YOUR_PROPERTY.LABEL") }
                    </a>
                </div>
            </div>
        </header>
    );
}

export default PageHeader;
