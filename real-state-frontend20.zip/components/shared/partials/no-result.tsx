import React from "react";
import { useTranslation } from 'react-i18next';

/**
 * Import styles
 */
import styles from '../../../styles/shared/no-result.module.scss';

const NoResult = () => {

    const { t } = useTranslation();

    return (
        <div className={styles.no_record_found}>
            <h1>{ t("NO_RESULT.LABELS.OOPS") }</h1>
            <h2>{ t("NO_RESULT.LABELS.NO_DATA_FOUND") }</h2>
            <div className={styles.not_found_img}>
                <img src="/images/not-found.jpg" alt=""/>
            </div>
        </div>
    );
}
export default NoResult;
