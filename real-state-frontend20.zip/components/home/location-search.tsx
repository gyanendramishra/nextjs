import React, { useState } from "react";
import { useTranslation } from 'react-i18next';

/**
 * Import services, types and utils
 */
import { TCLocation, TCategory } from "../../types";
import { EInternationalLables, EPropertyFor } from "../../utils";
import { forRentLocations, forSaleLocations, internationalLocations } from "../../services";


type TProps = {
    propertyFor: string;
    categories : TCategory[];
    styles: TStyle;
};

type TStyle = {
    readonly [key: string]: string;
};

type TActiveCalegory = {
    id: number,
    name: string,
}

const LocationSearch = (props:TProps) => {
    const { propertyFor, styles, categories } = props;
    const { t, i18n } = useTranslation();
    const { language } = i18n;

    const [activeKSACategory, setActiveKSACategory] = useState<TActiveCalegory>({
        id: 0,
        name: "",
    });
    const [activeInternationalCategory, setActiveInternationalCategory] = useState<string>(EInternationalLables.HIGH_INVESTMENT_RETURN);
    const [ksaCategoryLocations, setKSACategoryLocation] = useState<Array<TCLocation>>([]);
    const [internationalCategoryLocations, setInternationalCategoryLocation] = useState<Array<TCLocation>>([]);

    /**
     * Trigger react lifecycle hook
     */
    React.useEffect(() => {
        if(Object.keys(categories).length){
            switchKSACategory(categories[0]);
        }
    }, [categories]);

    /**
     * Swith the KSA search category
     * @return void
     */
    const switchKSACategory = async (category: TActiveCalegory) => {
        setActiveKSACategory((prevState) => {
            prevState.id = category.id;
            prevState.name = category.name;
            return({
              ...prevState
            })
          }
        );
        try{
            if(propertyFor === EPropertyFor.RENT){
                getForRentLocations(language, category.id);
            }else{
                getForSaleLocations(language, category.id);
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Swith the international category
     * @return void
     */
    const switchInternationalCategory = async (category: string) => {

        setActiveInternationalCategory(category);
        setInternationalCategoryLocation([]);
        try{
            const result = await internationalLocations(language, category);
            if(result.status === true){
                setActiveInternationalCategory(category);
                setInternationalCategoryLocation(result.data);
            }else{
                console.error(result.message);
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Get the locations of the category
     * @return
     */
    const getForRentLocations = async (locale: string, category: number) => {
        try{
            const result = await forRentLocations(locale, category);
            if(result.status === true){
                setKSACategoryLocation(result.data);
            }else{
                console.error(result.message);
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Get the locations of the category
     * @return
     */
    const getForSaleLocations = async (locale: string, category: number) => {
        try{
            const result = await forSaleLocations(locale, category);
            if(result.status === true){
                setKSACategoryLocation(result.data);
            }else{
                console.error(result.message);
            }
        }catch(error){
            console.log(error);
        }
    }

    let locationComponent;

    if (propertyFor === EPropertyFor.INTERNATIONL) {
        locationComponent = (
            <div className={styles.advance_search_block}>
                <div className={`${styles.custom_tab}`}>
                    <ul className={styles.prop_tab}>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.HIGH_INVESTMENT_RETURN) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.HIGH_INVESTMENT_RETURN)}
                            >
                                {t("MAIN_SEARCH.LABELS.HIGH_INVESTMENT_RETURN")}
                            </a>
                        </li>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.GREAT_PRICE) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.GREAT_PRICE)}
                            >
                                {t("MAIN_SEARCH.LABELS.GREAT_PRICE")}
                            </a>
                        </li>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.FEATURED) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.FEATURED)}
                            >
                                {t("MAIN_SEARCH.LABELS.FEATURED")}
                            </a>
                        </li>     
                    </ul>
                    {internationalCategoryLocations &&
                        <div className={`${styles.tab_content}`}>
                            <ul className={styles.link2}>
                                {internationalCategoryLocations.map((location:TCLocation, index:number) => {
                                    return (
                                        <li key={index}>
                                            <a href="#">{location.name}</a>
                                        </li>
                                    )
                                })}
                            </ul>
                            <div className={styles.all_properties}>
                                <a href="#">{ t("MAIN_SEARCH.LABELS.VIEW_ALL_PROPERTIES") }</a>
                            </div>
                        </div>
                    }
                </div>
            </div>
        );
    }else if(Object.keys(categories).length){
        locationComponent = (
            <div className={styles.advance_search_block}>
                <div className={`${styles.custom_tab}`}>
                    <ul className={styles.prop_tab}>
                        { categories.map((category, index)=>{
                            return (
                                <li key={index}>
                                    <a className={`${(activeKSACategory.id === category.id) ? styles.active : ''}`} onClick={() => switchKSACategory(category)}>
                                        {category.name}
                                    </a>
                                </li>
                            )
                        })}
                    </ul>
                    {ksaCategoryLocations &&
                        <div className={`${styles.tab_content}`}>
                            <ul className={styles.link2}>
                                {ksaCategoryLocations.map((location:TCLocation, index:number) => {
                                    return (
                                        <li key={index}>
                                            <a href="#">
                                                {activeKSACategory.name} {(propertyFor == EPropertyFor.RENT) ? t("MAIN_SEARCH.AREA_FILTER_LABLE.FOR_RENT_IN") : t("MAIN_SEARCH.AREA_FILTER_LABLE.FOR_SALE_IN") } {location.name}
                                            </a>
                                        </li>
                                    )
                                })}
                            </ul>
                            <div className={styles.all_properties}>
                                <a href="#">{ t("MAIN_SEARCH.LABELS.VIEW_ALL_PROPERTIES") }</a>
                            </div>
                        </div>
                    }
                </div>
            </div>
        );
    }
    return (
        <>
            { locationComponent }
        </>
    );
};


export default LocationSearch;