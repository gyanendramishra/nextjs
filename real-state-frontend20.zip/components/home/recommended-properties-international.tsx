import React, { useState} from "react";
import { useTranslation } from 'react-i18next';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Navigation, Scrollbar } from 'swiper';

SwiperCore.use([Navigation, Pagination, Scrollbar]);

/**
 * Import components
 */
import PropertyGridItem from "@/components/property/item-grid";
import FrameModal from "@/components/shared/elements/frame-modal";

/**
 * import clases, services types and utills
 */
import { TPSource } from '../../types';
import { Property } from '../../classes/property';

/**
 * component styles
 */
import styles from '../../styles/home/recommended-properties-international.module.scss';

type TProps = {
    properties : Array<TPSource>;
};

type TModal = {
    opened: boolean;
    title?: string;
    src?: string;
}

const RecommendedPropertiesInternational = (props: TProps) => {

    const { t, i18n } = useTranslation();
    const { language } = i18n;
    const { properties } = props;

    const [modal, setModal] = useState<TModal>({
        opened: false,
        title: "",
        src: ""
    });

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const populateVideo = (src: string): void => {
        setModal((prevState) => {
            prevState.opened = true;
            prevState.title = t("RECOMMENDED_PROPERTY.VIDEO_MODAL_TITLE");
            prevState.src = src;
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Handle modal on close
     * @param src: string
     * @return void
     */
    const handleModelClose = (): void => {
        setModal((prevState) => {
            prevState.opened = false;
            prevState.title = "";
            prevState.src = "";
            return({
              ...prevState
            })
          }
        );
    }


    /**
     * Render the template
     * 
     * @return mix html
     */

    return (
        <>
            { properties &&
                <div className={styles.home_section1}>
                    <div className={styles.container}>
                        <h2 className="text-center">{ t("RECOMMENDED_PROPERTY.TITLE_INTERNATIONAL") }</h2>
                        <Swiper
                            className="swipper_slider"
                            pagination
                            breakpoints={{
                                767: {
                                
                                    slidesPerView: 1,
                                    navigation: true,
                                    scrollbar: { 
                                        draggable: true, 
                                        hide: true 
                                    },
                                    pagination: true
                                },
                    
                                768: {
                                
                                    slidesPerView: 3,
                                    navigation: false,
                                    scrollbar: {
                                        draggable: false,
                                        hide: true 
                                    },
                                    pagination: false
                                },
                            }}
                        >
                            {properties.map((property:TPSource, index:number) => {
                                const rProperty = new Property(property, language);
                                return (
                                    <SwiperSlide className="swipper_item" key={index}>
                                        <PropertyGridItem
                                            property={rProperty}
                                            handleVideo={ populateVideo }
                                        ></PropertyGridItem>
                                    </SwiperSlide>
                                )
                            })}
                        </Swiper>
                    </div>
                    <FrameModal 
                        title={ modal.title }
                        opened={ modal.opened }
                        src={ modal.src }
                        onModalClose = { handleModelClose }
                    ></FrameModal>
                </div>
            }
        </>
    );
}

export default RecommendedPropertiesInternational
