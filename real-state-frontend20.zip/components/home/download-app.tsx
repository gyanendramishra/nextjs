import React from "react";
import { useTranslation } from 'react-i18next';

import styles from '../../styles/home/download-app.module.scss';


const  DownloadApp = () => {

    const { t } = useTranslation();
  
    return (
        <div className={styles.property_servies}>
            <div className={styles.container}>
                <div className={styles.app_download_block}>
                    <div className={styles.app_block1}>
                        <img src="/images/phone-banner.svg" alt=""/>
                    </div>
                    <div className={styles.app_block2}>
                        <h2>{ t("DOWNLOAD_APP.TITLE")}</h2>
                        <p>{ t("DOWNLOAD_APP.SUB_TITLE")}<br></br> { t("DOWNLOAD_APP.TAGLINE")}</p>
                    </div>
                    <div className={styles.app_block3}>
                        <a href="#"><img src="/images/app-store.svg" alt=""/></a>
                        <a href="#"><img src="/images/google-pay.svg" alt=""/></a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default DownloadApp;
