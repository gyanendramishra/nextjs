import React from "react";
import { useTranslation } from 'react-i18next';

/**
 * Import utill, classes, types and etc
 */
import { TCLocation } from "types";

/**
 * Import styles
 */
import styles from '../../styles/listing/property-area.module.scss';


type TProps = {
  areas:Array<TCLocation>;
}

const PropertyArea = (props: TProps) => {
    const { areas } = props;
    const { t } = useTranslation();
    /**
     * Render the html
     */
    return (
        <>
            {areas && (areas.length > 0) && (
                <div className={styles.property_area}>
                    <div className={styles.container}>
                        <div className={styles.area_inr}>
                            <ul>
                                { areas.map((area, index)=>{
                                    return (
                                        <li key={index}>
                                            <a href="#">{ area.name }</a>
                                        </li>
                                    )}
                                )}
                            </ul>
                            { (areas.length > 5) &&
                                <div className={styles.area_rt_btn}>
                                    <a href="#">
                                        { t("MAIN_SEARCH.LABELS.VIEW_ALL") } 
                                        <img src="/images/arrow2.svg" alt=""/>
                                    </a>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            )}
        </>
     );
}

export default PropertyArea;
