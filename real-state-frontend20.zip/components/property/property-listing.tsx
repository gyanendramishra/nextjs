import React, { useState } from "react";
import { useTranslation } from 'react-i18next';

/**
 * Import page components
 */
import Pagination from "@/components/property/pagination";
import NoResult from "@/components/shared/partials/no-result";
import PropertyGridItem from "@/components/property/item-grid";
import PropertyListItem from "@/components/property/item-list";
import FrameModal from "@/components/shared/elements/frame-modal";
import PropertySortFilter from "@/components/property/property-sort-filter";

/**
 * Import utill, classes, types and etc
 */
import { TPSource } from "types";
import { EPropertyDisplayMode } from "utils";
import { Property } from '../../classes/property';

/**
 * Import styles
 */
import styles from '../../styles/listing/property-listing-main.module.scss';

type TProps = {
    searchFor: string;
    proprtyDisplayMode: string;
    totalResult: number;
    properties : Array<TPSource>;
    handlePagination: Function;
    handleSorting: Function;
    switchPropertyDisplayMode: Function;
}

type TModal = {
  opened: boolean;
  title?: string;
  src?: string;
}

const PropertyListing = (props: TProps) => {
    const { 
        searchFor, 
        totalResult, 
        properties, 
        proprtyDisplayMode,
        handlePagination,
        handleSorting,
        switchPropertyDisplayMode 
    } = props;
    const { t, i18n } = useTranslation();
    const { language } = i18n;

    const [modal, setModal] = useState<TModal>({
        opened: false,
        title: "",
        src: ""
    });

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const populateVideo = (src: string): void => {
        setModal((prevState) => {
            prevState.opened = true;
            prevState.title = t("RECOMMENDED_PROPERTY.VIDEO_MODAL_TITLE");
            prevState.src = src;
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Handle modal on close
     * @param src: string
     * @return void
     */
    const handleModelClose = (): void => {
        setModal((prevState) => {
            prevState.opened = false;
            prevState.title = "";
            prevState.src = "";
            return({
              ...prevState
            })
          }
        );
    }

    let cardComponent;

    if(properties.length) {
        if(proprtyDisplayMode === EPropertyDisplayMode.LIST){
            cardComponent = (
                <>
                    <div className={`${styles.grid_view} ${styles.dis_block}`}>
                        <div className="row">
                                {properties.map((property:TPSource, index:number) => {
                                let rProperty = new Property(property, language);
                                return (
                                    <div className="col-md-12" key={index}>
                                        <PropertyListItem
                                            property={ rProperty }
                                            handleVideo={ populateVideo }
                                        ></PropertyListItem>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                    <Pagination
                        totalResult= { totalResult }
                        handlePagination= { handlePagination }
                    ></Pagination>
                </>
            )
        }else{
            cardComponent = (
                <>
                    <div className={`${styles.grid_view} ${styles.dis_block}`}>
                        <div className="row">
                                {properties.map((property:TPSource, index:number) => {
                                let rProperty = new Property(property, language);
                                return (
                                    <div className="col-xl-4 col-md-6" key={index}>
                                        <PropertyGridItem
                                            property={ rProperty }
                                            handleVideo={ populateVideo }
                                        ></PropertyGridItem>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                    <Pagination
                        totalResult= { totalResult }
                        handlePagination= { handlePagination }
                    ></Pagination>
                </>
            )
        }
        
    }else{
        cardComponent = (<NoResult></NoResult>);
    }
    
    return (
        <>
            <div className={styles.property_listing_main}>
                <div className={styles.container}>
                    <div className="row">
                        <div className="col-md-9">
                            <div className={styles.property_sort_filter}>
                                <PropertySortFilter
                                    searchFor = { searchFor }
                                    proprtyDisplayMode= {proprtyDisplayMode}
                                    totalResult = { totalResult }
                                    handleSorting= { handleSorting}
                                    switchPropertyDisplayMode= { switchPropertyDisplayMode }
                                ></PropertySortFilter>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-9">
                            { cardComponent }
                        </div>
                        <div className="col-md-3">
                            <div className={styles.ad_block1}>
                                <a href="#">
                                    <img src="/images/Add1.svg" alt=""/>
                                </a>
                            </div>
                            <div className={styles.ad_block2}>
                                <a href="#">
                                    <img src="/images/Add2.svg" alt=""/>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <FrameModal 
                title={ modal.title }
                opened={ modal.opened }
                src={ modal.src }
                onModalClose = { handleModelClose}
            ></FrameModal>
        </>
    )
}

  export default PropertyListing;
