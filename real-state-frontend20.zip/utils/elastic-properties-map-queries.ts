/**
 * Elastic query body for getting search properties on map
 */
export const EQSearchPropertyList = {
  from: 0,
  size: 3,
  _source: [
    "id",
    "slug",
    "en.title",
    "en.country",
    "en.zone",
    "en.city",
    "en.unitType",
    "en.currencyType",
    "en.propertyMainType",
    "ar.title",
    "ar.country",
    "ar.zone",
    "ar.city",
    "ar.unitType",
    "ar.currencyType",
    "ar.propertyMainType",
    "attribute.noOfBedrooms",
    "attribute.noOfBathrooms",
    "attribute.builtUpArea",
    "attribute.salePrice",
    "propertyOwner.phone",
    "propertyOwner.email",
    "propertyOwner.whatsApp",
    "propertyOwner.comapnyLogo",
    "searchCriteria.countryId",
    "searchCriteria.cityId",
    "searchCriteria.zoneId",
    "searchCriteria.propertyMainTypeId",
    "searchCriteria.propertyForId",
    "propertyFiles.mainImages",
    "isGreatPrice",
  ],
  "query": {
    "bool": {
      "must": [
        // {
        //   "match": {
        //     "searchCriteria.propertyMainTypeId": 0
        //   }
        // },
        // {
        //   "match": {
        //     "searchCriteria.propertyForId": 0
        //   }
        // },
        // {
        //   "bool": {
        //     "should": [
        //       {
        //         "term": {
        //           "searchCriteria.countryId": 0
        //         }
        //       },
        //       {
        //         "term": {
        //           "searchCriteria.cityId": 0
        //         }
        //       },
        //       {
        //         "match": {
        //           "searchCriteria.zoneId": 0
        //         }
        //       }
        //     ]
        //   }
        // },
        // {
        //   "match": {
        //     "searchCriteria.propertySubTypeId": 0
        //   }
        // },
        // {
        //   "match": {
        //     "searchCriteria.cityId": 0
        //   }
        // }
      ]
    }
  },
  "sort": [
    {
      "createdAt": {
        "order": "desc"
      }
    }
  ]
};
  
  /**
   * Elastic query body for getting search properties on map
   */
  export const EQSearchPropertyOnMap = {
    "_source": [
      "id",
      "propertyLocation.latitude",
      "propertyLocation.longitude"
    ],
    "query": {
      "bool": {
        "must": [
          // {
          //   "match": {
          //     "searchCriteria.propertyMainTypeId": 0
          //   }
          // },
          // {
          //   "match": {
          //     "searchCriteria.propertyForId": 0
          //   }
          // },
          // {
          //   "bool": {
          //     "should": [
          //       {
          //         "term": {
          //           "searchCriteria.countryId": 0
          //         }
          //       },
          //       {
          //         "term": {
          //           "searchCriteria.cityId": 0
          //         }
          //       },
          //       {
          //         "match": {
          //           "searchCriteria.zoneId": 0
          //         }
          //       }
          //     ]
          //   }
          // },
          // {
          //   "match": {
          //     "searchCriteria.propertySubTypeId": 0
          //   }
          // },
          // {
          //   "match": {
          //     "searchCriteria.cityId": 0
          //   }
          // }
        ]
      }
    },
    "sort": [
      {
        "createdAt": {
          "order": "desc"
        }
      }
    ]
  };
  
  /**
   * Elastic query body for getting cluster properties on map
   */
  export const EQClusterProperty = {
    "from": 0,
    "size": 3,    
    "_source": [
      "id",
      "slug",
      "en.title",
      "en.country",
      "en.zone",
      "en.city",
      "en.unitType",
      "en.currencyType",
      "en.propertyMainType",
      "ar.title",
      "ar.country",
      "ar.zone",
      "ar.city",
      "ar.unitType",
      "ar.currencyType",
      "ar.propertyMainType",
      "attribute.noOfBedrooms",
      "attribute.noOfBathrooms",
      "attribute.builtUpArea",
      "attribute.salePrice",
      "propertyOwner.phone",
      "propertyOwner.email",
      "propertyOwner.whatsApp",
      "propertyOwner.comapnyLogo",
      "searchCriteria.countryId",
      "searchCriteria.cityId",
      "searchCriteria.zoneId",
      "searchCriteria.propertyMainTypeId",
      "searchCriteria.propertyForId",
      "propertyFiles.mainImages",
      "isGreatPrice",
    ],
    "query": {
      "bool": {
        "filter": {
          "terms": {
            "id": []
          }
        }
      }
    }
  }

  /**
   * Elastic query body for getting cluster properties on map
   */
  export const EQPolygonPropertyList = {
    "from": 0,
    "size": 3,
    "_source": [
      "id",
      "slug",
      "en.title",
      "en.country",
      "en.zone",
      "en.city",
      "en.unitType",
      "en.currencyType",
      "en.propertyMainType",
      "ar.title",
      "ar.country",
      "ar.zone",
      "ar.city",
      "ar.unitType",
      "ar.currencyType",
      "ar.propertyMainType",
      "attribute.noOfBedrooms",
      "attribute.noOfBathrooms",
      "attribute.builtUpArea",
      "attribute.salePrice",
      "propertyOwner.phone",
      "propertyOwner.email",
      "propertyOwner.whatsApp",
      "propertyOwner.comapnyLogo",
      "searchCriteria.countryId",
      "searchCriteria.cityId",
      "searchCriteria.zoneId",
      "searchCriteria.propertyMainTypeId",
      "searchCriteria.propertyForId",
      "propertyFiles.mainImages",
      "isGreatPrice",
      "location.lat",
      "location.lon"
    ],
    "query": {
      "bool": {
        "filter": {
          "geo_polygon": {
            "location": {
              "points": [                
              ]
            }
          }
        }
      }
    }
  }

  /**
   * Elastic query body for getting cluster properties on map
   */
  export const EQPolygonPropertyLatLng = {
    "_source": [
      "id",
      "slug",      
      "location.lat",
      "location.lon"
    ],
    "query": {
      "bool": {
        "filter": {
          "geo_polygon": {
            "location": {
              "points": [                
              ]
            }
          }
        }
      }
    }
  }