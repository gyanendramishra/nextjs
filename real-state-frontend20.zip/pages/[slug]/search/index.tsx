import React, { useState, useEffect } from "react";
import { useRouter } from 'next/router'
import { /*GetStaticProps, GetStaticPaths,*/ GetServerSideProps } from 'next';
import { useTranslation } from 'react-i18next';

/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import PropertyArea from "@/components/property/property-area";
import SearchFilter from "@/components/property/search-filter";
import PropertyListing from "@/components/property/property-listing";

/**
 * Import utill, classes, types and etc
 */
import { TFilter, TPSource, TCLocation } from "types";
import { getFilteredProperties, getFilteredAreas } from "../../../services";
import { EPropertyDisplayMode, EPropertyFor, EPropertyType, EPagination, EPropertySort, getFiltersFromParams } from "utils";

type TResult = {
    result:Array<TPSource>;
    total: number;
}

type TProps = {
    initialProperties: TResult;
    initialAreas: Array<TCLocation>;
    initialFilters: TFilter;
}
const  Index = (props: TProps) => {
    
    const { initialProperties, initialAreas, initialFilters } = props;
    const { i18n } = useTranslation();
    const router = useRouter();
    const { language } = i18n;
    console.log('int', initialFilters);
    const [filters, setFilters] = useState<TFilter>(initialFilters);

    const [properties, setProperties] = useState<Array<TPSource>>(initialProperties.result);
    const [areas, setAreas] = useState<Array<TCLocation>>(initialAreas);
    const [totalResult, setTotalResult] = useState<number>(initialProperties.total);
    const [proprtyDisplayMode, setProprtyDisplayMode] = useState<string>(EPropertyDisplayMode.GRID);

    useEffect(() => {
        console.log('beforePopState', 'df');
        router.beforePopState(({ url, as, options }) => {
            console.log('beforePopState', url);
            // I only want to allow these two routes!
            if (as !== '/' && as !== '/other') {
                // Have SSR render bad routes as a 404.
                window.location.href = as
                return false
            }
            return true
        })
      }, []);

    /**
     * Switch property display mode
     * @param displayMode: string
     * @return void
     */
    const switchPropertyDisplayMode = (displayMode: string):void => {
        setProprtyDisplayMode(displayMode);
    }

    /**
     * Handle Pagination
     * @param selectedItem: object
     * @return void
     */
    const handlePagination = async (selectedItem: { selected: number; }) => {
        try{
            let pageNumber = selectedItem.selected;
            let filtesWithPager = {...filters, from : pageNumber*EPagination.PER_PAGE_COUNT, to : EPagination.PER_PAGE_COUNT};
            const result  = await getFilteredProperties(filtesWithPager);
            if(result.status === true){
                setProperties(result.data.result);
                setTotalResult(result.data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Handle Sorting
     * @param selectedItem: object
     * @return void
     */
    const handleSorting = async (e: React.ChangeEvent<HTMLInputElement>) => {
        try{
            const sort = e.currentTarget.value;
            let filtesWithSort = {...filters, from : 0, to : EPagination.PER_PAGE_COUNT, sort:sort};
            const result  = await getFilteredProperties(filtesWithSort);
            if(result.status === true){
                setProperties(result.data.result);
                setTotalResult(result.data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Get the properties by filters
     * @param filters: TFilter
     * @return void
     */
    const handleSearchAfterSubmit = async (filters: TFilter) => {
        try{
            const result  = await Promise.all([
                getFilteredProperties(filters),
                getFilteredAreas(language, filters.for, filters.sub_type),
            ]);
            if(result){
                if(result[0]){
                    setProperties(result[0] ? result[0].data.result : []);
                    setTotalResult(result[0].data.total);
                    setFilters((prevState) => {
                        prevState = filters;
                        return ({
                            ...prevState
                        });
                    });
                }
                if(result[1]){
                    setAreas(result[1] ? result[1].data : []);
                }
            }
        }catch(error){
            console.log(error);
        }
    }
    console.log('fil',filters);
    /**
     * Render the page
     */
    return (
        <Layout>
            <SearchFilter
                initialFilters= { initialFilters }
                handleSearch = { handleSearchAfterSubmit }
            ></SearchFilter>
            <PropertyArea
                areas = { areas }
            ></PropertyArea>
            <PropertyListing
                searchFor= { filters.for }
                totalResult = { totalResult }
                properties= { properties }
                proprtyDisplayMode= { proprtyDisplayMode }
                handlePagination= { handlePagination }
                handleSorting= { handleSorting}
                switchPropertyDisplayMode= { switchPropertyDisplayMode }
            ></PropertyListing>
        </Layout>
    );
}

/**
 * Get server side props
 */
export const getServerSideProps:GetServerSideProps  = async (context) => {

    const initialFilters = await getFiltersFromParams(context.params, context.query);
    try{
        if(context.params == null) throw new Error("Missing params");

        const properties = await getFilteredProperties(initialFilters);

        console.log("properties", properties);

        const areas = await getFilteredAreas(context.locale as string, context.params.slug, context.query.sub_type);
        console.log(properties.data);
        return { 
            props: { 
                initialProperties:  properties.data, 
                initialAreas:  areas.data,
                initialFilters: initialFilters
            } 
        } 
    }catch(error){
        console.log(error);
    }
    return { 
        props: { 
            initialProperties:  {
                result:[],
                total:0
            }, 
            initialAreas:  [],
            initialFilters: initialFilters  
        }
    } 
}

export default Index;
