import { combineReducers } from "redux";
import { searchReducer } from "./";

const rootReducer = combineReducers({
  filters: searchReducer,
});

export default rootReducer;
