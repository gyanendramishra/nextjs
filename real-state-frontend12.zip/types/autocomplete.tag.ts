/*
 * Auto complete tag
 */

export type TTag = {
  model_id: number;
  name: string;
  model: string;
};
