/*
 * Category type
 */
export type TSSearch = {
  for: string;
  type: string;
  locations: Array<{}>;
  category: number | null;
  country: number | null;
};

export type TSearchAction = {
  FOR_FILTER_CHANGED: string;
  TYPE_FILTER_CHANGED: string;
  SUB_TYPE_FILTER_CHANGED: string;
  BEDROOM_FILTER_CHANGED: string;
  BATHROOM_FILTER_CHANGED: string;
  PRICE_FILTER_CHANGED: string;
  SIZE_FILTER_CHANGED: string;
  COUNTRY_FILTER_CHANGED: string;
  FILTER_CHANGE_FAILED: string;
  LOCATION_FILTER_CHANGED: string;
};
