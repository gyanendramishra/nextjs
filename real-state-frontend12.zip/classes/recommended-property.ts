export type TPropertyAttribute = {
  builtUpArea: number;
  noOfBedrooms: number;
  noOfBathrooms: number;
  salePrice: number;
};

export type TPropertyFile = {
  mainImages: [];
};

export type TPropertyOwner = {
  phone: number;
  whatsApp: number;
  email: string;
  comapnyLogo: string;
};

export type TPropertyTranslation = {
  title: string;
  address: string;
  unitType: string;
  currencyType: string;
};

export type TProperty = {
  id: number;
  slug: string;
  attribute: TPropertyAttribute;
  propertyOwner: TPropertyOwner;
  propertyFiles: TPropertyFile;
  en: TPropertyTranslation;
  ar: TPropertyTranslation;
  externalUrl: string;
  externalVideoLink: string;
  isExclusive: boolean;
  isGreatPrice: boolean;
  isHighInvestmentReturn: boolean;
};

export type TPSource = {
  _id: number;
  _index: string;
  _score: number;
  _source: TProperty;
  _type: string;
};

export class RecommendedProperty {
  id: number;
  slug: string;
  attributes: TPropertyAttribute;
  owner: TPropertyOwner;
  files: TPropertyFile;
  en_translations: TPropertyTranslation;
  ar_translations: TPropertyTranslation;
  externalUrl: string;
  externalVideoLink: string;
  isExclusive: boolean;
  isGreatPrice: boolean;
  isHighInvestmentReturn: boolean;
  locale: string;

  /**
   * Create the new property instance
   * @return string
   */
  constructor(property: TPSource, locale: string = "en") {
    this.locale = locale;
    this.id = property._source.id;
    this.slug = property._source.slug;
    this.attributes = property._source.attribute;
    this.owner = property._source.propertyOwner;
    this.files = property._source.propertyFiles;
    this.en_translations = property._source.en;
    this.ar_translations = property._source.ar;
    this.externalUrl = property._source.externalUrl;
    this.externalVideoLink = property._source.externalVideoLink;
    this.isExclusive = property._source.isExclusive;
    this.isGreatPrice = property._source.isGreatPrice;
    this.isHighInvestmentReturn = property._source.isHighInvestmentReturn;
  }

  /**
   * Get the property title
   * @return string
   */
  title = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.title
      : this.en_translations.title;
  };

  /**
   * Get the property address
   * @return string
   */
  address = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.address
      : this.en_translations.address;
  };

  formatedPrice() {
    const formatter = new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 0,
    });
    return formatter.format(this.attributes.salePrice);
  }

  /**
   * Get the property area unit type
   * @return string
   */
  areaUnit = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.unitType
      : this.en_translations.unitType;
  };

  /**
   * Get the property price unit type
   * @return string
   */
  priceUnit = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.currencyType
      : this.en_translations.currencyType;
  };

  /**
   * Get the property main images
   * @return array
   */
  mainImages = (): [] => {
    if (Object.keys(this.files) && this.files.mainImages.length) {
      return this.files.mainImages;
    }
    return [];
  };
}
