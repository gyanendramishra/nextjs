
export enum EPropertyFor {
  "SALE" = "sale",
  "RENT" = "rent",
  "INTERNATIONL" = "international"
};

export enum EPropertyType {
  "COMMERCIAL" = "commerical",
  "RESIDENTIAL" = "residential",
};

export enum EInternationalLables {
  "HIGH_INVESTMENT_RETURN" = "is_high_investment_return",
  "GREAT_PRICE" = "is_great_price",
  "FEATURED" = "is_featured",
};
