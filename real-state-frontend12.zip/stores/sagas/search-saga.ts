import { call, put, take } from "redux-saga/effects";

import { searchActions } from "../actions";

function* forFilterChnagedSaga() {
  try {
    const filter = yield take(searchActions.FOR_FILTER_CHANGED);
    yield put({
      type: searchActions.FOR_FILTER_CHANGED,
      payload: filter.payload,
    });
  } catch (error) {
    yield put({ type: searchActions.FILTER_CHANGE_FAILED, error });
    console.log(error);
  }
}

function* typeFilterChnagedSaga() {
  try {
    const filter = yield take(searchActions.TYPE_FILTER_CHANGED);
    yield put({
      type: searchActions.TYPE_FILTER_CHANGED,
      payload: filter.payload,
    });
  } catch (error) {
    //console.log(error);
    yield put({ type: searchActions.FILTER_CHANGE_FAILED, error });
  }
}

function* locationFilterChangedSaga() {
  try {
    const filter = yield take(searchActions.LOCATION_FILTER_CHANGED);
    console.log(3);
    yield put({
      type: searchActions.LOCATION_FILTER_CHANGED,
      payload: filter.payload,
    });
  } catch (error) {
    console.log(error);
    yield put({ type: searchActions.FILTER_CHANGE_FAILED, error });
  }
}

export default [
  call(forFilterChnagedSaga),
  call(typeFilterChnagedSaga),
  call(locationFilterChangedSaga)
];
