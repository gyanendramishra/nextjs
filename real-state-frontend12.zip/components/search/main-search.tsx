import React, { useState, useContext, useLayoutEffect } from "react";
import PropTypes from "prop-types";
import { TFunction, I18nContext } from "next-i18next";
import { withTranslation } from "../../i18n";
import { connect } from 'react-redux';
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { mainSearchElements } from "../../services";
import { TFilter, TMaster, TSSearch  } from "../../types";

/**
 * Import page components
 */
import LocationSearch from "@/components/search/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";

import { forFilterChanged, typeFilterChanged, locationFilterChanged } from "../../stores/actions";

/**
 * Component styles
 */
import styles from "../../styles/search/main-search.module.scss";

type TProps = {
    readonly t: TFunction; 
    storage: TSSearch;
    dispatchForFilter: Function;
    dispatchTypeFilter: Function;
    dispatchLocationFilter: Function;
} & ReactI18nextWithTranslation;

const MainSearch = (props:TProps) => {
    const { t, storage, dispatchForFilter, dispatchTypeFilter } = props;
    const { i18n: { language } } = useContext(I18nContext);

    const [isMobile, setIsMobile] = useState<boolean>(false);
    
    const [masters, setMasters] = useState<TMaster>({
        categories: [],
        countries: []
    });

    const [filters, setFilters] = useState<TFilter>({
        advanceSearch: false,
        propertyFor: storage.for,
        propertyType: storage.type,
        propertySubType: null,
        locations: storage.locations,
        country : null,
        beadrooms : null,
        bathrooms : null,
        price: null,
        size: null,
    });

    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });

    /**
     * Trigger react lifecycle hook
     */
    React.useEffect(() => {
        getMainSearchElements();
    }, [language, isMobile]);

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = (): void => {
        if (filters.advanceSearch === true) {
            setFilters((prevState) => {
                prevState.advanceSearch = false;
                return({
                  ...prevState
                })
              }
            );
        } else {
            setFilters((prevState) => {
                prevState.advanceSearch = true;
                return({
                  ...prevState
                })
              }
            );
        }
        
    };

    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = (propertyFor: string): void => {
        
        dispatchForFilter(propertyFor);
        setFilters((prevState) => {
            prevState.propertyFor = propertyFor;
            return({
              ...prevState
            })
          }
        );
    };

    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changeLocation = (locations: Array<{}>): void => {
        
        dispatchForFilter(locations);
        setFilters((prevState) => {
            prevState.locations = locations;
            return({
              ...prevState
            })
          }
        );
    };

    /**
     * Change property type
     * @param propertyType: string
     * @return void
     */
    const changePropertyType = (propertyType: string): void => {
        
        dispatchTypeFilter(propertyType);
        setFilters((prevState) => {
            prevState.propertyType = propertyType;
            return({
              ...prevState
            })
          }
        );
    };
    

    /**
     * Get the search masters
     * @return void
     */
    const getMainSearchElements = async () : Promise<void> => {
        const result = await mainSearchElements(language);
        if(result.status === true){
            setMasters(result.data);
        }else{
            console.error(result.message);
        }
    };

    /**
     * Seach component
     */
    let searchComponent;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { masters }
                filters = { filters } 
                changePropertyFor = { changePropertyFor }
                changePropertyType = { changePropertyType }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { masters }
                filters = { filters } 
                changePropertyFor = { changePropertyFor }
                changePropertyType = { changePropertyType }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        )
    }

    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    { searchComponent }
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ masters.categories }
                    propertyFor={ filters.propertyFor }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

/**
 * Validate prop types
 */
MainSearch.propTypes = {
    t: PropTypes.func.isRequired,
};

const mapDispatchToProps = (dispatch: (arg0: { type: string; payload: { for: string; } | { type: string; }; }) => any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor)),
    dispatchTypeFilter: (propertyType:string) => dispatch(typeFilterChanged(propertyType)),
    dispatchLocationFilter: (locations:Array<{}>) => dispatch(locationFilterChanged(locations)),
});

const mapStateToProps = (state: any) => ({
    storage:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslation("main-search")(MainSearch));
