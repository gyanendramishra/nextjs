import React, { useContext, useState } from "react";
import PropTypes from "prop-types";
import { TFunction, I18nContext } from "next-i18next";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { EInternationalLables, EPropertyFor } from "../../utils";
import { TCLocation, TCategory } from "../../types";
import { forRentLocations, forSaleLocations, internationalLocations } from "../../services";


type TProps = {
    readonly t: TFunction;
    propertyFor: string;
    categories : TCategory[];
    styles: TStyle;
} & ReactI18nextWithTranslation;

type TStyle = {
    readonly [key: string]: string;
};

type TActiveCalegory = {
    id: number,
    name: string,
}

const LocationSearch = (props:TProps) => {
    const { t, propertyFor, styles, categories } = props;
    const { i18n: { language } } = useContext(I18nContext);

    const [activeKSACategory, setActiveKSACategory] = useState<TActiveCalegory>({
        id: 0,
        name: "",
    });
    const [activeInternationalCategory, setActiveInternationalCategory] = useState<string>(EInternationalLables.HIGH_INVESTMENT_RETURN);
    const [ksaCategoryLocations, setKSACategoryLocation] = useState<Array<TCLocation>>([]);
    const [internationalCategoryLocations, setInternationalCategoryLocation] = useState<Array<TCLocation>>([]);

    /**
     * Trigger react lifecycle hook
     */
    React.useEffect(() => {
        if(Object.keys(categories).length){
            switchKSACategory(categories[0]);
        }
    }, [categories]);

    /**
     * Swith the KSA search category
     * @return void
     */
    const switchKSACategory = async (category: TActiveCalegory) => {
        setActiveKSACategory((prevState) => {
            prevState.id = category.id;
            prevState.name = category.name;
            return({
              ...prevState
            })
          }
        );
        if(propertyFor === EPropertyFor.RENT){
            getForRentLocations(language, category.id);
        }else{
            getForSaleLocations(language, category.id);
        }
    }

    /**
     * Swith the international category
     * @return void
     */
    const switchInternationalCategory = async (category: string) => {

        setActiveInternationalCategory(category);
        setInternationalCategoryLocation([]);
        const result = await internationalLocations(language, category);
        if(result.status === true){
            setActiveInternationalCategory(category);
            setInternationalCategoryLocation(result.data);
        }else{
            console.error(result.message);
        }
        
    }

    /**
     * Get the locations of the category
     * @return
     */
    const getForRentLocations = async (locale: string, category: number) => {
        const result = await forRentLocations(locale, category);
        if(result.status === true){
            setKSACategoryLocation(result.data);
        }else{
            console.error(result.message);
        }
    }

    /**
     * Get the locations of the category
     * @return
     */
    const getForSaleLocations = async (locale: string, category: number) => {
        const result = await forSaleLocations(locale, category);
        if(result.status === true){
            setKSACategoryLocation(result.data);
        }else{
            console.error(result.message);
        }
    }

    let locationComponent;

    if (propertyFor === EPropertyFor.INTERNATIONL) {
        locationComponent = (
            <div className={styles.advance_search_block}>
                <div className={`${styles.custom_tab}`}>
                    <ul className={styles.prop_tab}>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.HIGH_INVESTMENT_RETURN) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.HIGH_INVESTMENT_RETURN)}
                            >
                                {t("LABELS.HIGH_INVESTMENT_RETURN")}
                            </a>
                        </li>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.GREAT_PRICE) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.GREAT_PRICE)}
                            >
                                {t("LABELS.GREAT_PRICE")}
                            </a>
                        </li>
                        <li>
                            <a 
                                className={`${(activeInternationalCategory === EInternationalLables.FEATURED) ? styles.active : ""}`} 
                                onClick={() => switchInternationalCategory(EInternationalLables.FEATURED)}
                            >
                                {t("LABELS.FEATURED")}
                            </a>
                        </li>     
                    </ul>
                    {internationalCategoryLocations &&
                        <div className={`${styles.tab_content}`}>
                            <ul className={styles.link2}>
                                {internationalCategoryLocations.map((location:TCLocation, index:number) => {
                                    return (
                                        <li key={index}>
                                            <a href="#">{location.name}</a>
                                        </li>
                                    )
                                })}
                            </ul>
                            <div className={styles.all_properties}>
                                <a href="#">{ t("LABELS.VIEW_ALL_PROPERTIES") }</a>
                            </div>
                        </div>
                    }
                </div>
            </div>
        );
    }else if(Object.keys(categories).length){
        locationComponent = (
            <div className={styles.advance_search_block}>
                <div className={`${styles.custom_tab}`}>
                    <ul className={styles.prop_tab}>
                        { categories.map((category, index)=>{
                            return (
                                <li key={index}>
                                    <a className={`${(activeKSACategory.id === category.id) ? styles.active : ''}`} onClick={() => switchKSACategory(category)}>
                                        {category.name}
                                    </a>
                                </li>
                            )
                        })}
                    </ul>
                    {ksaCategoryLocations &&
                        <div className={`${styles.tab_content}`}>
                            <ul className={styles.link2}>
                                {ksaCategoryLocations.map((location:TCLocation, index:number) => {
                                    return (
                                        <li key={index}>
                                            <a href="#">
                                                {activeKSACategory.name} {(propertyFor == EPropertyFor.RENT) ? t("AREA_FILTER_LABLE.FOR_RENT_IN") : t("AREA_FILTER_LABLE.FOR_SALE_IN") } {location.name}
                                            </a>
                                        </li>
                                    )
                                })}
                            </ul>
                            <div className={styles.all_properties}>
                                <a href="#">{ t("LABELS.VIEW_ALL_PROPERTIES") }</a>
                            </div>
                        </div>
                    }
                </div>
            </div>
        );
    }
    return (
        <>
            { locationComponent }
        </>
    );
};

/**
 * Validate prop types
 */
LocationSearch.propTypes = {
    t: PropTypes.func.isRequired,
};

export default withTranslation("main-search")(LocationSearch);