import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

import styles from '../../styles/home/download-app.module.scss';

type TProps = {
    readonly t: TFunction;
} & ReactI18nextWithTranslation

const  DownloadApp = (props: TProps) => {

    const { t } = props;
  
    return (
        <div className={styles.property_servies}>
            <div className={styles.container}>
                <div className={styles.app_download_block}>
                    <div className={styles.app_block1}>
                        <img src="/images/phone-banner.svg" alt=""/>
                    </div>
                    <div className={styles.app_block2}>
                        <h2>{ t("TITLE")}</h2>
                        <p>{ t("SUB_TITLE")}<br></br> { t("TAGLINE")}</p>
                    </div>
                    <div className={styles.app_block3}>
                        <a href="#"><img src="/images/app-store.svg" alt=""/></a>
                        <a href="#"><img src="/images/google-pay.svg" alt=""/></a>
                    </div>
                </div>
            </div>
        </div>
    );
}

/**
 * Validate prop types
 */
DownloadApp.propTypes = {
    t: PropTypes.func.isRequired,
};

export default withTranslation("download-app")(DownloadApp);
