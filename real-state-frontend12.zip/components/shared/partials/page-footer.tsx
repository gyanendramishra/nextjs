import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * component styles
 */
import styles from '../../../styles/shared/footer.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
}

export class PageFooter extends React.Component<Props> {
    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
    };
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired
    };

    /**
     * Get initial props
     * @return response
     */
    static getInitialProps = async () => {
        return {
            namespacesRequired: ["footer"],
        };
    };
    /**
     * Render the component html
     * @return mix
     */
    render() {
        const { t } = this.props;

        return (
            <footer className={styles.footer}>
                <div className={styles.container}>
                    <div className={styles.ftr_btm}>
                        <div className={styles.ftr_lt}>
                            <div className={styles.ftr_btm_nav}>
                                <a href="#">{ t("NAVIGATIONS.ABOUT") }. </a>
                                <a href="#">{ t("NAVIGATIONS.TERMS_AND_CONDITIONS") }. </a>
                                <a href="#">{ t("NAVIGATIONS.PRIVACY_POLICY") }. </a>
                                <a href="#">{ t("NAVIGATIONS.CUSTOMER_LOGIN") }. </a>
                                <a href="#">{ t("NAVIGATIONS.CAREERS") }.</a>
                                <a href="#">{ t("NAVIGATIONS.COMPANY_REGISTRATION") }. </a>
                            </div>
                            <div className={styles.ftr_btm_nav2}>
                                <a href="#">{ t("NAVIGATIONS.TERMS") }</a> | <a href="#">{ t("NAVIGATIONS.PRIVACY_POLICY") }</a>
                            </div>
                        </div>
                        <div className={styles.ftr_rt}>
                            <a className={styles.wd1} href="#">
                                <img src="/images/app-store.svg" alt=""/>
                            </a>
                            <a className={styles.wd2} href="#">
                                <img src="/images/google-pay.svg" alt=""/>
                            </a>
                        </div>
                    </div>
                </div>
            </footer>
        );
    };
}

export default withTranslation("footer")(PageFooter);
