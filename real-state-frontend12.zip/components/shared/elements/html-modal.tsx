import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * component styles
 */
//import styles from '../../../styles/shared/footer.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    readonly opened : boolean;
    readonly title: string;
}

interface State {
    opened : boolean;
}

export class Modal extends React.Component<Props, State> {
    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            opened: props.opened,
        }
    };
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
        opened: PropTypes.bool.isRequired,
        title: PropTypes.string.isRequired
    };

    /**
     * Get initial props
     * @return response
     */
    static getInitialProps = async () => {
        return {
            namespacesRequired: ["footer"],
        };
    };

    /**
     * Close the modal
     * @return void
     */
    public closeModal =  (): void => {
        this.setState({
            ...this.state,
            opened: false
        });
    }

    /**
     * Render the component html
     * @return mix
     */
    render() {
        const { t, title, opened } = this.props;

        return (
            <>
                {(opened === true) &&
                    <div className="modal">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">{ title }</h5>
                                    <button type="button" className="close" onClick={ this.closeModal }>
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div className="modal-body">
                                    
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-primary">Save changes</button>
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        );
    };
}

export default withTranslation("footer")(Modal);
