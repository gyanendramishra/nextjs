import axios, { AxiosResponse } from "axios";
import { TResultSet } from "../types";
import {
  EQRecommendedPropertyFORKSA,
  EQRecommendedPropertyFORInternational,
} from "../utils/elastic-queries";

/**
 * Get the search masters
 * @return result: TResultSet
 */
export const getRecommendedKSAProperties = async (): Promise<TResultSet> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORKSA
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const getRecommendedInternationalProperties = async (): Promise<
  TResultSet
> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORInternational
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};
