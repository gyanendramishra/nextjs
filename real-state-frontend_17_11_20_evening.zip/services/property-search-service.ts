import axios, { AxiosResponse } from "axios";
import { stringify } from "querystring";
import { TResultSet } from "../types";
import { EQSearchPropertyList } from "../utils/elastic-list-queries";
type TFilter = {
    propertyForId: string;
    propertyMainTypeId: string;
    propertySubTypeId: string | null;
    noOfBedrooms: number | null;
    noOfBathrooms: number | null;
    locations: [] | null;
    price: {min:string, max:string} | null;
    size: {min:string, max:string} | null;
    sortSearch:string;
    from:number;
    noOfPropertiesOnPage:number;
};


  /**
   * Get the search masters
   * @return void
   */
  export const  getSearchMasters = async (language:string) : Promise<TResultSet> => {
    let result: TResultSet = {};
    try {
        const response:AxiosResponse = await axios.get(
            `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/search-elements`,
            {
            headers: {
                locale: language,
            },
            }
        );
        result.status = true;
        result.data = response.data;
    } catch (error) {
        result.status = false;
        result.message = error.message;
    }
    return result;
  };

/**
 * Get the property types
 * @return void
 */
  export const  propertyTypes = async (language:string, type:string) : Promise<TResultSet> => {
    let result: TResultSet = {};
    try {
        const response:AxiosResponse = await axios.get(
            `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/property-types/${type}`,
            {
                headers: {
                    locale: language,
                }
            }
        );
        result.status = true;
        result.data = response.data;
    } catch (error) {
        result.status = false;
        result.message = error.message;
    }
    return result;
  };

/**
 * Get the property search List
 * @return void
 */
export const  propertySearchList = async (formData:TFilter) : Promise<TResultSet> => {
    let result: TResultSet = {};
    const query:any = EQSearchPropertyList
    let searchArr = [];
    let sortArr = [];
    
    if(formData.propertyForId){
        searchArr.push({
            "match": {
                'searchCriteria.propertyForId': formData.propertyForId
            }
        })
    }
    if(formData.propertyMainTypeId){
        searchArr.push({
            "match": {
                'searchCriteria.propertyMainTypeId': formData.propertyMainTypeId
            }
        })
    }
    if(formData.propertySubTypeId){
        searchArr.push({
            "match": {
                'searchCriteria.propertySubTypeId': formData.propertySubTypeId
            }
        })
    }
    if(formData.noOfBedrooms ){
        searchArr.push({
            "match": {
                'attribute.noOfBedrooms': formData.noOfBedrooms
            }
        })
    }
    if(formData.noOfBathrooms ){
        searchArr.push({
            "match": {
                'attribute.noOfBathrooms': formData.noOfBathrooms
            }
        })
    }

    if(formData.locations){
        formData.locations.map((val:any)=>{
            console.log('val',val)
            if(val.model=='country'){
                searchArr.push({
                    "match": {
                        'searchCriteria.countryId': val.model_id
                    }
                })
            }
            if(val.model=='city'){
                searchArr.push({
                    "match": {
                        'searchCriteria.cityId': val.model_id
                    }
                })
            }
            if(val.model=='zone'){
                searchArr.push({
                    "match": {
                        'searchCriteria.zoneId': val.model_id
                    }
                })
            }
        })
    }

    if(formData.price && formData.price.min!==''){
        searchArr.push({range:{
            "attribute.salePrice": {
                "gte": formData.price.min,
                "lte": formData.price.max
            }
        }})
    }

    if(formData.size && formData.size.min!==''){
        searchArr.push({range:{
            "attribute.builtUpArea": {
                "gte": formData.size.min,
                "lte": formData.size.max
            }
        }})
    }

    if(formData.sortSearch=='relevence'){
        sortArr.push()
    }else if(formData.sortSearch=='isExclusive'){
        sortArr.push({
            "isExclusive": {
              "order": "desc"
            }
          })

    }else if(formData.sortSearch=='asc'){
        sortArr.push({
            "attribute.salePrice": {
              "order": "asc"
            }
          })

    }else if(formData.sortSearch=='desc'){
        sortArr.push({
            "attribute.salePrice": {
              "order": "desc"
            }
        })
    }
    
    /*  
    * there are match array assign
    */
    query.query.bool.must = searchArr;
    query.sort = sortArr;
    query.from  = formData.from;
    query.size  = formData.noOfPropertiesOnPage;
    console.log('piyush chaturvedi',query);
    try {
        const response:AxiosResponse = await axios.post(
            `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`, query
        );
        result.status = true;
        result.data = response.data;
    } catch (error) {
        result.status = false;
        result.message = error.message;
    }
    return result;
  };

    /**
     * get city area
     * @param locale
     * @return response
     */

export const getCityArea = async (language:string,forType:string)=>{
    let result: TResultSet = {};
    try {
        const response:AxiosResponse = await axios.get(
            `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/${forType}`,
            {
            headers: {
                locale: language,
            },
            }
        );
        result.status = true;
        result.data = response.data;
    } catch (error) {
        result.status = false;
        result.message = error.message;
    }
    return result;
}