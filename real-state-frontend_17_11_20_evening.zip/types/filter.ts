import { TCategory, TCountry } from "./";

/**
 * Proprerty filter type
 */
export type TFilter = {
  advanceSearch: boolean;
  for: string;
  type: string;
  sub_type: string | null;
  locations: Array<{}>;
  country: number | null;
  beadrooms: number | null;
  bathrooms: number | null;
  price: number | null;
  size: number | null;
};

/**
 * Master elements type
 */
export type TMaster = {
  categories: TCategory[];
  countries: TCountry[];
};
