export type TResultSet = {
  status?: boolean;
  message?: string;
  data?: any;
};
