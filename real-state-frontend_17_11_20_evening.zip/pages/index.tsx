import React from "react";
import { GetStaticProps } from 'next';

/**
 * import clases, services types and utills
 */
import { TPSource, TMaster } from '../types';
import { getMainSearchElements, getRecommendedKSAProperties, getRecommendedInternationalProperties } from '../services';


/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import DownloadApp from "@/components/home/download-app";
import MainSearch from "@/components/search/main-search";
import HomeLinks from "@/components/home/home-links";
import RecommendedPropertiesKSA from "@/components/home/recommended-properties-ksa";
import RecommendedPropertiesInternational from "@/components/home/recommended-properties-international";


type TProps = {
    searchElements: TMaster;
    rKSAProperties: Array<TPSource>;
    rIProperties: Array<TPSource>;
};

const  Index = (props: TProps) => {
    const { searchElements, rKSAProperties, rIProperties } = props;

    /**
     * Render the page
     */
    return (
        <Layout>
            {/* Search properties compoent */}
            <MainSearch
                searchElements = {searchElements}
            ></MainSearch>
            {/* Recommended properties In KSA compoent */}
            <RecommendedPropertiesKSA
                properties= {rKSAProperties}
            ></RecommendedPropertiesKSA>
            {/* Recommended properties In Internationsl compoent */}
            <RecommendedPropertiesInternational
                properties= {rIProperties}
            ></RecommendedPropertiesInternational>
            {/* Download APP compoent */}
            <DownloadApp></DownloadApp>
            {/* Home links component */}
            <HomeLinks></HomeLinks>
        </Layout>
    );
}

/**
 * Get static props
 */
export const getStaticProps:GetStaticProps = async (ctx) => {

    const result  = await Promise.all([
        getMainSearchElements(ctx.locale as string),
        getRecommendedKSAProperties(),
        getRecommendedInternationalProperties()
    ]);
    return { props: { 
            searchElements: result[0].data, 
            rKSAProperties: result[1].data, 
            rIProperties: result[2].data
        } 
    }
}


export default Index;
