import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";
import { Formik, Field, Form, FormikHelpers } from "formik";
import ReactPaginate from 'react-paginate';

/**
 * Import page components
 */

import Layout from "@/components/shared/layouts/layout";
// import SearchFilter from "@/components/listing/search-filter";
import PropertyItem from "@/components/property/item";
import PropertyItemList from "@/components/property/item-list";
import PropertyArea from "@/components/listing/property-area";
import PropertySortFilter from "@/components/listing/property-sort-filter";
// import PropertyListingMain from "@/components/listing/property-listing-main";

/**
 * Import component types
 */
import { TTranslation, TCountry, TCategory } from "../types";

/**
 * Import component utils
 */
import { beadroomList, bathroomList,priceList, sizeList} from "../utils/search-constants";

/**
 * Import page components
 */
// import LocationSearch from "@/components/home/location-search";
import Autocomplete2 from "@/components/search/autocomplete2";
import MinMaxPicker from "@/components/search/min-max-picker2";
//import Autocomplete from "@/components/search/autocomplete";

/**
 * Component styles,styles1
 */

import styles from '../styles/listing/search-filter.module.scss';

import styles1 from '../styles/listing/property-listing-main.module.scss';

import styles3 from '../styles/listing/pagination.module.scss';


/**
 * Import component services
 */
import {propertyTypes, propertySearchList,getCityArea } from "../services";
/**
 * import types and queries
 */
import { RecommendedProperty, TPSource } from '../classes/recommended-property';

  
interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction,
    translation: TTranslation;
}

interface States {
    masters: TMaster;
    propertyTypes: TMaster;
    filter: TFilter;
    types:string
    searchList:any,
    pageCount:number;
    itemView:boolean;
    forType:string;
}

type TFilter = {
    propertyForId: string;
    propertyMainTypeId: string;
    propertySubTypeId: string | null;
    noOfBedrooms: number | null;
    noOfBathrooms: number | null;
    locations: [] | null;
    price: {min:string, max:string} | null;
    size: {min:string, max:string} | null;
    sortSearch:string;
    selectedPage:number;
    from:number;
    noOfPropertiesOnPage:number;
    
};

type TData= any;

type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};

class PropertySearchList extends React.Component<Props, States>{
    [x: string]: any;

    /**
     * New component instance
     */
    constructor(props: Props) {
        super(props);
        this.state = {
            masters: {
                categories: [],
                countries: [],
            },
            propertyTypes:{
                categories: [],
                countries: [],
            },
            filter: {
                propertyForId: "3",
                propertyMainTypeId: "3",
                propertySubTypeId:null,
                noOfBedrooms: null,
                noOfBathrooms:  null,
                locations: [],
                price: {min: '',max: ''},
                size: {min:'', max:''},
                sortSearch:'relevence',
                selectedPage:1,
                from:1,
                noOfPropertiesOnPage:3,
            },
            types:'',
            searchList:[],
            pageCount:0,
            itemView:true,
            forType:'3'
        };
    }

    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["common"],
        };
    }

     /**
     * Submit property type
     * @param types
     * @return response
     */

    getPropertyTypes = async (types:string)=>{
        const { i18n } = this.props;
        let  type = types=='3'?"residential":"commercial";
        const response = await propertyTypes(i18n.language,type);
        const { data,status } = response.data;
        if(status===true){
            this.setState({ masters: data });
        } 
    }

    /**
     * Submit search data
     * @param formData
     * @return response
     */

    onHandleSubmit = async (formData:TFilter)=>{
        this.setState({searchList:await propertySearchList(formData)})
        const {searchList, filter} = this.state;
        if(searchList.status){
            let totalPage = searchList.data.hits.total.value/filter.noOfPropertiesOnPage;
            this.setState({pageCount:Math.round(totalPage)})
        }
    }

    /**
     * Submit search data
     * @param formData
     * @return response
     */

    sortSearch = async (sortSearch:string)=>{
        let filter = this.state.filter;
        filter.sortSearch = sortSearch;
        this.setState({filter:filter})
        this.setState({searchList:await propertySearchList(filter)})
    }

    /**
     * set list View and grid view 
     * @param itemView
     * @return response
     */

    setView = (itemView:boolean)=>{
        this.setState({itemView:itemView})
    }

   
    setCityArea = ()=>{
        const { i18n } = this.props;
        const {filter} = this.state;
        let forType =filter.propertyForId=='3'?'areas-for-sale':'/v1/search-box/areas-for-rent'
        getCityArea(i18n.language,forType)
    }
    

    async componentDidMount(){
        const {filter} = this.state;
        
        const {propertyMainTypeId, propertyForId} = filter;
        this.getPropertyTypes(propertyMainTypeId);
        let data:TData = {propertyMainTypeId:propertyMainTypeId, propertyForId:propertyForId, from:filter.from, noOfPropertiesOnPage:filter.noOfPropertiesOnPage}
        this.onHandleSubmit(data)
        


    }

    handlePageClick=(data:any) =>{  
        const {noOfPropertiesOnPage}=this.state.filter
        const from = (data.selected*noOfPropertiesOnPage);
        let filter = this.state.filter;
        filter.from = from;
        this.setState({filter:filter})
        let paginationData:TData ={from:from, noOfPropertiesOnPage:noOfPropertiesOnPage}
        this.onHandleSubmit(paginationData)
        
    }

    /**
     * Render the page
     */
    render() {
        const { t,i18n } = this.props;
        const { filter, masters, searchList,pageCount, itemView,forType } = this.state;
        const { categories } = masters;
        return (
            <Layout title={ t('common:APP_NAME') }>
                <div className={styles.search_filter_outer}> {/* Desktop Search Filter */}
                <div className={styles.search_filter}>
                    <div className={styles.container}>
                    <Formik
                        initialValues={
                            filter
                        }
                        onSubmit={
                            async (values: TFilter, {  }: FormikHelpers<TFilter>) => {
                                console.log(values);
                                this.setState({forType:values.propertyForId})
                                await this.onHandleSubmit(values);
                                //setSubmitting(false);
                            }
                        }
                        >
                        {() => (
                            <Form>
                                <div className={`${styles.adv_row} ${styles.mbl_row}`}>
                                    <div className={styles.adv_col1}>
                                        <Field as="select" className={styles.form_control} name="propertyForId">
                                            <option value="3">{ t("SEARCH_FOR.FOR_SALE") }</option>
                                            <option value="4">{ t("SEARCH_FOR.FOR_RENT") }</option>
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <select className={styles.form_control} name="propertyMainTypeId" onChange={(e)=>{this.getPropertyTypes(e.target.value )}} >
                                            <option value='3'>{ t("SEARCH_TYPE.RESIDENTIAL") }</option>
                                            <option value='1'>{ t("SEARCH_TYPE.COMMERCIAL") }</option>
                                        </select>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <Field as="select" className={styles.form_control} name="propertySubTypeId">
                                            <option value="">{ t("LABELS.PROPERTY_TYPE") }</option>
                                            {categories && categories.map((value, index) => {
                                                return (
                                                    <option key={index} value={ value.id }>{ value.name }</option>
                                                );
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <Field as="select" className={styles.form_control} name="noOfBedrooms">
                                            <option value="">{ t("LABELS.BEDS") }</option>
                                            { beadroomList.map((option, index) => {
                                                return (
                                                    <option key={index} value={ option }>{ option }</option>
                                                );
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <Field as="select" className={styles.form_control} name="noOfBathrooms">
                                            <option value="">{ t("LABELS.BATHS") }</option>
                                            { bathroomList.map((option, index) => {
                                                return (
                                                    <option key={index} value={ option }>{ option }</option>
                                                );
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col2}>
                                        <MinMaxPicker 
                                            name="price"
                                            label={ t("LABELS.PRICE") }
                                            options={ priceList }
                                            //styles={styles}
                                        ></MinMaxPicker>
                                    
                                    </div>
                                </div>
                                <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
                                    <div className={styles.adv_col2}>
                                        <MinMaxPicker 
                                           name="size"
                                           label={ t("LABELS.SIZE") }
                                           options={ sizeList }
                                        //     styles={styles}
                                        ></MinMaxPicker>
                                    </div>
                                    <div className={styles.adv_col3}> 
                                        <Autocomplete2 name="locations" containerClass={styles.web_autocomplete}></Autocomplete2>
                                    </div>
                                    
                                    <div className={styles.adv_col4}>
                                        <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button> <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
                                    </div>
                                </div>
                            </Form>
                        )}
                    </Formik>
                    </div>
                </div> {/* Desktop Search Filter */} {/* Mobile Popup Search Filter */}
                <div className={styles.search_mobile_block_outer}>
                    <div className={styles.search_category_nav}>
                        <ul className="d-flex">
                            <li><a className={styles.active}>For Sale</a></li>
                            <li><a>For Rent</a></li>
                            <li><a>International</a></li>
                        </ul>
                    </div> {/* FOR SALE SECTION */}
                    <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
                        <div className={styles.adv_col_full}> {/*
                            <Autocomplete3></Autocomplete3> */} </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Residential</option>
                                <option>Commercial</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Property Type</option>
                                <option>Apartment</option>
                                <option>Commercial</option>
                                <option>Land</option>
                                <option>Private Island</option>
                                <option>Villa / Townhouse</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Beds</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5+</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Baths</option>
                            </select>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Price</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Price</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Size</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Size</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.adv_col_full}>
                            <button type="submit" className={styles.mbl_find_btn}>Find</button>
                        </div>
                        <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                    </div> {/* FOR RENT SECTION */}
                    <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
                        <div className={styles.adv_col_full}> {/*
                            <Autocomplete3></Autocomplete3> */} </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Residential</option>
                                <option>Commercial</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Property Type</option>
                                <option>Apartment</option>
                                <option>Commercial</option>
                                <option>Land</option>
                                <option>Private Island</option>
                                <option>Villa / Townhouse</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Beds</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5+</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Baths</option>
                            </select>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Price</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Price</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Size</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Size</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.adv_col_full}>
                            <button type="submit" className={styles.mbl_find_btn}>Find</button>
                        </div>
                        <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                    </div> {/* INTERNATIONAL SECTION */}
                    <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
                        <div className={styles.adv_col_full}> {/*
                            <Autocomplete3></Autocomplete3> */} </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Residential</option>
                                <option>Commercial</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Property Type</option>
                                <option>Apartment</option>
                                <option>Commercial</option>
                                <option>Land</option>
                                <option>Private Island</option>
                                <option>Villa / Townhouse</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Beds</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5+</option>
                            </select>
                        </div>
                        <div className={styles.adv_col_full}>
                            <select className={styles.form_control}>
                                <option>Baths</option>
                            </select>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Price</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Price</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Min: Size</option>
                                </select>
                            </div>
                            <div className={styles.wd2}> <span>to</span> </div>
                            <div className={styles.wd1}>
                                <select className={styles.form_control}>
                                    <option>Max: Size</option>
                                </select>
                            </div>
                        </div>
                        <div className={styles.adv_col_full}>
                            <button type="submit" className={styles.mbl_find_btn}>Find</button>
                        </div>
                        <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                    </div>
                </div> {/* Mobile Popup Search Filter */} </div>
                
                <PropertyArea></PropertyArea>
                
                <PropertySortFilter forType={forType=='3'?'For Sale':'For Rent'} getView={this.setView} sortSearch={this.sortSearch} totalCount={searchList.status?searchList.data.hits.total.value:0}></PropertySortFilter>
                <div className={styles1.property_listing_main}>
                    <div className={styles1.container}>
                        <div className="row">
                            <div className="col-md-8">
                            <div className={itemView?`${styles1.list_view} ${styles1.dis_block}`:`${styles1.grid_view} ${styles1.dis_block}`}>
                                <div className="row">
                                    {searchList.status &&
                                        searchList.data.hits.hits.map((property:TPSource,  index:number)=>{
                                        const rProperty = new RecommendedProperty(property, i18n.language);
                                        return (
                                            <div className={itemView?'col-md-12':'col-md-6'}>
                                                {itemView?
                                                <PropertyItem
                                                    key={index}
                                                    property={rProperty}
                                                ></PropertyItem>: 
                                                <PropertyItemList
                                                key={index}
                                                property={rProperty}
                                            ></PropertyItemList>
                                                }
                                            </div>
                                        )})
                                    }
                                </div>
                             </div>
                             <div className={styles3.pagination_block}>
                                <ReactPaginate
                                previousLabel={'<'}
                                nextLabel={'>'}
                                breakLabel={'...'}
                                pageCount={pageCount}
                                marginPagesDisplayed={10}
                                pageRangeDisplayed={3}
                                onPageChange={this.handlePageClick}
                                breakClassName={'page-item'}
                                breakLinkClassName={'page-link'}
                                containerClassName={styles3.pagination}
                                pageClassName={'page-item'}
                                pageLinkClassName={'page-link'}
                                previousClassName={'page-item'}
                                previousLinkClassName={'page-link'}
                                nextClassName={'page-item'}
                                nextLinkClassName={'page-link'}
                                activeClassName={'active'}
                                initialPage={0}
                                // forcePage={1}
                                />
                             </div>
                            </div>
                            <div className="col-md-4">
                                <div className={styles1.ad_block1}>
                                    <a href="#"><img src="/images/Add1.svg" alt=""/></a>
                                </div>
                                <div className={styles1.ad_block2}>
                                    <a href="#"><img src="/images/Add2.svg" alt=""/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* <PropertyListingMain></PropertyListingMain> */}
            </Layout>
        )
    }
}

export default withTranslation("main-search")(PropertySearchList);
