import React, { useEffect, useState } from "react";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";
import ReactPaginate from 'react-paginate';
import { useRouter , withRouter } from 'next/router';

// import { NextPageContext } from 'next'
import  decodePolyline from 'decode-google-map-polyline';
/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import ShowMap from "@/components/map/show-map";
import MapPropertiesList from "@/components/map/map-properties-list";

/**
 * Import components
 */
import { 
    searchPropertiesOnMap, 
    searchPropertiesListOnMap, 
    propertiesOfClusterOnMap, 
    propertiesInPolygonOnMap,
    propertiesListInPolygonOnMap 
} from '../services';
import {  TPSource } from '../classes/search-property';


type TProps =  {
    router: {
        query: Tquery
    }    
}
type Tquery = null | object;

type TStates = {
    propertieslatlng: TPSource[],
    properties: TPSource[],
    pageCount: number,
    noOfPropertiesOnPage: number,
    apiCallName: string
    ids: number[],
    selectedPage: number,
    coordinatePoints: any
}

type TPointsPolygon = {
    lat: Function, 
    lng: Function
}

// class SearchOnMapPage extends React.Component<Props, TStates> {
const SearchOnMapPage = (props: TProps) =>{

    const router = useRouter;
    /**
     * Create new component instance
     * @return void
     */
    // constructor(props: Props) {
    //     super(props);
    //     this.state = {
    //         propertieslatlng : [],
    //         properties : [],
    //         pageCount: 0,
    //         noOfPropertiesOnPage: 4,
    //         apiCallName: "searchPropertiesListOnMap",
    //         ids: [],
    //         selectedPage: 0,
    //         coordinatePoints: []
    //     }
    // }
    const query: Tquery = props.router.query;    
    let polygonData = "";
    let polygonDataArray: [] = [];
    if(query["polygonData"] !== undefined){
        polygonData = query["polygonData"];
        const coordinatePoints = decodePolyline(polygonData);        
        polygonDataArray = coordinatePoints;
    }

    const [mapstate, setMapState]:[TStates, Function] = useState({
                    propertieslatlng : [],
                    properties : [],
                    pageCount: 0,
                    noOfPropertiesOnPage: 4,
                    apiCallName: "",
                    ids: [],
                    selectedPage: 0,
                    coordinatePoints: []
                });
    /**
     * Validate prop types
     */
    // public static propTypes = {
    //     t: PropTypes.func.isRequired,
    // };
    /**
     * Get initial props
     * @return response
     */
    // static async getInitialProps({ query }: {query: any} ) {
    //     // const { router } = this.props;
    //     const ploygonData: string = query.polygonData;
        
    //     return {
    //         namespacesRequired: ["common"],
    //     };
    // }

    const showPloygonDataOnMapList = (ploygonData) => {
        // console.log(ploygonData);
    }

    /**
     * Triggers when component is load
     * @return void
     */    
    // const componentDidMount = async () => {
    useEffect(() => {
        async function fetchData() {
            await PropertiesLatLongOnMap();
            await PropertiesListOnMap();
        }
        fetchData();
    },[]);

    useEffect(() => {        
        async function fetchData() {
            if(polygonData){   
                console.log('search-on-map: Line no 129',polygonDataArray,polygonDataArray.length);
                const coordinatePoints = polygonDataArray;             
                // console.log('Get polygonData',coordinatePoints);
                let changedCoordinatePoints: { "lat": string, "lon": string }[] = []; 
                coordinatePoints.map((point: TPointsPolygon)=>{
                    const lat = point.lat;
                    const long = point.lng;
                    const coordPoint: { "lat": string, "lon": string } = { "lat": lat, "lon": long };
                    changedCoordinatePoints.push(coordPoint);
                });
                await PropertiesLatLongPolygonOnMap(changedCoordinatePoints);
            }  
        }      
        fetchData();
    },[polygonData]);


    const PropertiesLatLongPolygonOnMap = async (coordinatePoints: any) =>{
        const resultOnMap = await propertiesInPolygonOnMap(coordinatePoints);
        if(resultOnMap.status === true){
            console.log('line no 149:',resultOnMap.data.result);
            let resultLatlong = resultOnMap.data.result.map((property: any)=>{
                let prop = property._source;
                const id = property._source.id;
                const lat =  property._source.location.lat;
                const lng =  property._source.location.lon;
                prop = {id:id,propertyLocation:{"latitude": lat,"longitude": lng}};
                property._source = prop;
                return property;
            });
            console.log(resultLatlong);
            setMapState((prevState: TStates) => {
                prevState.propertieslatlng = resultLatlong;
                prevState.apiCallName = "searchPropertiesOnMap";
                return({
                ...prevState
                })
            });
            console.log(mapstate);
            // this.setState({"propertieslatlng": resultLatlong});
        } else {
            // console.error(resultOnMap.message);
        }
    }
    /*
    * Function for getting 
    * @return void
    */
    const PropertiesLatLongOnMap = async () =>{ 
        const resultOnMap = await searchPropertiesOnMap();        
        if(resultOnMap.status === true){ 
            setMapState((prevState: TStates) => {
                prevState.propertieslatlng = resultOnMap.data;
                prevState.apiCallName = "searchPropertiesOnMap";
                return({
                ...prevState
                })
            });
        }else{
            console.error(resultOnMap.message);
        }
    }
    /*
    * Function for getting 
    * @return void
    */
    const PropertiesListOnMap = async () =>{        
        const result = await searchPropertiesListOnMap(0,mapstate.noOfPropertiesOnPage);
        if(result.status === true){
            const noofpage = result.data.total/mapstate.noOfPropertiesOnPage;
            // this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"searchPropertiesListOnMap"});            
            setMapState((prevState: TStates) => {
                prevState.properties = result.data.result;
                prevState.pageCount = noofpage;
                prevState.apiCallName = "searchPropertiesListOnMap";
                return({
                ...prevState
                })
            });
        }else{
            console.error(result.message);
        }
    }

    const getPropertiesId = async (ids: number[]) =>{   
        // this.setState({"selectedPage": 0});     
        const result = await propertiesOfClusterOnMap(ids, 0, mapstate.noOfPropertiesOnPage);
        if(result.status === true){
            const noofpage = ids.length/mapstate.noOfPropertiesOnPage;
            // this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"propertiesOfClusterOnMap", "ids": ids});
        }else{
            console.error(result.message);
        }
    }

    const getPropertiesPolygon = async (coordinatesArray: any) =>{
        // Router.push({
        //     pathname: '/search-on-map',
        //     query: { polygonData: coordinatesArray },
        // });
        router.push('/search-on-map?polygonData='+coordinatesArray,'/search-on-map?polygonData='+coordinatesArray, { shallow: true });
        // let coordinatePoints: { "lat": string, "lon": string }[] = [];
        // coordinatesArray.map((point: TPointsPolygon)=>{
        //    const lat = point.lat();
        //    const long = point.lng();
        //    const coordPoint: { "lat": string, "lon": string } = { "lat": lat, "lon": long };
        //    coordinatePoints.push(coordPoint);
        // });
        // const resultOnMap = await propertiesInPolygonOnMap(coordinatePoints);
        // if(resultOnMap.status === true){
        //     // console.log(resultOnMap.data.result);
        //     let resultLatlong = resultOnMap.data.result.map((property: any)=>{
        //         let prop = property._source;
        //         const id = property._source.id;
        //         const lat =  property._source.location.lat;
        //         const lng =  property._source.location.lon;
        //         prop = {id:id,propertyLocation:{"latitude": lat,"longitude": lng}};
        //         property._source = prop;
        //         return property;
        //     });
        //     console.log(resultLatlong);
        //     this.setState({"propertieslatlng": resultLatlong});
        //     // this.setState({"propertieslatlng": resultOnMap.data.result});
        // }else{
        //     console.error(resultOnMap.message);
        // }
        // const result = await propertiesListInPolygonOnMap(coordinatePoints, 0, this.state.noOfPropertiesOnPage);
        // if(result.status === true){
        //     console.log(result.data.total);
        //     const noofpage = result.data.total/this.state.noOfPropertiesOnPage;
        //     this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"propertiesInPolygonOnMap", "coordinatePoints": coordinatePoints});
        // }else{
        //     console.error(result.message);
        // }
    }

    const handlePageClick = async (data: any) =>{
        const from = (data.selected * mapstate.noOfPropertiesOnPage);
        // this.setState({"selectedPage": data.selected});
        if(mapstate.apiCallName == 'propertiesOfClusterOnMap'){
            const ids = mapstate.ids;
            const result = await propertiesOfClusterOnMap(ids, from, mapstate.noOfPropertiesOnPage);
            if(result.status === true){
                const noofpage = ids.length/mapstate.noOfPropertiesOnPage;
                // this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"propertiesOfClusterOnMap"});
            }else{
                console.error(result.message);
            }
        } else if(mapstate.apiCallName == 'searchPropertiesListOnMap') {
            const result = await searchPropertiesListOnMap(from,mapstate.noOfPropertiesOnPage);
            if(result.status === true){
                const noofpage = result.data.total/mapstate.noOfPropertiesOnPage;
                // this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"searchPropertiesListOnMap"});
            }else{
                console.error(result.message);
            }
        } else {
            const coordinatePoints = mapstate.coordinatePoints;
            const result = await propertiesListInPolygonOnMap(coordinatePoints, from, mapstate.noOfPropertiesOnPage);
            if(result.status === true){
                // console.log(result.data.total);
                const noofpage = result.data.total / mapstate.noOfPropertiesOnPage;
                // this.setState({"properties": result.data.result,"pageCount":noofpage,"apiCallName":"propertiesInPolygonOnMap"});
            }else{
                console.error(result.message);
            }
        }
    }

    /**
     * Render the page
     */
    // render() {
        
        const { t } = props;
        let center: any = {lat: -28.024, lng: 140.887};
        const zoom = 5;
        let places: any = [];
        let propertyJson: {id: number, lat: number, lng: number};
        let properties: TPSource[] = [];

        if(mapstate.propertieslatlng){
            mapstate.propertieslatlng.map((property, index)=>{
                if(index == 0) {
                    center = {
                                lat: property._source.propertyLocation.latitude,
                                lng: property._source.propertyLocation.longitude
                             }
                }
                propertyJson = {
                                id: property._source.id, 
                                lat: property._source.propertyLocation.latitude,
                                lng: property._source.propertyLocation.longitude
                               };
                
                places.push(propertyJson);
            });
        }
        if(mapstate.properties){
            mapstate.properties.map((property: any)=>{
                properties.push(property);
            });
        }    

        // console.log(mapstate);
        return (
            <Layout title="Map View"> 
                <div style={{padding: "80px 0 30px"}}>
                    {/* Show properties list component */}
                    <MapPropertiesList properties={properties}></MapPropertiesList>
                    {/* Show map component */}
                    <ShowMap 
                        center={center} 
                        zoom={zoom} 
                        places={places} 
                        polygonData={polygonDataArray}
                        getPropertiesId={(ids: number[])=>{getPropertiesId(ids)}}
                        getPropertiesPolygon={(coordinatesArray: [])=>{getPropertiesPolygon(coordinatesArray)}}
                    ></ShowMap>
                    <div style={{"width": "100%", "height": "100vh", "float": "left", "paddingLeft": "50%"}}>
                    <ReactPaginate
                        previousLabel={'previous'}
                        nextLabel={'next'}
                        breakLabel={'...'}
                        pageCount={mapstate.pageCount}
                        marginPagesDisplayed={2}
                        pageRangeDisplayed={5}
                        onPageChange={handlePageClick}
                        breakClassName={'page-item'}
                        breakLinkClassName={'page-link'}
                        containerClassName={'pagination'}
                        pageClassName={'page-item'}
                        pageLinkClassName={'page-link'}
                        previousClassName={'page-item'}
                        previousLinkClassName={'page-link'}
                        nextClassName={'page-item'}
                        nextLinkClassName={'page-link'}
                        activeClassName={'active'}
                        forcePage={mapstate.selectedPage}
                        />
                    </div>
                    
                </div>                
            </Layout>
        )
    // }
}

export default withRouter(SearchOnMapPage);