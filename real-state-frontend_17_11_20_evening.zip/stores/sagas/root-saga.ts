import { all } from "redux-saga/effects";

import TranslationSaga from "./translation-saga";
import SearchSaga from "./search-saga";

function* rootSaga() {
  yield all([...TranslationSaga, SearchSaga]);
}

export default rootSaga;
