/**
 * Elastic query body for getting recommended properties in KSA
 */
export const EQRecommendedPropertyFORKSA = {
  from: 0,
  size: 3,
  _source: [
    "id",
    "slug",
    "en.title",
    "en.country",
    "en.zone",
    "en.city",
    "en.unitType",
    "en.currencyType",
    "en.propertyMainType",
    "ar.title",
    "ar.country",
    "ar.zone",
    "ar.city",
    "ar.unitType",
    "ar.currencyType",
    "ar.propertyMainType",
    "attribute.noOfBedrooms",
    "attribute.noOfBathrooms",
    "attribute.builtUpArea",
    "attribute.salePrice",
    "propertyOwner.phone",
    "propertyOwner.email",
    "propertyOwner.whatsApp",
    "propertyOwner.comapnyLogo",
    "searchCriteria.countryId",
    "searchCriteria.cityId",
    "searchCriteria.zoneId",
    "searchCriteria.propertyMainTypeId",
    "searchCriteria.propertyForId",
    "propertyFiles.mainImages",
    "isGreatPrice",
  ],
  query: {
    bool: {
      must: [
        {
          match: {
            isRecommended: true,
          },
        },
        {
          match: {
            "searchCriteria.propertyRegionId": 56,
          },
        },
      ],
    },
  },
  sort: [
    {
      publishedAt: {
        order: "desc",
      },
    },
  ],
};

/**
 * Elastic query body for getting recommended properties in International
 */
export const EQRecommendedPropertyFORInternational = {
  from: 0,
  size: 3,
  _source: [
    "id",
    "slug",
    "en.title",
    "en.country",
    "en.zone",
    "en.city",
    "en.unitType",
    "en.currencyType",
    "en.propertyMainType",
    "ar.title",
    "ar.country",
    "ar.zone",
    "ar.city",
    "ar.unitType",
    "ar.currencyType",
    "ar.propertyMainType",
    "attribute.noOfBedrooms",
    "attribute.noOfBathrooms",
    "attribute.builtUpArea",
    "attribute.salePrice",
    "propertyOwner.phone",
    "propertyOwner.email",
    "propertyOwner.whatsApp",
    "propertyOwner.comapnyLogo",
    "searchCriteria.countryId",
    "searchCriteria.cityId",
    "searchCriteria.zoneId",
    "searchCriteria.propertyMainTypeId",
    "searchCriteria.propertyForId",
    "propertyFiles.mainImages",
    "isGreatPrice",
  ],
  query: {
    bool: {
      must: [
        {
          match: {
            isRecommended: true,
          },
        },
        {
          match: {
            "searchCriteria.propertyRegionId": 57,
          },
        },
      ],
    },
  },
  sort: [
    {
      publishedAt: {
        order: "desc",
      },
    },
  ],
};


/**
 * Elastic query body for getting recommended properties in International
 */
export const EQSearchPropertyList = {
  from: 0,
  size: 20,
  _source: [
    "id",
    "slug",
    "en.title",
    "en.country",
    "en.address",
    "en.zone",
    "en.city",
    "en.unitType",
    "en.currencyType",
    "en.propertyMainType",
    "ar.title",
    "ar.country",
    "ar.address",
    "ar.zone",
    "ar.city",
    "ar.unitType",
    "ar.currencyType",
    "ar.propertyMainType",
    "attribute.noOfBedrooms",
    "attribute.noOfBathrooms",
    "attribute.builtUpArea",
    "attribute.salePrice",
    "propertyOwner.phone",
    "propertyOwner.email",
    "propertyOwner.whatsApp",
    "propertyOwner.comapnyLogo",
    "searchCriteria.countryId",
    "searchCriteria.cityId",
    "searchCriteria.zoneId",
    "searchCriteria.propertyMainTypeId",
    "searchCriteria.propertyForId",
    "propertyFiles.mainImages",
    "isGreatPrice",
  ],
  query: {
    bool: {
      must: [],
    },
  },
  sort: [
    {
      publishedAt: {
        order: "desc",
      },
    },
  ],
};
