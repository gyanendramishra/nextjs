import React from "react";
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, FormikHelpers } from "formik";

/**
 * Import services, types and utils
 */

import { TFilter, TMaster } from "../../types";
import { EPropertyFor, EPropertyType } from "../../utils";
import { beadroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import PropertyType from "@/components/search/property-type";
import MinMaxPicker from "@/components/search/min-max-picker";
import Autocomplete from "@/components/search/autocomplete";

type TProps = {
    styles: TStyle;
    masters: TMaster;
    filters: TFilter;
    changePropertyFor: Function;
    toggleAdvanceSearch: Function;
};

type TStyle = {
    readonly [key: string]: string;
}

const MainSearchWebForm = (props:TProps) => {

    const {
        styles, 
        filters,
        masters, 
        changePropertyFor,
        toggleAdvanceSearch
    } = props;
    const { t } = useTranslation();
    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    const onHandleSearch = (formData:TFilter):void => {
        //formData.propertyFor = filters.propertyFor;
        //alert(JSON.stringify(formData, null, 2));
        console.log(formData);
    }

    return (
        <Formik
            initialValues={filters}
            onSubmit={async (
                values: TFilter,
                {
                    setSubmitting,
                }: FormikHelpers<TFilter>
            ) => {
                console.log(values);
                await onHandleSearch(values);
                setSubmitting(false);
            }}
        >
            {() => (
                <Form>
                    <div className={styles.search_category_nav}>
                        <ul className="d-flex">
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.SALE ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.SALE)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.FOR_SALE")}
                                </a>
                            </li>
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.RENT ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.RENT)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.FOR_RENT")}
                                </a>
                            </li>
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.INTERNATIONL)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.INTERNATIONAL")}
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div className={(filters.for === EPropertyFor.INTERNATIONL) ? styles.search_inner+" "+styles.international_col: styles.search_inner}>
                        <div className={styles.select_block}>
                            <Field
                                as="select"
                                name="type_"
                                className={styles.form_control}
                            >
                                <option value={EPropertyType.RESIDENTIAL}>
                                    {t("MAIN_SEARCH.SEARCH_TYPE.RESIDENTIAL")}
                                </option>
                                <option value={ EPropertyType.COMMERCIAL }>
                                    {t("MAIN_SEARCH.SEARCH_TYPE.COMMERCIAL")}
                                </option>
                            </Field>
                        </div>
                        {(filters.for === EPropertyFor.INTERNATIONL) && (
                            <div className={`${styles.select_block} ${styles.country_col}`}>
                                <Field
                                    as="select"
                                    name="country"
                                    className={styles.form_control}
                                >
                                    <option value="">{t("MAIN_SEARCH.LABELS.COUNTRY")}</option>
                                    {masters.countries.map((country, index: number) => {
                                        return (
                                            <option value={country.id} key={index}>
                                                {country.name}
                                            </option>
                                        );
                                    })}
                                </Field>
                            </div>
                        )}
                        <div className={styles.search_field}>
                            {/* Auto complete */}
                            <Autocomplete 
                                name="locations"
                            ></Autocomplete>         
                        </div>
                        <div className={styles.search_btn}>
                            <button type="submit" className={styles.find_btn}>
                                {t("MAIN_SEARCH.LABELS.FIND")}
                            </button>
                        </div>
                    </div>
                    <div className={styles.srch1}>
                        { (filters.advanceSearch === true) && (
                            <div className={styles.adv_block}>
                                <div className={styles.adv_row}>
                                    <div className={styles.adv_col1}>
                                        <PropertyType
                                            name="sub_type"
                                            lable = { t("MAIN_SEARCH.LABELS.PROPERTY_TYPE")}
                                            category = { filters.type }
                                            styles = { styles }
                                        ></PropertyType>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <Field 
                                            as="select" 
                                            className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                            name="beadrooms" 
                                        >
                                            <option value="">{ t("MAIN_SEARCH.LABELS.BEDS") }</option>
                                            { beadroomList.map((option, index) => {
                                                return (
                                                    <option key={index} value={ option }>{ option }</option>
                                                );
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col1}>
                                        <Field 
                                            as="select" 
                                            className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                            name="bathrooms" 
                                        >
                                            <option value="">{ t("MAIN_SEARCH.LABELS.BATHS") }</option>
                                            { bathroomList.map((option, index) => {
                                                return (
                                                    <option key={index} value={ option }>{ option }</option>
                                                );
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.adv_col2}>
                                        <MinMaxPicker 
                                            name="price"
                                            label={ t("MAIN_SEARCH.LABELS.PRICE") }
                                            options={ priceList }
                                            styles={styles}
                                        ></MinMaxPicker>
                                    </div>
                                    <div className={styles.adv_col2}>
                                        <MinMaxPicker 
                                            name="size"
                                            label={ t("MAIN_SEARCH.LABELS.SIZE") }
                                            options={ sizeList }
                                            styles={styles}
                                        ></MinMaxPicker>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div className={styles.srch1_inr}>
                            <a className={styles.left_link} href="#">
                                <i className="icon-pin"></i> { t("MAIN_SEARCH.LABELS.SEARCH_ON_MAP") }
                            </a>
                            <a className={`${styles.right_link} ${styles.desktop_link}`} onClick={()=> toggleAdvanceSearch()}>
                                <i className="icon-levels"></i>{filters.advanceSearch ? t("MAIN_SEARCH.LABELS.CLOSE_ADVANCED_SEARCH") : t("MAIN_SEARCH.LABELS.ADVANCED_SEARCH")}
                            </a>
                        </div>
                    </div>
                </Form>
            )}
        </Formik>
    );
}

export default MainSearchWebForm;

