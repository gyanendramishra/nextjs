import React, { useState, useLayoutEffect } from "react";
import { connect } from 'react-redux';
import { useTranslation } from 'react-i18next';

/**
 * Import services, types and utils
 */
import { TFilter, TMaster, TSSearch  } from "../../types";
import { EPropertyType  } from "../../utils";

/**
 * Import page components
 */
import LocationSearch from "@/components/search/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";

import { forFilterChanged } from "../../stores/actions";

/**
 * Component styles
 */
import styles from "../../styles/search/main-search.module.scss";

type TProps = {
    storeFilters: TSSearch;
    searchElements: TMaster;
    dispatchForFilter: Function;
};

const MainSearch = (props:TProps) => {
    const {
        storeFilters, 
        searchElements,
        dispatchForFilter
    } = props;

    const { t } = useTranslation();
    const [isMobile, setIsMobile] = useState<boolean>(false);
    const [filters, setFilters] = useState<TFilter>({
        advanceSearch: false,
        for: storeFilters.for,
        type: EPropertyType.RESIDENTIAL,
        sub_type: "",
        locations: [],
        country : null,
        beadrooms : null,
        bathrooms : null,
        price: null,
        size: null,
    });

    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = async (): Promise<void> => {
        if (filters.advanceSearch === true) {
            setFilters((prevState) => {
                prevState.advanceSearch = false;
                return({
                  ...prevState
                })
              }
            );
        } else {
            setFilters((prevState) => {
                prevState.advanceSearch = true;
                return({
                  ...prevState
                })
              }
            );
        }
    };

    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = async (propertyFor: string):Promise<void> => {
        await dispatchForFilter(propertyFor);
        setFilters((prevState) => {
            prevState.for = propertyFor;
            return({
              ...prevState
            })
          }
        );
    };

    /**
     * Seach component
     */
    let searchComponent;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                changePropertyFor = { changePropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                changePropertyFor = { changePropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        )
    }

    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("MAIN_SEARCH.LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    { searchComponent }
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ searchElements.categories }
                    propertyFor={ filters.for }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

const mapDispatchToProps = (dispatch: any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor))
});

const mapStateToProps = (state: any) => ({
    storeFilters:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(MainSearch);
