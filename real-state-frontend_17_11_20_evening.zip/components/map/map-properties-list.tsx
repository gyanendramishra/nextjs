import React from "react";

/**
 * Import components
 */
import PropertyItem from "@/components/property/item";
import { Property } from '../../classes/property';
import {  TPSource } from '../../classes/search-property';

type TProps = {
    properties: TPSource[];
}

type TStates = {
    // properties:TPSource[]
}

export class MapPropertiesList extends React.Component<TProps, TStates> {
    /**
     * Create new component instance
     * @return void
     */
    constructor(props: TProps) {
        super(props);        
    }
    
    /**
     * Render the page
     */
    render() {
        const { properties } = this.props;
        const no_of_properties = properties.length;
        console.log(properties.length);
        if(typeof properties !== 'undefined' && properties.length > 0){
            return (<div style={{width: "50%", height:"100vh", float: "left"}}>
                <div>
                    <h2>Properties for sales in</h2>
                    <span>{no_of_properties} results</span>
                </div>
                <div className="row">
                {properties.map((property: any, index: number) => {
                    const rProperty = new Property(property, "en");
                    return (
                        <div className="col-md-6">
                            <PropertyItem
                                key={index}
                                property={rProperty}>
                            </PropertyItem>
                        </div>
                    );
                })}</div></div>
            );
        } else {
            return (<div>List not load</div>);
        }
    }
}


export default MapPropertiesList;