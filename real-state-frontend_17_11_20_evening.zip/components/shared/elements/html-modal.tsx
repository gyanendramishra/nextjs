import React, { useState } from "react";
import PropTypes from "prop-types";

/**
 * component styles
 */
//import styles from '../../../styles/shared/footer.module.scss';

type TProps =  {
    readonly opened : boolean;
    readonly title: string;
}


const HtmlModal = (props: TProps) => {
    const { title } = props;
    const [opened, setOpened] = useState<boolean>(props.opened)
    

    /**
     * Close the modal
     * @return void
     */
    const closeModal =  (): void => {
        setOpened(false);
    }

    /**
     * Render the component html
     * @return mix
     */

    return (
        <>
            {(opened === true) &&
                <div className="modal">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{ title }</h5>
                                <button type="button" className="close" onClick={ closeModal }>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-primary">Save changes</button>
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            }
        </>
    );
}

/**
 * Validate prop types
 */
HtmlModal.propTypes = {
    opened: PropTypes.bool.isRequired,
    title: PropTypes.string.isRequired
};

export default HtmlModal;
