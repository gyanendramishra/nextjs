import React, { Component } from "react";
import styles from '../../styles/listing/search-filter.module.scss';
// import Autocomplete2 from '../autocomplete2';
// import Autocomplete3 from '../autocomplete3';


export default class SearchFilter extends Component {
  render() {
    return (
      <div className={styles.search_filter_outer}>

      {/* Desktop Search Filter */}

       <div className={styles.search_filter}>
       <div className={styles.container}>
         <div className={`${styles.adv_row} ${styles.mbl_row}`}>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>For Sale</option>
                 <option>For Rent</option>
                 <option>International</option>
               </select>
           </div>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>Residential</option>
                 <option>Commercial</option>
               </select>
           </div>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
               </select>
             </div>
            <div className={styles.adv_col1}>
              <select className={styles.form_control}>
                <option>Beds</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5+</option>
              </select>
            </div>
            <div className={styles.adv_col1}>
              <select className={styles.form_control}>
                <option>Baths</option>
              </select>
            </div>
            <div className={styles.adv_col2}>
               <div className={`${styles.form_control} ${styles.click_btn1}`}>
                 <label className={styles.lbl}>Price</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box1}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
         </div>
         <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
         <div className={styles.adv_col2}>
                <div className={`${styles.form_control} ${styles.click_btn2}`}>
                 <label className={styles.lbl}>Size</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box2}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
         <div className={styles.adv_col3}>
         {/* <Autocomplete2></Autocomplete2> */}
         </div>
         <div className={styles.adv_col4}>
           <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button>
           <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
         </div>
         </div>
       </div>
    </div>
      
      {/* Desktop Search Filter */}



      {/* Mobile Popup Search Filter */}

       <div className={styles.search_mobile_block_outer}>
       <div className={styles.search_category_nav}>
          <ul className="d-flex">
            <li><a className={styles.active}>For Sale</a></li>
            <li><a>For Rent</a></li>
            <li><a>International</a></li>
          </ul>
          </div>
         

       {/* FOR SALE SECTION */}
          <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>


 {/* FOR RENT SECTION */}
 <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>


 {/* INTERNATIONAL SECTION */}
 <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>

       </div>
    
      {/* Mobile Popup Search Filter */}
      </div>
   );
}
}
