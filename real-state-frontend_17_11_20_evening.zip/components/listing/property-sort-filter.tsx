import React from "react";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";
import PropTypes from "prop-types";

import styles from '../../styles/listing/property-sort-filter.module.scss';

/**
 * Import component types
 */
// import { TTranslation } from "../../types";

interface States {
  itemView:boolean;
}

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction,
    sortSearch:Function;
    getView:Function;
    totalCount:number;
    forType:string;
}

class PropertySortFilter extends React.Component<Props,States> {
    constructor(props: Props) {
        super(props);
        this.state={itemView:true}
    }

      /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["common"],
        };
    }

     /**
     * Get SortingValue
     * @return response
     */

    getSortingValue=(value:string)=>{

        this.props.sortSearch(value);

    }

     /**
     * set boolean value for grid and list
     * @return response
     */

    itemView = (viewStatus:boolean)=>{
      this.setState({itemView:viewStatus})
      this.props.getView(viewStatus)
      
    }
    
  render() {
    const {t,totalCount,forType}=this.props;
    const {itemView}=this.state;
    return (
     <div className={styles.property_sort_filter}>
       <div className={styles.container}>
        <div className="row">
          <div className="col-md-8">
            <div className={styles.sort_lt}>
            <div className={styles.hd_block2}>
            <h2>Properties {forType} in Saudi Arabia</h2>
            <p>{totalCount>0?totalCount:0} results</p>
            </div>
            <div className={styles.rt_filter}>
              <div className={styles.rt_col1}>
                <select className={styles.form_control} name="sortSearch" onChange={(e)=>{this.getSortingValue(e.target.value)}}>
                    <option value="relevence">{ t("SEARCH_SORT.RELEVANCE") }</option>
                    <option value="isExclusive">{ t("SEARCH_SORT.EXCLUSIVE") }</option>
                    <option value="asc">{ t("SEARCH_SORT.LOW_TO_HIGH") }</option>
                    <option value="desc">{ t("SEARCH_SORT.HIGH_TO_LOW") }</option>
                </select>
              </div>
              <div className={styles.rt_col1}>
                <a className={styles.form_control}><i className="icon-pin"></i> View On map</a>
              </div>
              <div className={styles.rt_col2}>
                <a className={itemView?`${styles.grid_btn} `:`${styles.grid_btn} ${styles.active}`} onClick={()=>{this.itemView(false)}} href="#">Grid</a>
              </div>
              <div className={styles.rt_col2}>
              <a className={itemView?`${styles.list_btn} ${styles.active}`:`${styles.list_btn}`} onClick={()=>{this.itemView(true)}} href="#">List</a>
              </div>
            </div>
            </div>
          </div>
         </div>
       </div>
     </div>
    );
  }
}

export default withTranslation("main-search")(PropertySortFilter);