import React, { useState } from "react";
import { useRouter } from "next/router";
import { useTranslation } from 'react-i18next';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Navigation, Scrollbar } from 'swiper';

SwiperCore.use([Navigation, Pagination, Scrollbar]);

/**
 * Import components
 */
import PropertyItem from "@/components/property/item";
import FrameModal from "@/components/shared/elements/frame-modal";

/**
 * import clases, services types and utills
 */
import { TPSource } from '../../types';
import { Property } from '../../classes/property';

/**
 * component styles
 */
import styles from '../../styles/home/recommended-properties-ksa.module.scss';


type TProps = {
    properties : Array<TPSource>;
};

type TModal = {
    opened: boolean;
    title?: string;
    src?: string;
}

const RecommendedPropertiesKSA = (props: TProps) => {
    
    const { locale } = useRouter();
    const { t } = useTranslation();
    const { properties } = props;

    const [modal, setModal] = useState<TModal>({
        opened: false,
        title: "",
        src: ""
    });

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const populateVideo = (src: string): void => {
        setModal((prevState) => {
            prevState.opened = true;
            prevState.title = t("RECOMMENDED_PROPERTY.VIDEO_MODAL_TITLE");
            prevState.src = src;
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Handle modal on close
     * @param src: string
     * @return void
     */
    const handleModelClose = (): void => {
        setModal((prevState) => {
            prevState.opened = false;
            prevState.title = "";
            prevState.src = "";
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Render the template
     * 
     * @return mix html
     */
    
    return (
        <div className={styles.home_section1}>
            <div className={styles.container}>
                <h2 className="text-center">{ t("RECOMMENDED_PROPERTY.TITLE_KSA") }</h2>
                <div className="row">
                    <Swiper
                            navigation
                            pagination
                            scrollbar={{ 
                                draggable: true, hide: true 
                            }}
                            breakpoints={{
                                640: {
                                  width: 640,
                                  slidesPerView: 1,
                                },
                                768: {
                                  width: 768,
                                  slidesPerView: 2,
                                },
                                1024: {
                                    width: 1024,
                                    slidesPerView: 3,
                                    pagination: false
                                },
                            }}
                        >
                        {properties.map((property:TPSource, index:number) => {
                            const rProperty = new Property(property, locale);
                            return (
                                <SwiperSlide key={index}>
                                    <div className="col-md-4">
                                        <PropertyItem
                                            property={rProperty}
                                            handleVideo={populateVideo}
                                        ></PropertyItem>
                                    </div>
                                </SwiperSlide>
                            )
                        })}
                    </Swiper>
                </div>
            </div>
            <FrameModal 
                title={ modal.title }
                opened={ modal.opened }
                src={ modal.src }
                onModalClose = { handleModelClose}
            ></FrameModal>
        </div>
    );
}

export default RecommendedPropertiesKSA;
