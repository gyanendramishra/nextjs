import React from "react";
import * as Yup from "yup";
import PropTypes from "prop-types";
import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { Formik, Form, Field, FormikHelpers } from "formik";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { mainSearchElements, propertyTypes } from "../../services";
import { EPropertyFor, EPropertyType } from "../../utils";
import { TTranslation, TCountry, TCategory, TPropertyType } from "../../types";
import { forFilterChanged, typeFilterChanged } from '../../stores/actions';
import { beadroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import LocationSearch from "@/components/home/location-search";
import Autocomplete from "@/components/search/autocomplete";
import MinMaxPicker from "@/components/search/min-max-picker";

/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    translation: TTranslation;
    filters: TFilter;    
}

interface States {
    advanceSearch:boolean;
    masters: TMaster;
    filter: TFilter;
    propertyTypes: TPropertyType[];
}

type TFilter = {
    for: string;
    type: string;
    locations: string | null;
    category: number | null;
    country: number | null;
    sub_type: string | null;
    beadrooms : number | null;
    bathrooms : number | null;
    minPrice: number | null;
    maxPrice: number | null;
    minSize: number | null;
};

type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};


export class SearchProperties extends React.Component<Props, States> {
    /**
     * New component instance
     */
    constructor(props: Props) {
        super(props);
        this.state = {
            advanceSearch: false,
            masters: {
                categories: [],
                countries: [],
            },
            filter: {
                for: EPropertyFor.SALE,
                type: EPropertyType.COMMERCIAL,
                location: null,
                category : null,
                country : null,
                sub_type: null,
                beadrooms : null,
                bathrooms : null,
                minPrice: null,
                maxPrice: null,
                minSize: null,
            },
            propertyTypes:[]
        };
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Toggle advance search
     * @return void
     */
    public toggleAdvanceSearch = (): void => {
        const { advanceSearch } = this.state;
        if (advanceSearch === true) {
            this.setState({
                ...this.state,
                advanceSearch: false
            });
        } else {
            this.setState({
                ...this.state,
                advanceSearch: true
            });
        }
        
    };

    /**
     * Switch property for
     * @param propertyFor: string
     * @return void
     */
    public switchPropertyFor = (propertyFor: string): void => {
        const { filter } = this.state;
        filter.for = propertyFor;
        this.setState({
            ...this.state,
            filter: filter
        });
        //this.props.forFilterChanged(propertyFor);
    };

    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    public onHandleSearch = async (formData: TFilter) => {
        alert(JSON.stringify(formData, null, 2));
    };

    /**
     * Prepare form validation schema
     * @param t: TFunction
     * @return Yup.object
     */
    public validationSchema = (t: TFunction) => {
        // return Yup.object().shape({
        //     locations: Yup.string().required(
        //         t("validations:REQUIRED", { attribute: t("FORM.LABELS.LOCATIONS") })
        //     ),
        // });
    };

    /**
     * Get the search masters
     * @return void
     */
    getMainSearchElements = async () : Promise<void> => {
        const { translation } = this.props;
        const result = await mainSearchElements(translation.language);
        if(result.status === true){
            this.setState({ masters: result.data });
        }else{
            console.error(result.message);
        }
    };

    /**
     * Get the search masters
     * @return void
     */
    getPropertyTypes = async (type: string) : Promise<void> => {
        const { translation } = this.props;
        const result = await propertyTypes(translation.language, type);
            if(result.status === true){
                this.setState({ propertyTypes: result.data });
            }else{
                console.error(result.message);
            }
    };

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = async () => {
        await this.getMainSearchElements();
    };

    /**
     * Triggers on prop change
     * @return void
     */
    componentDidUpdate = async (prevProps: Props) => {
        const { translation } = this.props;
        if(translation.language != prevProps.translation.language){
            await this.getMainSearchElements();
        }
    } 

    /**
     * Triggers when component is failed
     * @return void
     */
    componentDidCatch = () => {
        console.error("Opps somthing went wrong. Search component not rendered.");
    };

    render() {
        const { t } = this.props;
        const { advanceSearch, filter, masters, propertyTypes } = this.state;
        const { countries, categories } = masters;
        return (
        <div className={styles.search_outer}>
            <div className={styles.container}>
                <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    <Formik
                        initialValues={filter}
                        onSubmit={async (
                            values: TFilter,
                            {
                                setSubmitting,
                            }: FormikHelpers<TFilter>
                        ) => {
                            console.log(values);
                            await this.onHandleSearch(values);
                            setSubmitting(false);
                        }}
                    >
                        <Form>
                            <div className={styles.search_category_nav}>
                                <ul className="d-flex">
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.SALE ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.SALE)}
                                        >
                                            {t("SEARCH_FOR.FOR_SALE")}
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.RENT ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.RENT)}
                                        >
                                            {t("SEARCH_FOR.FOR_RENT")}
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.INTERNATIONL)}
                                        >
                                            {t("SEARCH_FOR.INTERNATIONAL")}
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className={styles.dis_block}>
                                <div className={(filter.for === EPropertyFor.INTERNATIONL) ? styles.search_inner+" "+styles.international_col: styles.search_inner}>
                                    <div className={styles.select_block}>
                                        <Field
                                            as="select"
                                            name="type"
                                            className={styles.form_control}
                                        >
                                            <option value={EPropertyType.RESIDENTIAL}>
                                                {t("SEARCH_TYPE.RESIDENTIAL")}
                                            </option>
                                            <option value={ EPropertyType.COMMERCIAL }>
                                                {t("SEARCH_TYPE.COMMERCIAL")}
                                            </option>
                                        </Field>
                                    </div>
                                    {(filter.for === EPropertyFor.INTERNATIONL) && (
                                        <div className={`${styles.select_block} ${styles.country_col}`}>
                                            <Field
                                                as="select"
                                                name="country"
                                                className={styles.form_control}
                                            >
                                                {countries.map((country: TCountry, index: number) => {
                                                    return (
                                                        <option value={country.id} key={index}>
                                                            {country.name}
                                                        </option>
                                                    );
                                                })}
                                            </Field>
                                        </div>
                                    )}
                                    <div className={styles.search_field}>
                                        {/* Auto complete */}
                                        <Autocomplete name="location" />              
                                    </div>
                                    <div className={styles.search_btn}>
                                        <button type="submit" className={styles.find_btn}>
                                            {t("LABELS.FIND")}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.srch1}>
                                { (advanceSearch === true) && (
                                    <div className={styles.adv_block}>
                                        <a className={styles.cls_btn3}>
                                            <img src="/images/close.svg" alt=""/>
                                        </a>
                                        <div className={styles.adv_row}>
                                            <div className={styles.adv_col1}>
                                                <Field as="select" className={styles.form_control} name="sub_type">
                                                    <option>{ t("LABELS.PROPERTY_TYPE") }</option>
                                                    { propertyTypes.map((propertyType, index)=>{
                                                        return(
                                                            <option value={propertyType.id} key={index}>{propertyType.name}</option>
                                                        )
                                                    })}
                                                </Field>
                                            </div>
                                            <div className={styles.adv_col1}>
                                                <Field as="select" className={styles.form_control} name="beadrooms">
                                                    <option value="">{ t("LABELS.BEDS") }</option>
                                                    { beadroomList.map((option, index) => {
                                                        return (
                                                            <option key={index} value={ option }>{ option }</option>
                                                        );
                                                    })}
                                                </Field>
                                            </div>
                                            <div className={styles.adv_col1}>
                                                <Field as="select" className={styles.form_control} name="bathrooms">
                                                    <option value="">{ t("LABELS.BATHS") }</option>
                                                    { bathroomList.map((option, index) => {
                                                        return (
                                                            <option key={index} value={ option }>{ option }</option>
                                                        );
                                                    })}
                                                </Field>
                                            </div>
                                            <div className={styles.adv_col2}>
                                                <MinMaxPicker 
                                                    label={ t("LABELS.PRICE") }
                                                    options={ priceList }
                                                ></MinMaxPicker>
                                            </div>
                                            <div className={styles.adv_col2}>
                                                <MinMaxPicker 
                                                    label={ t("LABELS.SIZE") }
                                                    options={ sizeList }
                                                ></MinMaxPicker>
                                            </div>
                                        </div>
                                    </div>
                                )}
                                <div className={styles.srch1_inr}>
                                    <a className={styles.left_link} href="#">
                                        <i className="icon-pin"></i> { t("LABELS.SEARCH_ON_MAP") }
                                    </a>
                                    <a className={styles.right_link} onClick={this.toggleAdvanceSearch}>
                                        <i className="icon-levels"></i>{advanceSearch ? t("LABELS.CLOSE_ADVANCED_SEARCH") : t("LABELS.ADVANCED_SEARCH")}
                                    </a>
                                </div>
                            </div>
                        </Form>
                    </Formik>
                    </div>
                    {/* Location search component */}
                    <LocationSearch 
                        categories={categories}
                        propertyFor={filter.for}
                    ></LocationSearch>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language,
        filters: state.filters
    }
});

const mapDispatchToProps = (dispatch: Dispatch) => {
    return {
        forFilterChanged: (propertyFor:string) => {
            dispatch(forFilterChanged(propertyFor));
        },
        typeFilterChanged: (propertyType:string) => {
            dispatch(typeFilterChanged(propertyType));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withTranslation("main-search")(SearchProperties));
