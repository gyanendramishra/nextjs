
export enum EPropertyFor {
  "SALE" = "SALE",
  "RENT" = "RENT",
  "INTERNATIONL" = "INTERNATIONL"
};

export enum EPropertyType {
  "COMMERCIAL" = "SALE",
  "RESIDENTIAL" = "RESIDENTIAL",
};

export enum EInternationalLables {
  "HIGH_INVESTMENT_RETURN" = "is_high_investment_return",
  "GREAT_PRICE" = "is_great_price",
  "FEATURED" = "is_featured",
};
