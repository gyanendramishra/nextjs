import { combineReducers } from "redux";
import { translationReducer, searchReducer } from "./";

const rootReducer = combineReducers({
  translation: translationReducer,
  filters: searchReducer,
});

export default rootReducer;
