export type TPropertyAttribute = {
  builtUpArea?: number;
  carpetArea?: number;
  superBuiltUpArea?: number;
  completionYear?: number;
  noOfBedrooms?: number;
  noOfBathrooms?: number;
  noOfFloors?: number;
  floorNumber?: number;
  capacityPerRoom?: number;
  campCapacity?: number;
  salePrice?: number;
  expectedRent?: number;
  rentCycle?: number;
  rentPerSqFeet?: number | null;
  securityDepositAmount?: number;
  monthlyChargeRange?: number;
  isRentNegotiable?: boolean;
  possessionDate?: number | null;
};

export type TPropertyFile = {
  mainImages?: [];
  interiorImages?: [];
  exteriorImages?: [];
  floorPlans?: [];
  documents?: [];
  brochures?: [];
};

export type TPropertyOwner = {
  phone?: number;
  whatsApp?: number;
  email?: string;
  comapnyLogo?: string;
};

export type TPropertyTranslation = {
  title: number;
  landmark?: number;
  address?: string;
  country?: string;
  state?: string;
  city?: string;
  zone?: string;
  description?: string;
};

export type TProperty = {
  id: number;
  darReference?: string;
  unitReference?: string;
  externalUrl?: string;
  externalVideoLink?: string;
  isSold?: boolean;
  isHotDeal?: boolean;
  isExclusive?: boolean;
  isFeatured?: boolean;
  isInspected?: boolean;
  isRecommended?: boolean;
  isHighInvestmentReturn?: boolean;
  isGreatPrice?: boolean;
  slug?: string;
  attribute?: TPropertyAttribute;
  propertyOwner?: TPropertyOwner;
  propertyFiles?: TPropertyFile;
  en?: TPropertyTranslation;
  ar?: TPropertyTranslation;
};

export type TPSource = {
  _id: number;
  _index: string;
  _score: number;
  _source: TProperty;
  _type: string;
};
