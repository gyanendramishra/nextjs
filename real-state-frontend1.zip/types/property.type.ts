/*
 * Property type
 */
export type TPropertyType = {
  id: number;
  name: string;
  slug: string;
}