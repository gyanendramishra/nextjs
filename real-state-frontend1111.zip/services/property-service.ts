import axios, { AxiosResponse } from "axios";
import { TResultSet, TFilter } from "../types";
import {
  EPagination,
  EPropertyFor,
  EPropertyType,
  EPropertySort,
  EQSearchProperty,
  EQRecommendedPropertyFORKSA,
  EQRecommendedPropertyFORInternational,
} from "../utils";

/**
 * Get the search masters
 * @return result: TResultSet
 */
export const getRecommendedKSAProperties = async (): Promise<TResultSet> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORKSA
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const getRecommendedInternationalProperties = async (): Promise<
  TResultSet
> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORInternational
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};

/**
 * Get filtered areas
 * @param locale
 * @return response
 */

export const getFilteredAreas = async (
  locale: string,
  type: string,
  category: number | null | undefined
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    let uri =
      type === EPropertyFor.SALE ? "cities-for-sale" : "cities-for-rent";
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/${uri}/${category}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the property search List
 * @return void
 */
export const getFilteredProperties = async (
  request: TFilter
): Promise<TResultSet> => {
  let result: TResultSet = {};
  const EQuery = EQSearchProperty;

  const qMust = [];
  const qSort = [];

  const qOmust = {
    query: {
      bool: {
        must: {},
      },
    },
  };
  const qOsort = {
    sort: {},
  };

  if (request.for) {
    qMust.push({
      match: {
        "searchCriteria.propertyForId":
          request.for === EPropertyFor.SALE ? 3 : 4,
      },
    });
  }
  if (request.type) {
    qMust.push({
      match: {
        "searchCriteria.propertyMainTypeId":
          request.type === EPropertyType.RESIDENTIAL ? 3 : 1,
      },
    });
  }
  if (request.sub_type) {
    qMust.push({
      match: {
        "searchCriteria.propertySubTypeId": request.sub_type,
      },
    });
  }
  if (request.bedrooms) {
    qMust.push({
      match: {
        "attribute.noOfBedrooms": request.bedrooms,
      },
    });
  }
  if (request.bathrooms) {
    qMust.push({
      match: {
        "attribute.noOfBathrooms": request.bathrooms,
      },
    });
  }

  if (request.locations) {
    request.locations.map((location: any) => {
      if (location.model == "country") {
        qMust.push({
          match: {
            "searchCriteria.countryId": location.model_id,
          },
        });
      }
      if (location.model == "city") {
        qMust.push({
          match: {
            "searchCriteria.cityId": location.model_id,
          },
        });
      }
      if (location.model == "zone") {
        qMust.push({
          match: {
            "searchCriteria.zoneId": location.model_id,
          },
        });
      }
    });
  }

  if (request.price) {
    if (request.size.min && request.size.max) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
            lte: request.price.max,
          },
        },
      });
    } else if (request.price.min) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
          },
        },
      });
    } else if (request.price.max) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            lte: request.price.max,
          },
        },
      });
    }
  }

  if (request.size) {
    if (request.size.min && request.size.max) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
            lte: request.size.max,
          },
        },
      });
    } else if (request.size.min) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
          },
        },
      });
    } else if (request.size.max) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            lte: request.size.max,
          },
        },
      });
    }
  }

  if (request.sort) {
    if (request.sort === EPropertySort.RELEVENCE) {
      qSort.push({
        publishedAt: {
          order: "asc",
        },
      });
    } else if (request.sort === EPropertySort.EXCLUSIVE) {
      qSort.push({
        isExclusive: {
          order: "desc",
        },
      });
    } else if (request.sort === EPropertySort.PRICE_LOW_TO_HIGH) {
      qSort.push({
        "attribute.salePrice": {
          order: "asc",
        },
      });
    } else if (request.sort === EPropertySort.PRICE_HIGH_TO_LOW) {
      qSort.push({
        "attribute.salePrice": {
          order: "desc",
        },
      });
    } else {
      qSort.push({
        publishedAt: {
          order: "desc",
        },
      });
    }
  }
  /*
   * there are match array assign
   */
  if (qMust.length > 0) {
    qOmust.query.bool.must = qMust;
    Object.assign(EQuery, qOmust);
  }

  if (qSort.length > 0) {
    qOsort.sort = qSort;
    Object.assign(EQuery, qOsort);
  }

  if (request.from && request.to) {
    EQuery.from = request.from;
    EQuery.size = request.to;
  } else {
    EQuery.from = 0;
    EQuery.size = EPagination.PER_PAGE_COUNT;
  }

  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQuery
    );
    const { hits, total } = response.data.hits;
    result.status = true;
    result.data = {
      result: hits,
      total: total.value,
    };
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};
