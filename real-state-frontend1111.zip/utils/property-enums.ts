export enum EPropertyFor {
  "SALE" = "sale",
  "RENT" = "rent",
  "INTERNATIONL" = "international",
}

export enum EPropertyType {
  "COMMERCIAL" = "commercial",
  "RESIDENTIAL" = "residential",
}

export enum EInternationalLables {
  "HIGH_INVESTMENT_RETURN" = "is_high_investment_return",
  "GREAT_PRICE" = "is_great_price",
  "FEATURED" = "is_featured",
}

export enum EPropertyDisplayMode {
  "LIST" = "LIST",
  "GRID" = "GRID",
}

export enum EPagination {
  "PER_PAGE_COUNT" = 2,
  "PAGINATION_LINK_COUNT" = 5,
  "INITIAL_PAGE" = 0,
}

export enum EPropertySort {
  "DATE_DESC" = "date_derscription",
  "RELEVENCE" = "relevence",
  "EXCLUSIVE" = "exclusive",
  "PRICE_HIGH_TO_LOW" = "price_high_to_low",
  "PRICE_LOW_TO_HIGH" = "price_low_to_high",
}
