import App from "next/app";
import { useEffect } from 'react'
import { useRouter } from "next/router";
import { useTranslation } from 'react-i18next';
import { wrapper } from "../stores";
import type { AppProps, AppContext } from "next/app";
import '../i18n';

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/icons.scss";
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';
import 'swiper/components/scrollbar/scrollbar.scss';
import "../styles/global/theme.scss";


const  MyApp = ({ Component, pageProps }: AppProps) => {
    const { i18n: { language } } = useTranslation();
    /**
     * Handle app lang
     * @return void
     */

    useEffect( () => {
        (async () => {
            const direction = (language === "en") ? "ltr" : "rtl";
            setDirection(direction, language );
        })();
    }, [language]);

    /**
     * Set app dircetion and language
     * @return void
    */
    const setDirection = (direction: string, language: string):void => {
        document.documentElement.dir = direction;
        document.documentElement.lang = language;
    }

    return <Component {...pageProps} />;
}


MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

export default wrapper.withRedux(MyApp);
