import React, { useState } from "react";
import { GetStaticProps } from 'next';
import { useRouter } from 'next/router';

/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import PropertyArea from "@/components/property/property-area";
import SearchFilter from "@/components/property/search-filter";
import PropertyListing from "@/components/property/property-listing";
import PropertySortFilter from "@/components/property/property-sort-filter";

/**
 * Import utill, classes, types and etc
 */
import { TFilter, TPSource, TCLocation } from "types";
import { EPropertyDisplayMode, EPropertyFor, EPropertyType, EPagination, EPropertySort } from "utils";
import { getFilteredProperties, getFilteredAreas } from "../../services";

type TProps = {
    initialProperties: Array<TPSource>;
    initialAreas: Array<TCLocation>;
}
const  Index = (props: TProps) => {

    const { initialProperties, initialAreas } = props;
    const { locale } = useRouter();

    const [filters, setFilters] = useState<TFilter>({
        for: EPropertyFor.SALE,
        type: EPropertyType.RESIDENTIAL,
        sub_type: null,
        locations: [],
        country : null,
        bedrooms : null,
        bathrooms : null,
        price: {
            min: null,
            max: null
        },
        size: {
            min: null,
            max: null
        },
        sort: EPropertySort.DATE_DESC,
        from : 0,
        to : EPagination.PER_PAGE_COUNT
    });
    const [properties, setProperties] = useState<Array<TPSource>>(initialProperties);
    const [areas, setAreas] = useState<Array<TCLocation>>(initialAreas);
    const [totalResult, setTotalResult] = useState<number>(0);
    const [proprtyDisplayMode, setProprtyDisplayMode] = useState<string>(EPropertyDisplayMode.GRID);

    /**
     * Switch property display mode
     * @param displayMode: string
     * @return void
     */
    const switchPropertyDisplayMode = (displayMode: string):void => {
        setProprtyDisplayMode(displayMode);
    }

    /**
     * Handle Pagination
     * @param selectedItem: object
     * @return void
     */
    const handlePagination = async (selectedItem: { selected: number; }) => {
        const pageNumber = selectedItem.selected;
        if(pageNumber > 0){
            let filtesWithPager = {...filters, from : pageNumber*EPagination.PER_PAGE_COUNT, to : EPagination.PER_PAGE_COUNT};
            const result  = await getFilteredProperties(filtesWithPager);
            if(result.status === true){
                setProperties(result.data.result);
                setTotalResult(result.data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
        }
    }

    /**
     * Handle Sorting
     * @param selectedItem: object
     * @return void
     */
    const handleSorting = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const sort = e.currentTarget.value;
        let filtesWithSort = {...filters, from : 0, to : EPagination.PER_PAGE_COUNT, sort:sort};
        const result  = await getFilteredProperties(filtesWithSort);
        if(result.status === true){
            setProperties(result.data.result);
            setTotalResult(result.data.total);
            setFilters((prevState) => {
                prevState = filters;
                return ({
                    ...prevState
                });
            });
        }
    }

    /**
     * Get the properties by filters
     * @param filters: TFilter
     * @return void
     */
    const handleSearchAfterSubmit = async (filters: TFilter) => {
        const result  = await Promise.all([
            getFilteredProperties(filters),
            getFilteredAreas(locale as string, filters.for, filters.sub_type),
        ]);
        if(result){
            if(result[0]){
                setProperties(result[0] ? result[0].data.result : []);
                setTotalResult(result[0].data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
            if(result[1]){
                setAreas(result[1] ? result[1].data : []);
            }
        }
    }

    /**
     * Render the page
     */
    return (
        <Layout>
            <SearchFilter
                handleSearch = { handleSearchAfterSubmit }
            ></SearchFilter>
            <PropertyArea
                areas = { areas }
            ></PropertyArea>
            <PropertySortFilter
                proprtyDisplayMode= {proprtyDisplayMode}
                totalResult = { totalResult }
                handleSorting= { handleSorting}
                switchPropertyDisplayMode= { switchPropertyDisplayMode }
            ></PropertySortFilter>
            <PropertyListing
                proprtyDisplayMode= {proprtyDisplayMode}
                totalResult = { totalResult }
                properties= { properties }
                handlePagination= { handlePagination }
            ></PropertyListing>
        </Layout>
    );
}

/**
 * Get static props
 */
export const getStaticProps:GetStaticProps = async (ctx) => {
    //const filters = ctx.query;
    console.log(ctx);
    // const result  = await Promise.all([
    //     getFilteredProperties({
    //         for: 1,
    //     }),
    //     getFilteredAreas(ctx.locale as string, 'residential'),
    // ]);
    // if(result){
    //     return { props: { 
    //             initialProperties: result[0] ? result[0].data : [], 
    //             initialAreas: result[1] ? result[1].data : [], 
    //         } 
    //     }
    // }else{
    //     return { props: { 
    //             initialProperties:  [], 
    //             initialAreas:  [], 
    //         } 
    //     }
    // }
    return { props: { 
        initialProperties:  [], 
        initialAreas:  [], 
    } 
} 
}

export default Index;
