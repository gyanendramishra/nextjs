import { TCategory, TCountry } from "./";

/**
 * Proprerty filter type
 */
export type TFilter = {
  for: string;
  type: string;
  sub_type: number | null;
  locations: Array<{}>;
  country: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  price: TMinMax;
  size: TMinMax;
  sort: string;
  from: number;
  to: number;
};

export type TMinMax = {
  min: number | null;
  max: number | null;
};

/**
 * Master elements type
 */
export type TMaster = {
  categories: TCategory[];
  countries: TCountry[];
};
