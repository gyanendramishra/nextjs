import { TSearchAction } from "../../types";

export const searchActions: TSearchAction = {
  FOR_FILTER_CHANGED: "FOR_FILTER_CHANGED",
  FILTER_CHANGE_FAILED: "FILTER_CHANGE_FAILED",
};

export const forFilterChanged = (propertyFor: string) => {
  return {
    type: searchActions.FOR_FILTER_CHANGED,
    payload: {
      for: propertyFor,
    },
  };
};

export const filterChangeFailed = (error: any) => {
  return {
    type: searchActions.FILTER_CHANGE_FAILED,
    error,
  };
};
