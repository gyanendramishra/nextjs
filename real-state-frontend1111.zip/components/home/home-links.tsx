import React from "react";
import { useTranslation } from 'react-i18next';

/**
 * component styles
 */
import styles from '../../styles/home/home-links.module.scss';


const HomeLinks = () => {

    const { t } = useTranslation();
    return (
        <div className={styles.home_links}>
            <div className={styles.container}>
                <div className={styles.ftr_row}>
                    <div className={`${styles.ftr_col} ${styles.ftr_col1}`}>
                        <a className={styles.ftr_logo} href="#">
                            <img src="/images/logo-white.svg" alt=""/>
                        </a>
                    </div>
                    <div className={`${styles.ftr_col} ${styles.ftr_col2}`}>
                        <div className={styles.frt_divide}>
                            <div className={styles.ftr_hd}>
                                { t("HOME_LINKS.ABOUT_DAR_AL_ARKAN_ONLINE.LABEL") }
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("HOME_LINKS.ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.OUR_STORY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("HOME_LINKS.ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.MORTGAGE") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("HOME_LINKS.ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.REGISTER_YOUR_COMPANY") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className={styles.frt_divide}>
                            <div className={styles.ftr_hd}>
                                <a href="#">
                                    { t("HOME_LINKS.REGISTER.LABEL") }
                                </a>
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("HOME_LINKS.REGISTER.OPTIONS.LIST_YOUR_PROPERTY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("HOME_LINKS.REGISTER.OPTIONS.LOGIN") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className={`${styles.ftr_col} ${styles.ftr_col3}`}>
                        <div className={styles.ftr_hd}>
                            { t("HOME_LINKS.PROPERTIES.LABEL") }
                        </div>
                        <div className={styles.ftr_nav}>
                            <ul>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_SAUDI_ARABIA") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_UNITED_KINGDOM") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_CYPRUS") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_FRANCE") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_ITALY") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_SWITZERLAND") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.PROPERTIES.OPTIONS.PROPERTIES_IN_SPAIN") }
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className={`${styles.ftr_col} ${styles.ftr_col4}`}>
                        <div className={styles.ftr_hd}>
                            { t("HOME_LINKS.EXPERIENCE.LABEL") }
                        </div>
                        <div className={styles.ftr_nav}>
                            <ul>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.EXPERIENCE.OPTIONS.BUILDING_EVALUATION") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.EXPERIENCE.OPTIONS.AREA_DIRECTORY") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.EXPERIENCE.OPTIONS.REAL_ESTATE_BLOG") }
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        { t("HOME_LINKS.EXPERIENCE.OPTIONS.REAL_ESTATE_FINANCE") }
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className={`${styles.ftr_col} ${styles.ftr_col5}`}>
                        <div className={styles.ftr_hd}>
                            { t("HOME_LINKS.OUR_SOCIAL_MEDIA.LABEL") }
                        </div>
                        <div className={styles.contact_info}>
                            <ul className="d-flex">
                                <li>
                                    <a href="#">
                                        <i className="icon-fb"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i className="icon-instagram"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i className="icon-linkedin"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i className="icon-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i className="icon-youtube"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default HomeLinks;