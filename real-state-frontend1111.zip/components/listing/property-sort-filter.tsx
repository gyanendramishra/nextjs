import React, { useState } from "react";
import { useTranslation } from 'react-i18next';
import styles from '../../styles/listing/property-sort-filter.module.scss';


type TProps = {
    sortSearch:Function;
    getView:Function;
    totalCount:number;
    forType:string;
};

const PropertySortFilter = (props:TProps) => {

  const { t } = useTranslation();
  
  const {totalCount,forType} = props;
  const [itemViews,setItemViews] = useState<boolean>(true);
  // this.state={itemView:true}
     /**
     * Get SortingValue
     * @return response
     */

    const getSortingValue=(value:string)=>{
      props.sortSearch(value);
    }

     /**
     * set boolean value for grid and list
     * @return response
     */

    const itemView = (viewStatus:boolean)=>{
      setItemViews(viewStatus)
      props.getView(viewStatus)
    }
    
    // const {itemView}=this.state;
    return (
     <div className={styles.property_sort_filter}>
       <div className={styles.container}>
        <div className="row">
          <div className="col-md-8">
            <div className={styles.sort_lt}>
            <div className={styles.hd_block2}>
            <h2>Properties {forType} in Saudi Arabia</h2>
            <p>{totalCount>0?totalCount:0} results</p>
            </div>
            <div className={styles.rt_filter}>
              <div className={styles.rt_col1}>
                <select className={styles.form_control} name="sortSearch" onChange={(e)=>{getSortingValue(e.target.value)}}>
                    <option value="relevence">{ t("SEARCH_SORT.RELEVANCE") }</option>
                    <option value="isExclusive">{ t("SEARCH_SORT.EXCLUSIVE") }</option>
                    <option value="asc">{ t("SEARCH_SORT.LOW_TO_HIGH") }</option>
                    <option value="desc">{ t("SEARCH_SORT.HIGH_TO_LOW") }</option>
                </select>
              </div>
              <div className={styles.rt_col1}>
                <a className={styles.form_control}><i className="icon-pin"></i> View On map</a>
              </div>
              <div className={styles.rt_col2}>
                <a className={itemViews?`${styles.grid_btn} `:`${styles.grid_btn} ${styles.active}`} onClick={()=>{itemView(false)}} href="#">Grid</a>
              </div>
              <div className={styles.rt_col2}>
              <a className={itemViews?`${styles.list_btn} ${styles.active}`:`${styles.list_btn}`} onClick={()=>{itemView(true)}} href="#">List</a>
              </div>
            </div>
            </div>
          </div>
         </div>
       </div>
     </div>
    );
  }

export default PropertySortFilter;
