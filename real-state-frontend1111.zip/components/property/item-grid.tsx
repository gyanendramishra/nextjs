import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { useTranslation } from 'react-i18next';
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Navigation, Scrollbar } from 'swiper';

SwiperCore.use([Navigation, Pagination, Scrollbar]);

/**
 * component styles
 */
import styles from '../../styles/property/item.module.scss';
/**
 * import classes
 */
import { Property } from '../../classes/property';


type TProps = {
    property: Property,
    handleVideo: Function;
}

const PropertyGridItem = (props: TProps) => {
    const { property } = props;
    const { t } = useTranslation();
    const [savedProperties, setSavedProperties] = useState<Array<number>>([]);
    
    useEffect(()=>{
        getSavedProperties();
    }, [])

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const getSavedProperties = () => {
        let savedProperties = localStorage.getItem('saved_properties');
        if(savedProperties){
            const properties  = (JSON.parse(savedProperties) as Array<number>);
            if(savedProperties){
                setSavedProperties(properties);
            }
        }
    }

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const handleVideo = (src: string): void => {
        props.handleVideo(src);
    }

    /**
     * Mark property as saved
     * @param id: number
     * @return void
     */
    const markAsSaved = (id: number): void => {
        if(!savedProperties.includes(id)){
            savedProperties.push(id);
            localStorage.setItem('saved_properties', JSON.stringify(savedProperties));
        }else{
            const index = savedProperties.indexOf(id);
            if (index !== -1) {
                savedProperties.splice(index, 1);
                localStorage.setItem('saved_properties', JSON.stringify(savedProperties));
            }
        }
        getSavedProperties();
    }

    return (
        <div className={styles.property_list}>
            <div className={styles.property_img}>
                <div className={styles.property_main_img}>
                    <Swiper
                        updateOnWindowResize={ true }
                        slidesPerView={1}
                        navigation
                        scrollbar={{ draggable: true, hide: true }}
                        pagination={{type:"fraction"}}
                    >
                        {property.mainImages().map((propertyFile, index) => {
                            return (
                                <SwiperSlide key={index}>
                                    <a href="#">
                                        <img src={ propertyFile } alt=""/>
                                    </a>
                                </SwiperSlide>
                            )
                        })}
                    </Swiper>
                </div>
                <div className={styles.overlay_top}>
                    <div className={styles.top_lt}>
                        { (property.isExclusive == true) && (
                            <div className={styles.new}>
                                <i className="icon-circle-with-check-symbol"></i> 
                                { t('PROPERTY_ITEM.FLAGS.EXCLUSIVE') }
                            </div>
                        )}
                        { (property.isGreatPrice == true) && (
                            <div className={styles.great_price}>
                                <i className="icon-circle-with-check-symbol"></i> 
                                { t('PROPERTY_ITEM.FLAGS.GREAT_PRICE') }
                            </div>
                        )}
                        { (property.isHighInvestmentReturn == true) && (
                            <div className={styles.return}>
                                <i className="icon-circle-with-check-symbol"></i> 
                                { t('PROPERTY_ITEM.FLAGS.HIGH_INVESTMENT_RETURN') }
                            </div>
                        )}
                    </div>
                    <div className={styles.top_rt}>
                        <a onClick={ ()=> markAsSaved(property.id) }>
                            <img src={ savedProperties.includes(property.id) ? '/images/heart.svg' : '/images/line-heart.png'} alt=""/> 
                        </a>
                    </div>
                </div>
                { ((property.externalVideoLink) || (property.externalUrl)) && (
                    <div className={styles.degree_icon}>
                        { (property.externalUrl) && (
                            <a className={styles.degree} href={ property.externalUrl } target="_blank">
                                <i className="icon-degrees"></i>
                            </a>
                        )}
                        { (property.externalVideoLink) && (
                            <a onClick={()=> handleVideo(property.externalVideoLink) }>
                                <i className="icon-play-button"></i>
                            </a>
                        )}
                    </div>
                )}
            </div>
            <div className={styles.prd_detail}>
                <div className={styles.prd_sub_hd}>
                    {property.shortAddress()}
                </div>
                <div className={styles.prd_hd}>
                    <a href="#">
                        {property.title()}
                    </a>
                </div>
                <ul className={styles.amenities_block}>
                    <li>
                        <i className="icon-bedroom"></i> 
                        {property.attributes.noOfBedrooms} {t("PROPERTY_ITEM.LABELS.BEDS")}
                    </li>
                    <li>
                        <i className="icon-bath"></i> {property.attributes.noOfBedrooms} {t("PROPERTY_ITEM.LABELS.BATHS")}
                    </li>
                    <li>
                        <i className="icon-size"></i> {property.attributes.builtUpArea} {property.areaUnit()}
                    </li>
                </ul>
                <div className={styles.prc_block}>
                    <div className={styles.prc}>
                        {property.formatedPrice()} {property.priceUnit()} 
                    </div>
                    <div className={styles.prd_logo}>
                        <img src="/images/aqua.png" alt=""/>
                    </div>
                </div>
                <ul className={styles.prd_social}>
                    <li>
                        <a href={"tel:"+property.owner.phone} target="_blank">
                            <i className="icon-call"></i> {t("PROPERTY_ITEM.ACTIONS.CALL")}
                        </a>
                    </li>
                    <li>
                        <a href={`${process.env.NEXT_PUBLIC_WHATSAPP_CALL_END_POINT}?phone=91${property.owner.whatsApp}`} target="_blank">
                            <i className="icon-whatsapp"></i> {t("PROPERTY_ITEM.ACTIONS.WHATSAPP")}
                        </a>
                    </li>
                    <li>
                        <a href={`mailto:"${property.owner.email}`} target="_blank">
                            <i className="icon-email"></i> {t("PROPERTY_ITEM.ACTIONS.EMAIL")}
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    );
};

PropertyGridItem.propTypes = {
    handleVideo: PropTypes.func.isRequired,
};

export default PropertyGridItem;