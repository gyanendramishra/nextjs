import React, { useState, useLayoutEffect } from "react";
import { connect } from 'react-redux';
import { useRouter } from 'next/router';
import { useTranslation } from 'react-i18next';
import { Formik, Form, FormikHelpers } from "formik";

/**
 * Import services, types and utils
 */
import { TFilter, TMaster, TSSearch  } from "../../types";
import { EPropertyType, EPropertyFor, EPropertySort, EPagination  } from "../../utils";
import { forFilterChanged } from "../../stores/actions";

/**
 * Import page components
 */
import LocationSearch from "@/components/search/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";


/**
 * Component styles
 */
import styles from "../../styles/search/main-search.module.scss";

type TProps = {
    storeFilters: TSSearch;
    searchElements: TMaster;
    dispatchForFilter: Function;
};

const MainSearch = (props:TProps) => {
    const {
        storeFilters, 
        searchElements,
        dispatchForFilter
    } = props;
    
    const { t } = useTranslation();
    const router = useRouter();
    const { locale } = router;
    const [isMobile, setIsMobile] = useState<boolean>(false);
    const [filters, setFilters] = useState<TFilter>({
        for: storeFilters.for,
        type: EPropertyType.RESIDENTIAL,
        sub_type: null,
        locations: [],
        country : null,
        bedrooms : null,
        bathrooms : null,
        price: {
            min: null,
            max: null
        },
        size: {
            min: null,
            max: null
        },
        sort: EPropertySort.DATE_DESC,
        from : 0,
        to : EPagination.PER_PAGE_COUNT
    });

    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });
    

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }
    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = async (propertyFor: string): Promise<void> => {
        setFilters((prevState) => {
            prevState.for = propertyFor;
            return({
              ...prevState
            })
          }
        );
        await dispatchForFilter(propertyFor);
    };

    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    const onHandleSearch = async (formData:TFilter): Promise<void> => {
        //formData.propertyFor = filters.propertyFor;
        //alert(JSON.stringify(formData, null, 2));
        //console.log(formData);
        //const results = await getFilteredProperties(formData);
        router.push('/properties');
        //console.log(results);
    }

    /**
     * Seach component
     */
    let searchComponent: {} | null | undefined;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                changePropertyFor = { changePropertyFor }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
            />
        )
    }

    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("MAIN_SEARCH.LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    <Formik
                        enableReinitialize={ true }
                        initialValues={filters}
                        onSubmit={ async (
                            values: TFilter,
                            {
                                setSubmitting,
                            }: FormikHelpers<TFilter>
                        ) => {
                            console.log(values);
                            await onHandleSearch(values);
                            setSubmitting(false);
                        }}
                    >
                        {() => (
                            <Form>
                                <div className={styles.search_category_nav}>
                                    <ul className="d-flex">
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.SALE ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.SALE)}
                                            >
                                                {t("MAIN_SEARCH.SEARCH_FOR.FOR_SALE")}
                                            </a>
                                        </li>
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.RENT ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.RENT)}
                                            >
                                                {t("MAIN_SEARCH.SEARCH_FOR.FOR_RENT")}
                                            </a>
                                        </li>
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.INTERNATIONL)}
                                            >
                                                {t("MAIN_SEARCH.SEARCH_FOR.INTERNATIONAL")}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                { searchComponent }
                            </Form>
                        )}
                    </Formik>
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ searchElements.categories }
                    propertyFor={ filters.for }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

const mapDispatchToProps = (dispatch: any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor))
});

const mapStateToProps = (state: any) => ({
    storeFilters:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(MainSearch);
