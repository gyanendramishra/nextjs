import React, {Component} from 'react'
import axios from 'axios'

import styles from '../../styles/components/autocomplete3.module.scss';

type TProps = any;
type TState = {
    tags: string[]
    modelId: number[]
    model: string[]
    activeSuggestion: number
    filteredSuggestions: string[]
    showSuggestions: boolean
    userInput: string
    responseList: []
};

class Autocomplete extends Component<TProps,TState> {

    static propTypes = {
        suggestions: Array
    };
    
    static defaultProps = {
        suggestions: []
    };

    constructor(props: any) {
        super(props);
        this.state = {
            tags: [],
            modelId:[],
            model: [],
            // The active selection's index
            activeSuggestion: 0,
            // The suggestions that match the user's input
            filteredSuggestions: [],
            // Whether or not the suggestion list is shown
            showSuggestions: false,
            // What the user has entered
            userInput: "",
            responseList: []
        };
    }

    // Event fired when the input value is changed
    onChange = e => {
        // const { suggestions } = this.props;
        const suggestions = []
        const userInput = e.currentTarget.value;

        // Filter our suggestions that don't contain the user's input
        const filteredSuggestions = suggestions.filter(
            suggestion => suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1
        );

        // Update the user input and filtered suggestions, reset the active
        // suggestion and make sure the suggestions are shown
        this.setState({
            activeSuggestion: 0,
            filteredSuggestions,
            showSuggestions: true,
            userInput: e.currentTarget.value
        });
    };

    // Event fired when the user clicks on a suggestion
    onClick = (e, clickData: string) => {
        // Update the user input and reset the rest of the state
        this.setState({
            activeSuggestion: 0,
            filteredSuggestions: [],
            showSuggestions: false,
            userInput: clickData            
        });
        let val = clickData;
        if (this.state.tags.find(tag => tag.toLowerCase() === val.toLowerCase())) {
            return;
        }
        this.setState({ tags: [...this.state.tags, val]});
        this.tagInput.value = null;

        const foodBar: any = this.state.responseList.find(item => item.name === clickData);
        let model_id = Number(foodBar.model_id)
        let model = foodBar.model
        
        let modelIdArr = this.state.modelId;
        let modelArr = this.state.model;
        modelIdArr.push(model_id);
        modelArr.push(model);

        this.setState({
            modelId: modelIdArr,
            model: modelArr           
        });
    };

    // Event fired when the user presses a key down
    onKeyDown = e => {        
        const { activeSuggestion, filteredSuggestions } = this.state;

        // User pressed the enter key, update the input and close the
        // suggestions
        if (e.keyCode === 13) {
            this.setState({
                activeSuggestion: 0,
                showSuggestions: false,
                userInput: filteredSuggestions[activeSuggestion]
            });
        }
        // User pressed the up arrow, decrement the index
        else if (e.keyCode === 38) {
            if (activeSuggestion === 0) {
                return;
            }

            this.setState({ activeSuggestion: activeSuggestion - 1 });
        }
        // User pressed the down arrow, increment the index
        else if (e.keyCode === 40) {
            if (activeSuggestion - 1 === filteredSuggestions.length) {
                return;
            }

            this.setState({ activeSuggestion: activeSuggestion + 1 });
        }
    };

    removeTag = (i) => {
        const newTags = [ ...this.state.tags ];
        newTags.splice(i, 1);
        this.setState({ tags: newTags });

        const newmodelIdArr = [ ...this.state.modelId ];
        newmodelIdArr.splice(i, 1);
        this.setState({ modelId: newmodelIdArr });

        const newmodelArr = [ ...this.state.model ];
        newmodelArr.splice(i, 1);
        this.setState({ model: newmodelArr });

        this.callAPI('');

        setTimeout(()=>{
            console.log(this.state);
        },10);        
    }

    inputKeyDown = (e) => {
        const { activeSuggestion, filteredSuggestions } = this.state;
        let val = e.target.value;
        
        if (e.key === 'Enter' && val) {
          if(val.length > 2){
            val = filteredSuggestions[activeSuggestion];
            if (this.state.tags.find(tag => tag.toLowerCase() === val.toLowerCase())) {
                return;
            }
          
            this.setState({ tags: [...this.state.tags, val]});
            this.tagInput.value = null;
          }
        } else if (e.key === 'Backspace' && !val) {
        //   this.removeTag(this.state.tags.length - 1);
        }

        if(e.key!='ArrowDown' && e.key!='ArrowUp' && e.key!='Enter') {
            if(val && val.length > 2){
                this.callAPI(val);
            }
        }
        
    }

    callAPI = (val: string) => {
        const apiConfig = {
            headers: {
                'Content-Type': 'application/json',
                'locale': 'en'
            }
        }
        let Data;
        if(this.state.modelId.length > 0){            
            Data = {
                "keyword": val,
                "model_id": this.state.modelId[(this.state.modelId.length-1)],
                "model": this.state.model[(this.state.model.length-1)]
              };
        } else {
            Data = {
                "keyword": val,
            };
        }
         
        axios.post('http://176.227.193.212:9900/misc/v1/search-box/locations', Data, apiConfig).then((response)=>{
            console.log(response.data.data);
            let resData = response.data.data;
            let tags = resData.map((data: {name: string})=>{
                return data.name;
            });
            this.setState({
                ...this.state,
                filteredSuggestions: tags,
                responseList: resData
            });
        })
    }

    render(){
        // const { tags } = this.state;
        const {
            onChange,
            onClick,
            onKeyDown,
            state: {
              activeSuggestion,
              filteredSuggestions,
              showSuggestions,
              userInput,
              tags
            }
          } = this;

        let suggestionsListComponent;

        if (showSuggestions && userInput) {
            if (filteredSuggestions.length) {
                suggestionsListComponent = (
                <ul className={styles.suggestions}>
                    {filteredSuggestions.map((suggestion, index) => {
                    let className;

                    // Flag the active suggestion with a class
                    if (index === activeSuggestion) {
                        className = styles.suggestion_active;
                    }
                    let data = this.state.responseList[index];
                    console.log(data);
                    return (
                        <li
                        className={className}
                        key={suggestion}
                        onClick={(event)=>onClick(event,data.name)}
                        >
                            <div className={styles.suggestion_div}>
                                <span className={styles.left_search_text}>{data.name}</span>
                                <span className={styles.right_search_text}>{data.parent_name}</span>
                            </div>
                        </li>
                    );
                    })}
                </ul>
                );
            } else {
                suggestionsListComponent = (
                <div className={styles.no_suggestions}>
                    <em>No suggestions, you're on your own!</em>
                </div>
                );
            }
        }

        return (
            <>
            <div className={styles.input_tag}>
                <ul className={styles.input_tag__tags}>
                { tags.map((tag, i) => (
                    <li key={tag}>
                    {tag}
                    <button type="button" onClick={() => { this.removeTag(i); }}>+</button>
                    </li>
                ))}
                <li className={styles.input_tag__tags__input}>
                    <input type="text" onChange={onChange} onKeyUp={(event)=>{this.inputKeyDown(event);this.onKeyDown(event);}} ref={c => { this.tagInput = c; }} placeholder="Search Country, City, Area" />
                </li>
                </ul>
            </div>
            {suggestionsListComponent}
            </>
        )
    }
    
}

export default Autocomplete

