
import Layout from "@/components/shared/layouts/Layout";
import SearchFilter from "@/components/listing/SearchFilter";
import PropertyArea from "@/components/listing/PropertyArea";
import PropertySortFilter from "@/components/listing/PropertySortFilter";
import PropertyListingMain from "@/components/listing/PropertyListingMain";

const IndexPage = () => (
  <Layout title="Listing : Dar Al Arkan">
    <SearchFilter></SearchFilter>
    <PropertyArea></PropertyArea>
    <PropertySortFilter></PropertySortFilter>
    <PropertyListingMain></PropertyListingMain>
  </Layout>
);

export default IndexPage;
