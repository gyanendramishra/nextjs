
import Layout from "@/components/shared/layouts/Layout";
import SearchProperties from "@/components/home/SearchProperties";
import RecommendedPropertiesKSA from "@/components/home/RecommendedPropertiesKSA";
import RecommendedPropertiesInternational from "@/components/home/RecommendedPropertiesInternational";
import PropertyServices from "@/components/home/PropertyServices";


import HomeLink from "@/components/home/HomeLink";

const IndexPage = () => (
  <Layout title="Home : Dar Al Arkan">
    <SearchProperties></SearchProperties>
    <RecommendedPropertiesKSA></RecommendedPropertiesKSA>
    <RecommendedPropertiesInternational></RecommendedPropertiesInternational>
    <PropertyServices></PropertyServices>
    <HomeLink></HomeLink>
  </Layout>
);

export default IndexPage;
