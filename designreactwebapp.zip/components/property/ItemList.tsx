import React, { Component } from "react";
import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react';

import styles from '../../styles/property/ItemList.module.scss';

SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

export default class PropertyItemList extends Component {
  render() {
    return (
      <div className={styles.property_list_view}>
        <div className={styles.property_img}>
        <div className={styles.property_main_img}>
          <Swiper
              slidesPerView={1}
              navigation
              pagination={{ type: 'fraction', clickable: true }}
            >
              <SwiperSlide>
                <a href="#"><img src="/images/image2.png" alt=""/></a>
              </SwiperSlide>
              <SwiperSlide>
                <a href="#"><img src="/images/image2.png" alt=""/></a>
              </SwiperSlide>
              <SwiperSlide>
                <a href="#"><img src="/images/image2.png" alt=""/></a>
              </SwiperSlide>
              <SwiperSlide>
                <a href="#"><img src="/images/image2.png" alt=""/></a>
              </SwiperSlide>
            </Swiper>
          </div>
          <div className={styles.overlay_top}>
            <div className={styles.top_lt}>
            <div className={styles.new}><i className="icon-circle-with-check-symbol"></i> Exclusive</div>
            </div>
            <div className={styles.top_rt}>
                <a href="#"><img src="/images/line-heart.png" alt=""/></a>
            </div>
          </div>
          <div className={styles.degree_icon}>
                <a className={styles.degree} href="#"><i className="icon-degrees"></i></a>
                <a href="#"><i className="icon-play-button"></i></a>
                </div>
          </div>
        <div className={styles.prd_detail}>
          <div className={styles.prd_sub_hd}>Riyadh, Saudi Arabia</div>
          <div className={styles.prd_hd}><a href="#">Apartment 1 Bedroom in Garden, Peterborough Peterborough, United Kingdom</a></div>
            
            <ul className={styles.amenities_block}>
              <li><i className="icon-bedroom"></i> 3 Beds</li>
              <li><i className="icon-bath"></i> 3 Baths</li>
              <li><i className="icon-size"></i> 317 Sqm</li>
            </ul>
            <div className={styles.prc_block}>
              <div className={styles.prc}>1,480,000 SAR </div>
              <div className={styles.prd_logo}><img src="/images/aqua.png" alt=""/></div>
            </div>
            <ul className={styles.prd_social}>
              <li><a href="#"><i className="icon-call"></i> Call</a></li>
              <li><a href="#"><i className="icon-whatsapp"></i> WhatsApp</a></li>
              <li><a href="#"><i className="icon-email"></i> Email</a></li>
            </ul>
          </div>
      </div>
    );
  }
}
