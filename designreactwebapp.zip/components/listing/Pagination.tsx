import React, { Component, Props } from "react";
import styles from '../../styles/listing/Pagination.module.scss';


export default class Pagination extends Component {
  render() {
    return (
     <div className={styles.pagination_block}>
       <ul className={styles.pagination}>
    <li className={`${styles.page_item} ${styles.item_first} ${styles.disabled}`}>
      <a className={styles.page_link}><img src="/images/arrow1.svg" alt=""/></a>
    </li>
    <li className={`${styles.page_item} ${styles.active}`}>
      <a className={styles.page_link} href="#">1</a>
      </li>
      <li className={styles.page_item}>
      <a className={styles.page_link}>2</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link} href="#">3</a>
      </li>
      <li className={styles.page_item}>
      <a className={styles.page_link}>4</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link}>5</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link}>6</a>
    </li>
      <li className={`${styles.page_item} ${styles.item_last}`}>
      <a className={styles.page_link} href="#"><img src="/images/arrow1.svg" alt=""/></a>
    </li>
  </ul>
     </div>
    );
  }
}
