import React, { Component, Props } from "react";
import styles from '../../styles/listing/PropertySortFilter.module.scss';


export default class PropertySortFilter extends Component {
  render() {
    return (
     <div className={styles.property_sort_filter}>
       <div className={styles.container}>
        <div className="row">
          <div className="col-md-8">
            <div className={styles.sort_lt}>
            <div className={styles.hd_block2}>
            <h2>Properties for Rent in Saudi Arabia</h2>
            <p>786 results</p>
            </div>
            <div className={styles.rt_filter}>
              <div className={styles.rt_col1}>
              <select className={styles.form_control}>
                 <option>Sort by: All</option>
               </select>
              </div>
              <div className={styles.rt_col1}>
                <a className={styles.form_control}><i className="icon-pin"></i> View On map</a>
              </div>
              <div className={styles.rt_col2}>
                <a className={`${styles.grid_btn} ${styles.active}`} href="#">Grid</a>
              </div>
              <div className={styles.rt_col2}>
              <a className={styles.list_btn}href="#">List</a>
              </div>
            </div>
            </div>
          </div>
         </div>
       </div>
     </div>
    );
  }
}
