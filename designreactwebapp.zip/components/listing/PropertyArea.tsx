import React, { Component, Props } from "react";
import styles from '../../styles/listing/PropertyArea.module.scss';


export default class PropertyArea extends Component {
  render() {
    return (
     <div className={styles.property_area}>
       <div className={styles.container}>
         <div className={styles.area_inr}>
           <ul>
             <li><a href="#">Riyadh</a></li>
             <li><a href="#">Medina</a></li>
             <li><a href="#">Mecca</a></li>
             <li><a href="#">Dammam</a></li>
             <li><a href="#">Jeddah</a></li>
             <li><a href="#">Dhahran</a></li>
           </ul>
           <div className={styles.area_rt_btn}><a href="#">View ALL <img src="/images/arrow2.svg" alt=""/></a></div>
         </div>
       </div>
     </div>
    );
  }
}
