import React, { Component } from "react";
import styles from '../../styles/home/HomeLink.module.scss';

export default class HomeLink extends Component {
  render() {
    return (
      <div className={styles.home_links}>
        <div className={styles.container}>
        <div className={styles.ftr_row}>
          <div className={`${styles.ftr_col} ${styles.ftr_col1}`}>
            <a className={styles.ftr_logo} href="#"><img src="/images/logo-white.svg" alt=""/></a>
          </div>
          <div className={`${styles.ftr_col} ${styles.ftr_col2}`}>
             <div className={styles.frt_divide}>
             <div className={styles.ftr_hd}>About Dar Al-Arkan Online</div>
              <div className={styles.ftr_nav}>
                <ul>
                  <li><a href="#">Our Story</a></li>
                  <li><a href="#">Mortgage</a></li>
                  <li><a href="#">Register Your Company</a></li>
                </ul>
              </div>
             </div>
             <div className={styles.frt_divide}>
              <div className={styles.ftr_hd}>Register</div>
              <div className={styles.ftr_nav}>
                <ul>
                  <li><a href="#">List your Property</a></li>
                  <li><a href="#">Log-in</a></li>
                </ul>
              </div>
             </div>
          </div>
          <div className={`${styles.ftr_col} ${styles.ftr_col3}`}>
            <div className={styles.ftr_hd}>Properties</div>
              <div className={styles.ftr_nav}>
                <ul>
                  <li><a href="#">Properties in Saudi Arabia</a></li>
                  <li><a href="#">Properties in United Kingdom</a></li>
                  <li><a href="#">Properties in Cyprus</a></li>
                  <li><a href="#">Properties in France</a></li>
                  <li><a href="#">Properties in Italy</a></li>
                  <li><a href="#">Properties in Switzerland</a></li>
                  <li><a href="#">Properties in Spain</a></li>
                </ul>
              </div>
            </div>
            <div className={`${styles.ftr_col} ${styles.ftr_col4}`}>
            <div className={styles.ftr_hd}>Experience</div>
              <div className={styles.ftr_nav}>
                <ul>
                  <li><a href="#">Building Evaluation</a></li>
                  <li><a href="#">Area Directory</a></li>
                  <li><a href="#">Real Estate Blog</a></li>
                  <li><a href="#">Real Estate Finance</a></li>
                </ul>
              </div>
            </div>
            <div className={`${styles.ftr_col} ${styles.ftr_col5}`}>
            <div className={styles.ftr_hd}>Our Social Media</div>
            <div className={styles.contact_info}>
              <ul className="d-flex">
                <li><a href="#"><i className="icon-fb"></i></a></li>
                <li><a href="#"><i className="icon-instagram"></i></a></li>
                <li><a href="#"><i className="icon-linkedin"></i></a></li>
                <li><a href="#"><i className="icon-twitter"></i></a></li>
                <li><a href="#"><i className="icon-youtube"></i></a></li>
              </ul>
              </div>
            </div>
          </div>
       
        </div>
      </div>
    );
  }
}
