import React, { Component } from "react";
import PropertyItem from "@/components/property/Item";

import styles from '../../styles/home/RecommendedPropertiesInternational.module.scss';

export default class RecommendedPropertiesInternational extends Component {
  render() {
    return (
      <div className={styles.home_section1}>
        <div className={styles.container}>
        <h2 className="text-center">Properties for Sale in International</h2>
          <div className="row">
            
            <div className="col-md-4">
                <PropertyItem></PropertyItem>
            </div>
            <div className="col-md-4">
              <PropertyItem></PropertyItem>
            </div>
            <div className="col-md-4">
              <PropertyItem></PropertyItem>
            </div>
          </div>
        
        </div>
      </div>
    );
  }
}
