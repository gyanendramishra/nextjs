import React, { Component, Props } from "react";
import styles from '../../styles/home/SearchProperties.module.scss';
import Autocomplete from '../autocomplete';
import Autocomplete3 from '../autocomplete3';

type TStates={ foreSale: boolean, forRent:boolean, international:boolean , apartments:boolean, villas:boolean, land:boolean, highInvestment:boolean, greatPrice:boolean, featured:boolean,advanceSearch:boolean}

type TProps=any
export default class SearchProperties extends Component<TProps,TStates> {
  constructor(props: TProps) {
    
    super(props);
    this.state = { foreSale: true, forRent:false, international:false , apartments:true, villas:false, land:false, highInvestment:true, greatPrice:false, featured:false,advanceSearch:false};
  }
  render() {
    //console.log(this.state);
    const { foreSale, forRent, international, apartments, villas, land, highInvestment, greatPrice, featured, advanceSearch } = this.state;
    return (
     <div className={styles.search_outer}>
        <div className={styles.container}>
          <div className={styles.search_block_outer}>
            <div className="text-center">
              <h1>Search Properties for Rent and Sale</h1>
            </div>

            <div className={styles.search_category_nav}>
            <ul className="d-flex">
              <li onClick={()=>{this.setState({foreSale: true, forRent:false, international:false})}}><a className={foreSale?styles.active:''}>For Sale</a></li>
              <li onClick={()=>{this.setState({foreSale: false, forRent:true, international:false})}}><a className={forRent?styles.active:''}>For Rent</a></li>
              <li onClick={()=>{this.setState({foreSale: false, forRent:false, international:true})}}><a className={international?styles.active:''}>International</a></li>
            </ul>
            </div>
           
            {/* FOR SALE SECTION */}
            <div className={foreSale?styles.dis_block:styles.dis_none}>
            <div className={styles.search_inner}>
              <div className={styles.select_block}>
                <select className={styles.form_control}>
                  <option>Residential</option>
                  <option>Commercial</option>
                </select>
              </div>
              <div className={styles.search_field}>
                {/* <input type="text" placeholder="Search country, city, area" className={styles.form_control}/> */}
                <Autocomplete></Autocomplete>
              </div>
              <div className={styles.search_btn}><button type="submit" className={styles.find_btn}>Find</button></div>
            </div>
            </div>

            {/* FOR RENT SECTION */}
           <div className={forRent?styles.dis_block:styles.dis_none}>
            <div className={styles.search_inner}>
              <div className={styles.select_block}>
                <select className={styles.form_control}>
                  <option>Residential</option>
                  <option>Commercial</option>
                </select>
              </div>
              <div className={styles.search_field}>
                {/* <input type="text" placeholder="Search country, city, area" className={styles.form_control}/> */}
                <Autocomplete></Autocomplete>
              </div>
              <div className={styles.search_btn}><button type="submit" className={styles.find_btn}>Find</button></div>
            </div>
            </div>

            {/* INTERNATIONAL SECTION */}
            <div className={international?styles.dis_block:styles.dis_none}>
            <div className={`${styles.search_inner} ${styles.international_col}`}>
              <div className={styles.select_block}>
                <select className={styles.form_control}>
                  <option>Residential</option>
                  <option>Commercial</option>
                </select>
              </div>
              <div className={`${styles.select_block} ${styles.country_col}`}>
                <select className={styles.form_control}>
                  <option>Country</option>
                  <option>Saudi Arabia</option>
                  <option>Bosnia and Herzegovina</option>
                  <option>United Arab Emirates</option>
                  <option>United Kingdom</option>
                  <option>Monaco</option>
                  <option>Cyprus</option>
                  <option>France</option>
                  <option>Greece</option>
                  <option>Italy</option>
                  <option>Malta</option>
                  <option>Switzerland</option>
                  <option>Spain</option>
                </select>
              </div>
              <div className={styles.search_field}>
                <Autocomplete></Autocomplete>
              </div>
              <div className={styles.search_btn}><button type="submit" className={styles.find_btn}>Find</button></div>
            </div>
            </div>
           
            <div className={styles.srch1}>

            <div className={advanceSearch? `${styles.adv_block}`: styles.dis_none}>
              <a className={styles.cls_btn3} onClick={()=>{advanceSearch?this.setState({advanceSearch:false}):this.setState({advanceSearch:true})}}><img src="/images/close.svg" alt=""/></a>
           <div className={styles.adv_row}>
             <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>Property Type</option>
                 <option>Apartment</option>
                 <option>Commercial</option>
                 <option>Land</option>
                 <option>Private Island</option>
                 <option>Villa / Townhouse</option>
               </select>
             </div>
             <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>Beds</option>
                 <option>1</option>
                 <option>2</option>
                 <option>3</option>
                 <option>4</option>
                 <option>5+</option>
               </select>
             </div>
             <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>Baths</option>
               </select>
             </div>
             <div className={styles.adv_col2}>
               <div className={`${styles.form_control} ${styles.click_btn1}`}>
                 <label className={styles.lbl}>Price</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box1}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
             <div className={styles.adv_col2}>
                <div className={`${styles.form_control} ${styles.click_btn2}`}>
                 <label className={styles.lbl}>Size</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box2}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
           </div>
         </div>
             
             
              <div className={styles.srch1_inr}>
              <a className={styles.left_link}><i className="icon-pin"></i> Search on Map</a>
              <a className={`${styles.right_link} ${styles.desktop_link}`} onClick={()=>{advanceSearch?this.setState({advanceSearch:false}):this.setState({advanceSearch:true})}}><i className="icon-levels"></i>{advanceSearch?' Close Advanced Search':'Advanced Search'} </a>
            
              <a className={`${styles.right_link} ${styles.mobile_link}`}><i className="icon-levels"></i> Advanced Search</a>
              </div>
       </div>

          </div>


          <div className={styles.advance_search_block}>

       
       <div className={international? styles.dis_none :`${styles.custom_tab} ${styles.dis_block}`}>
 
          <ul className={styles.prop_tab}>
          <li onClick={()=>{this.setState({apartments: true, villas:false, land:false})}}><a className={apartments?styles.active:''}>Apartments</a></li>
          <li onClick={()=>{this.setState({apartments: false, villas:true, land:false})}}><a className={villas?styles.active:''}>Villas</a></li>
          <li onClick={()=>{this.setState({apartments: false, villas:false, land:true})}}><a className={land?styles.active:''}>Land</a></li>
          </ul>
           
          <div className={apartments? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
              <ul className={styles.link2}>
                <li><a href="#">Apartments for Sale in Abha</a></li>
                <li><a href="#">Apartments for Sale in Al-Ahsa</a></li>
                <li><a href="#">Apartments for Sale in Al-Khobar</a></li>
                <li><a href="#">Apartments for Sale in Baha</a></li>
                <li><a href="#">Apartments for Sale in Dammam</a></li>
                <li><a href="#">Apartments for Sale in Dhahran</a></li>
              </ul>
              <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>
          <div className={villas? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
              <ul className={styles.link2}>
                <li><a href="#">Apartments for Sale in Abha</a></li>
                <li><a href="#">Apartments for Sale in Al-Ahsa</a></li>
                <li><a href="#">Apartments for Sale in Al-Khobar</a></li>
                <li><a href="#">Apartments for Sale in Baha</a></li>
                <li><a href="#">Apartments for Sale in Dammam</a></li>
                <li><a href="#">Apartments for Sale in Dhahran</a></li>
              </ul>
              <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>
          <div className={land? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
              <ul className={styles.link2}>
                <li><a href="#">Apartments for Sale in Abha</a></li>
                <li><a href="#">Apartments for Sale in Al-Ahsa</a></li>
                <li><a href="#">Apartments for Sale in Al-Khobar</a></li>
                <li><a href="#">Apartments for Sale in Baha</a></li>
                <li><a href="#">Apartments for Sale in Dammam</a></li>
                <li><a href="#">Apartments for Sale in Dhahran</a></li>
              </ul>
              <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>
          </div>

          <div className={international? `${styles.custom_tab} ${styles.dis_block}`: styles.dis_none}>
          <ul className={styles.prop_tab}>
          <li onClick={()=>{this.setState({highInvestment: true, greatPrice:false, featured:false})}}><a className={highInvestment?styles.active:''} href="#">High Investment Return</a></li>
          <li onClick={()=>{this.setState({highInvestment: false, greatPrice:true, featured:false})}}><a className={greatPrice?styles.active:''} href="#">Great Price</a></li>
          <li onClick={()=>{this.setState({highInvestment: false, greatPrice:false, featured:true})}}><a className={featured?styles.active:''} href="#">Featured</a></li>
          </ul>
          <div className={highInvestment? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
            <ul className={styles.link2}>
              <li><a href="#">Bosnia and Herzegovina</a></li>
              <li><a href="#">United Arab Emirates</a></li>
              <li><a href="#">Malta</a></li>
              <li><a href="#">Cyprus</a></li>
              <li><a href="#">France</a></li>
              <li><a href="#">Spain</a></li>
            </ul>
            <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>

          <div className={greatPrice? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
            <ul className={styles.link2}>
              <li><a href="#">Afghanistan</a></li>
              <li><a href="#">Albania</a></li>
              <li><a href="#">Algeria</a></li>
              <li><a href="#">Malawi</a></li>
              <li><a href="#">Malaysia</a></li>
              <li><a href="#">Mali</a></li>
            </ul>
            <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>

          <div className={featured? `${styles.tab_content} ${styles.dis_block}`: styles.dis_none} >
            <ul className={styles.link2}>
              <li><a href="#">New Zealand</a></li>
              <li><a href="#">Nicaragua</a></li>
              <li><a href="#">Nigeria</a></li>
              <li><a href="#">Norway</a></li>
              <li><a href="#">Palau</a></li>
              <li><a href="#">Paraguay</a></li>
            </ul>
            <div className={styles.all_properties}><a href="#">View all properties</a></div>
          </div>


          </div>




   </div>



            {/* Mobile Popup Search Filter */}

       <div className={styles.search_mobile_block_outer}>
          

          <div className={styles.search_category_nav}>
          <ul className="d-flex">
            <li><a className={styles.active}>For Sale</a></li>
            <li><a>For Rent</a></li>
            <li><a>International</a></li>
          </ul>
          </div>
         
          {/* FOR SALE SECTION */}
          <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
           <div className={styles.adv_col_full}>
           <Autocomplete3></Autocomplete3>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Residential</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}><i className="icon-levels"></i> Close Advanced Search</a>
           </div>
          </div>

          {/* FOR RENT SECTION */}
          <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
             <input type="text" className={styles.form_control} placeholder="Search Country, City, Area"/>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Residential</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={styles.close_adv_btn}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}><i className="icon-levels"></i> Close Advanced Search</a>
            </div>
          </div>

          {/* INTERNATIONAL SECTION */}
          <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
             <input type="text" className={styles.form_control} placeholder="Search Country, City, Area"/>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Residential</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Country</option>
               <option>Saudi Arabia</option>
               <option>Bosnia and Herzegovina</option>
               <option>United Arab Emirates</option>
               <option>United Kingdom</option>
               <option>Monaco</option>
               <option>Cyprus</option>
               <option>France</option>
               <option>Greece</option>
               <option>Italy</option>
               <option>Malta</option>
               <option>Switzerland</option>
               <option>Spain</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
             <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={styles.close_adv_btn}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}><i className="icon-levels"></i> Close Advanced Search</a>
            </div>
          </div>
          
       </div>
           {/* Mobile Popup Search Filter */}

        </div>
     </div>
    );
  }
}
