import React, { Component } from "react";
//import Link from 'next/link';
import styles from '../../../styles/global/Header.module.scss';

export default class Header extends Component {
  render() {
    return (
      <header className={styles.header}>
        <div className={styles.container}>
         <div className={styles.hdr_btm_inr}>
              <a className={styles.logo} href="#"><img src="/images/logo.svg" alt=""/></a>
              <a  className={styles.menu_button}><img src="/images/berger-menu.svg" alt=""/></a>
              <div className={styles.menu}>
                <div className={styles.mobile_scroll}>
                <ul className={styles.nav1}>
                  <li className={styles.sub_nav}><a href="#">For Sale</a>
                   <div className={styles.sub_nav_outer}>
                     <ul>
                       <li><a href="#">Riyadh</a></li>
                       <li><a href="#">Jeddah</a></li>
                       <li><a href="#">Medina</a></li>
                       <li><a href="#">Dammam</a></li>
                       <li><a href="#">Mecca</a></li>
                       <li><a href="#">Al Khobar</a></li>
                       <li><a href="#">Tabuk</a></li>
                       <li><a href="#">Yanbu</a></li>
                       <li><a href="#">Taif</a></li>
                       <li><a href="#">Al Jubail</a></li>
                       <li><a href="#">Abha</a></li>
                       <li><a href="#">Najran</a></li>
                     </ul>
                     <a className={styles.all_link} href="#">All Details</a>
                   </div>
                  </li>
                  <li className={styles.sub_nav}><a href="#">For Rent</a>
                  </li>
                  <li className={styles.sub_nav}><a href="#">International</a>
                  <div className={styles.sub_nav_outer}>
                    <div className={styles.nav_hd}>Value</div>
                     <ul>
                       <li><a href="#">High Investment Return</a></li>
                       <li><a href="#">Great Price</a></li>
                     </ul>
                     <div className={styles.nav_hd}>Countries</div>
                     <ul>
                       <li><a href="#">Bosnia and Herzegovina</a></li>
                       <li><a href="#">United Arab Emirates</a></li>
                       <li><a href="#">Malta</a></li>
                       <li><a href="#">United Kingdom</a></li>
                       <li><a href="#">Monaco</a></li>
                       <li><a href="#">Switzerland</a></li>
                       <li><a href="#">Cyprus</a></li>
                       <li><a href="#">France</a></li>
                       <li><a href="#">Spain</a></li>
                       <li><a href="#">Greece</a></li>
                       <li><a href="#">Italy</a></li>
                     </ul>
                     <a className={styles.all_link} href="#">All Details</a>
                   </div>
                  </li>
                  <li className={styles.sub_nav}><a href="#">Services</a>
                  </li>
                  <li className={styles.sub_nav}><a href="#">Experience</a>
                  </li>
                </ul>
                <ul className={styles.nav2}>
                 <li className={styles.setting}><a href="#">Setting</a></li>
                 <li className={styles.saved}><a href="#">Saved <i className="icon-heart"></i></a></li>
                 <li className={styles.name}><a href="#">عربي</a></li>
                 <li className={styles.sign_btn}><a href="#">Log in</a></li>
               </ul>
                </div>
               <a className={`${styles.button_line} ${styles.button_line_mobile}`} href="#">List your Property</a>
               <a className={styles.button_close} href="#"><img src="/images/close.svg" alt=""/></a>
               <div className={styles.app_download_btn_mobile}>
                 <a href="#"><img src="/images/app-store.svg" alt=""/></a>
                 <a href="#"><img src="/images/google-pay.svg" alt=""/></a>
               </div>
             </div>
             <a className={styles.button_line} href="#">List your Property</a>
           </div>
        </div>
      </header>
    );
  }
}
