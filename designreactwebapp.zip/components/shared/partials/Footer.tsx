import React, { Component } from "react";
import styles from '../../../styles/global/Footer.module.scss';

export default class Footer extends Component {
  render() {
    return (
      <footer className={styles.footer}>
        <div className={styles.container}>
        <div className={styles.ftr_btm}>
            <div className={styles.ftr_lt}>
              <div className={styles.ftr_btm_nav}>
              <a href="#">About. </a>
              <a href="#">Terms and Conditions. </a>
              <a href="#">Privacy policy. </a>
              <a href="#">Customer login. </a>
              <a href="#">Careers. </a>
              <a href="#">Company registration</a>
              </div>
              <div className={styles.ftr_btm_nav2}><a href="#">Terms</a>  |  <a href="#">Privacy Policy</a></div>
            </div>
            <div className={styles.ftr_rt}>
              <a className={styles.wd1} href="#"><img src="/images/app-store.svg" alt=""/></a>
              <a className={styles.wd2} href="#"><img src="/images/google-pay.svg" alt=""/></a>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}
