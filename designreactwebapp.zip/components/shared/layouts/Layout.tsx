import Head from "next/head";
import React, { Component, ReactNode } from "react";
import Header from "@/components/shared/partials/Header";
import Footer from "@/components/shared/partials/Footer";

type Props = {
  children?: ReactNode;
  title?: string;
  keywords?: string;
  description?: string;
};

export default class Layout extends Component<
  Props,
  { children: ReactNode; title: string }
> {
  static defaultProps = {
    title: "Home: Dar Al Arkan",
    keywords: "Home: Dar Al Arkan",
    description: "Home: Dar Al Arkan",
  };
  render() {
    return (
      <>
        {/* Layout Head  */}
        <Head>
          <meta charSet="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
          <meta name="keyword" content={this.props.keywords} />
          <meta name="description" content={this.props.description} />
          <title>{this.props.title}</title>
        </Head>
        {/* Layout Header Seaction */}
        <Header />
        {/* Layout Main Seaction  */}
        {this.props.children}
        {/* Layout Footer Seaction */}
        <Footer />
      </>
    );
  }
}
