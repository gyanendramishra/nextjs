import React, { ReactText, useState } from "react";
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import {useField, FieldConfig, useFormikContext} from "formik";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";


type TProps = {
    readonly t: TFunction;
    readonly label : string;
    readonly options: TPickerOption; 
    styles: TStyle;
} & ReactI18nextWithTranslation  & FieldConfig

type TStyle = {
    readonly [key: string]: string;
}

type TPickerOption = {
    min: ReactText[];
    max: ReactText[];
}

export const MinMaxPicker = (props:TProps) => {
    const [ field ] = useField(props);
    const { t, label, options, styles} = props;

    const { setFieldValue } = useFormikContext();

    const [min, setMin] = useState<ReactText>("Any");
    const [max, setMax] = useState<ReactText>("Any");
    const [opened, setOpened] = useState<boolean>(false);

    /**
     * Toggle the picker
     * @return void
     */
    const togglePicker = (): void => {
        if (opened === true) {
            setOpened(false);
        } else {
            setOpened(true);
        }
    };

    /**
     * Handle min value
     * @return void
     */
    const handleMinValue = (value : number | string): void => {
        setMin(value);
        setFieldValue(field.name, {
            min: min,
            max: max,
        });
    };

    /**
     * Handle max value
     * @return void
     */
    const handleMaxValue = (value : number | string): void => {
        setMax(value);
        setFieldValue(field.name, {
            min: min,
            max: max,
        });
    };

    /**
     * Handle min value on key up
     * @return void
     */
    const handleMinValueOnKeyUp = (e: React.KeyboardEvent<HTMLInputElement>): void => {
        handleMinValue((e.target as HTMLInputElement).value);
    };

    /**
     * Handle max value on key up
     * @return void
     */
    const handleMaxValueOnKeyUp = (e: React.KeyboardEvent<HTMLInputElement>): void => {
        handleMaxValue((e.target as HTMLInputElement).value);
    };

    return (
        <>
            <div className={`${styles.form_control} ${styles.click_btn1}`} onClick={ togglePicker }>
                <label className={`${styles.lbl} ${styles.lbl1}`}>{ label }</label>
                <label className={styles.lbl}>{min}</label>
                <span className={styles.span}>{ t("LABELS.TO") }</span>
                <label className={styles.lbl}>{ max }</label>
            </div>
            { opened && (
                <div className={`${styles.price_select_card} ${styles.open_box1}`}>
                    <div className={styles.card_block1}>
                        <input type="text"  {...field } style={{ display: "none"}}   />
                        <div className={styles.card_lt}>
                            <div className={styles.label_value}>{ t("LABELS.MIN") }:</div>
                            <input type="text" placeholder={`${ min }`} className={styles.form_control} onKeyUp={ handleMinValueOnKeyUp }  />
                            <ul className={styles.listing_block}>
                                <li>
                                    <a onClick={()=> handleMinValue('Any')}>{ t("LABELS.ANY") }</a>
                                </li>
                                { options.min.map((option, index) => {
                                    if(max as number <= option){
                                        return (
                                            <li key={index}>
                                                <a className={ min == option ? styles.active : '' }>
                                                    <del>{ option }</del>
                                                </a>
                                            </li>
                                        )
                                    }else{
                                        return (
                                            <li key={index}>
                                                <a className={ min == option ? styles.active : '' } onClick={()=> handleMinValue(option)}>{ option }</a>
                                            </li>
                                        )
                                    }
                                })}
                            </ul>
                        </div>
                        <div className={styles.card_rt}>
                            <div className={styles.label_value}>{ t("LABELS.MAX") }:</div>
                            <input type="text" placeholder={`${ max }`} className={styles.form_control} onKeyUp={ handleMaxValueOnKeyUp } />
                            <ul className={styles.listing_block}>
                                <li>
                                    <a onClick={()=> handleMaxValue('Any')}>{ t("LABELS.ANY") }</a>
                                </li>
                                { options.max.map((option, index) => {
                                    if(min as number >= option){
                                        return (
                                            <li key={index}>
                                                <a className={ max == option ? styles.active : '' }>
                                                    <del>{ option }</del>
                                                </a>
                                            </li>
                                        )
                                    }else{
                                        return (
                                            <li key={index}>
                                                <a className={ max == option ? styles.active : '' } onClick={()=> handleMaxValue(option)}>{ option }</a>
                                            </li>
                                        )
                                    }
                                })}
                            </ul>
                        </div>
                    </div>
                    <div className={styles.btn_outer1}>
                        <a className={styles.close_btn1} onClick={ togglePicker }>
                            { t("LABELS.CLOSE") }
                        </a>
                    </div>
                </div>
            )}
        </>
    );
}

export default withTranslation("min-max-picker")(MinMaxPicker)
