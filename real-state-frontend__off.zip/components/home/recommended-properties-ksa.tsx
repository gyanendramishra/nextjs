import React, { useContext, useState } from "react";
import PropTypes from "prop-types";
import { TFunction, I18nContext } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import components
 */
import PropertyItem from "@/components/property/item";
import FrameModal from "@/components/shared/elements/frame-modal";

/**
 * import clases and services
 */
import { recommendedKSAProperties } from '../../services';
import { RecommendedProperty, TPSource } from '../../classes/recommended-property';

/**
 * component styles
 */
import styles from '../../styles/home/recommended-properties-ksa.module.scss';


type TProps = {
    readonly t: TFunction;
} & ReactI18nextWithTranslation

type TModal = {
    opened: boolean;
    title?: string;
    src?: string;
}

const RecommendedPropertiesKSA  = (props: TProps) => {
    
    const { t } = props;
    const { i18n: { language } } = useContext(I18nContext);

    const [properties, setProperties] = useState<Array<TPSource>>([]);
    const [modal, setModal] = useState<TModal>({
        opened: false,
        title: "",
        src: ""
    });

    /**
     * Trigger react lifecycle hook
     */
    React.useEffect( () => {
        getProperties();
    }, [language]);

    /**
     * Get the properties
     * @return void
     */
    const getProperties = async () : Promise<void> => {
        const result = await recommendedKSAProperties();
        if(result.status === true){
            setProperties(result.data);
        }else{
            console.error(result.message);
        }
    };

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const populateVideo = (src: string): void => {
        setModal((prevState) => {
            prevState.opened = true;
            prevState.title = t("VIDEO_MODAL_TITLE");
            prevState.src = src;
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Handle modal on close
     * @param src: string
     * @return void
     */
    const handleModelClose = (): void => {
        setModal((prevState) => {
            prevState.opened = false;
            prevState.title = "";
            prevState.src = "";
            return({
              ...prevState
            })
          }
        );
    }

    /**
     * Render the template
     * 
     * @return mix html
     */
    if(!Object.keys(properties).length){
        return ("");
    }
    return (
        <div className={styles.home_section1}>
            <div className={styles.container}>
                <h2 className="text-center">{ t("TITLE_KSA") }</h2>
                <div className="row">
                    {properties.map((property:TPSource, index:number) => {
                        const rProperty = new RecommendedProperty(property, language);
                        return (
                            <div 
                                className="col-md-4"
                                key={index}
                            >
                                <PropertyItem
                                    property={rProperty}
                                    handleVideo={populateVideo}
                                ></PropertyItem>
                            </div>
                        )
                    })}
                </div>
            </div>
            <FrameModal 
                title={ modal.title }
                opened={ modal.opened }
                src={ modal.src }
                onModalClose = { handleModelClose}
            ></FrameModal>
        </div>
    );
}

/**
 * Validate prop types
 */
RecommendedPropertiesKSA.propTypes = {
    t: PropTypes.func.isRequired,
};

export default withTranslation("recommended-properties")(RecommendedPropertiesKSA)
