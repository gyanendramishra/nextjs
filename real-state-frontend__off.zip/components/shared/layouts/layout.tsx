import Head from "next/head";
import PropTypes from "prop-types";
import { I18nContext } from "next-i18next";
import React, { ReactNode, useContext } from "react";
import PageHeader from "@/components/shared/partials/page-header";
import PageFooter from "@/components/shared/partials/page-footer";

type TProps = {
    children: ReactNode;
    title: string;
    keywords?: string;
    description?: string;
};

const Layout = (props: TProps) => {
    const { children, title, keywords, description } = props;
    const { i18n: { language } } = useContext(I18nContext);

    return (
        <>
            {/* Layout Head  */}
            <Head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="initial-scale=1.0, width=device-width"/>
                <meta name="keyword" content={ keywords } />
                <meta name="description" content={ description } />
                <meta name="lang" content={ language } />
                <title>{ title }</title>
            </Head>
            {/* Layout Header Seaction */}
            <PageHeader />
                {/* Layout Main Seaction  */}
                { children }
                {/* Layout Footer Seaction */}
            <PageFooter /> 
        </>
    );
}

/**
 * Validate prop types
 */
Layout.propTypes = {
    title: PropTypes.string.isRequired,
};

Layout.defaultProps = {
    title: "Home: Dar Al Arkan",
    keywords: "Home: Dar Al Arkan",
    description: "Home: Dar Al Arkan",
};

export default Layout;
