import { AnyAction } from "redux";
import { HYDRATE } from "next-redux-wrapper";
import { searchActions } from "../actions";
import { TFilter } from "../../types";
import { EPropertyFor, EPropertyType } from "../../utils";

const searchState: TFilter = {
  advanceSearch: false,
  for: EPropertyFor.SALE,
  type: EPropertyType.RESIDENTIAL,
  sub_type: null,
  locations: [],
  country: null,
  beadrooms: null,
  bathrooms: null,
  price: null,
  size: null,
};

export function searchReducer(state: TFilter = searchState, action: AnyAction) {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    case searchActions.FOR_FILTER_CHANGED:
      return {
        ...state,
        ...{ for: action.payload.for },
      };

    case searchActions.TYPE_FILTER_CHANGED:
      return {
        ...state,
        ...{ type: action.payload.type },
      };

    case searchActions.ADVANCE_SEARCH_FILTER_CHANGED:
      return {
        ...state,
        ...{ advanceSearch: action.payload.advanceSearch },
      };

    default:
      return state;
  }
}

export default searchReducer;
