module.exports = {
  i18n: {
    locales: ['en', 'ar' ],
    defaultLocale: 'en',
  },
}
