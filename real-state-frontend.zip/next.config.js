const { locales, defaultLocale } = require('./i18n.js')

module.exports = {
  i18n: {
    locales,
    defaultLocale,
  },
}