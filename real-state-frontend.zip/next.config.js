module.exports = {
  i18n: {
    locales: ['en', 'ar' ],
    defaultLocale: 'en',
  },
  // async rewrites() {
  //   return [
  //     // Basic `path-to-regexp` usage
  //     // Query object shape: { id: string }
  //     { source: "/user/:id", destination: "/user_profile" },

  //     // Optional Language
  //     // Query object shape: { lang?: string }
  //     { source: "/:lang(en|es)?/about", destination: "/about" },

  //     // Advanced rewrite
  //     // Query object shape: { id: string } (in addition to dynamic route param)
  //     { source: "/u/:id", destination: "/user/:id" }
  //   ];
  // }
  async rewrites() {
    return [
      {
        source: '/:lang(en|ar)?/properties/:slug',
        destination: '/:lang(en|ar)?/blog', // Matched parameters can be used in the destination
      },
    ]
  },
}

