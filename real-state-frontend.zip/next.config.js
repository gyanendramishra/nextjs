const { locales, defaultLocale } = require('./i18n.js')

module.exports = {
  i18n: {
    locales,
    defaultLocale,
  },
  async redirects() {
    return [
      {
        source: '/',
        destination: '/ar',
        permanent: true,
      },
    ]
  },
}