import axios, { AxiosResponse } from "axios";
import { TResultSet } from "../types";
import {
  EZero,
  EPagination,
  EPropertyFor,
  EPropertyType,
  EPropertySort,
  EQSearchProperty,
  EPropertyForValue,
  EPropertyTypeValue,
  EPropertyRegionValue,
  EPropertyFlag,
  EQRecommendedPropertyFORKSA,
  EQRecommendedPropertyFORInternational,
} from "../utils";

/**
 * Get the search masters
 * @return result: TResultSet
 */
export const getRecommendedKSAProperties = async (): Promise<TResultSet> => {
  let result: TResultSet = {
    status: false,
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORKSA
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    throw error;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const getRecommendedInternationalProperties = async (): Promise<TResultSet> => {
  let result: TResultSet = {
    status: false,
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORInternational
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    throw error;
  }
  return result;
};

/**
 * Get filtered areas
 * @param locale
 * @return response
 */

export const getFilteredAreas = async (
  locale: string,
  type: string | string[],
  category: string | string[]
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    let uri =
      type === EPropertyFor.SALE ? "cities-for-sale" : "cities-for-rent";
    if (category) {
      uri = uri + `/${category}`;
    }
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/${uri}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * Get the property search List
 * @return void
 */
export const getFilteredProperties = async (
  request: any
): Promise<TResultSet> => {
  let result: TResultSet = {};
  const EQuery = EQSearchProperty;

  const qMust = [];
  const qSort = [];

  const qOmust = {
    query: {
      bool: {
        must: {},
      },
    },
  };
  const qOsort = {
    sort: {},
  };
  if (request.for) {
    qMust.push({
      match: {
        "searchCriteria.propertyRegionId":
          request.for === EPropertyFor.SALE
            ? EPropertyRegionValue.KSA
            : EPropertyRegionValue.INTERNATIONAL,
      },
    });
    qMust.push({
      match: {
        "searchCriteria.propertyForId":
          request.for === EPropertyFor.SALE
            ? EPropertyForValue.SALE
            : EPropertyForValue.RENT,
      },
    });
  }
  if (request.type) {
    qMust.push({
      match: {
        "searchCriteria.propertyMainTypeId":
          request.type === EPropertyType.RESIDENTIAL
            ? EPropertyTypeValue.RESIDENTIAL
            : EPropertyTypeValue.COMMERCIAL,
      },
    });
  }
  if (request.sub_type) {
    qMust.push({
      match: {
        "searchCriteria.propertySubTypeId": request.sub_type,
      },
    });
  }
  if (request.bedrooms) {
    qMust.push({
      match: {
        "attribute.noOfBedrooms": request.bedrooms,
      },
    });
  }
  if (request.bathrooms) {
    qMust.push({
      match: {
        "attribute.noOfBathrooms": request.bathrooms,
      },
    });
  }

  if (request.country) {
    qMust.push({
      match: {
        "searchCriteria.countryId": request.country,
      },
    });
  }
  if (request.state) {
    qMust.push({
      match: {
        "searchCriteria.stateId": request.state,
      },
    });
  }
  if (request.city) {
    qMust.push({
      match: {
        "searchCriteria.cityId": request.city,
      },
    });
  }
  if (request.zone) {
    qMust.push({
      match: {
        "searchCriteria.zoneId": request.zone,
      },
    });
  }

  if (request.price) {
    if (
      request.price.min &&
      !isNaN(request.price.min) &&
      request.price.max &&
      !isNaN(request.price.max)
    ) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
            lte: request.price.max,
          },
        },
      });
    } else if (request.price.min && !isNaN(request.price.min)) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
          },
        },
      });
    } else if (request.price.max && !isNaN(request.price.max)) {
      qMust.push({
        range: {
          "attribute.salePrice": {
            lte: request.price.max,
          },
        },
      });
    }
  }

  if (request.size) {
    if (
      request.size.min &&
      !isNaN(request.size.max) &&
      request.size.max &&
      !isNaN(request.size.max)
    ) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
            lte: request.size.max,
          },
        },
      });
    } else if (request.size.min && !isNaN(request.size.min)) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
          },
        },
      });
    } else if (request.size.max && !isNaN(request.size.max)) {
      qMust.push({
        range: {
          "attribute.builtUpArea": {
            lte: request.size.max,
          },
        },
      });
    }
  }

  if (request.flag) {
    if (request.flag === EPropertyFlag.FEATURED) {
      qMust.push({
        match: {
          "searchCriteria.isFeatured": true,
        },
      });
    } else if (request.flag === EPropertyFlag.GREAT_PRICE) {
      qMust.push({
        match: {
          "searchCriteria.isGreatPrice": true,
        },
      });
    } else if (request.flag === EPropertyFlag.HIGH_INVESTMENT_RETURN) {
      qMust.push({
        match: {
          "searchCriteria.isHighInvestmentReturn": true,
        },
      });
    } else {
    }
  }
  if (request.sort) {
    if (request.sort === EPropertySort.RELEVENCE) {
      qSort.push({
        publishedAt: {
          order: "desc",
        },
      });
    } else if (request.sort === EPropertySort.EXCLUSIVE) {
      qSort.push({
        isExclusive: {
          order: "desc",
        },
      });
    } else if (request.sort === EPropertySort.PRICE_LOW_TO_HIGH) {
      qSort.push({
        "attribute.salePrice": {
          order: "asc",
        },
      });
    } else if (request.sort === EPropertySort.PRICE_HIGH_TO_LOW) {
      qSort.push({
        "attribute.salePrice": {
          order: "desc",
        },
      });
    } else {
      qSort.push({
        publishedAt: {
          order: "desc",
        },
      });
    }
  }
  /*
   * there are match array assign
   */
  if (qMust.length > EZero.ZERO) {
    qOmust.query.bool.must = qMust;
    Object.assign(EQuery, qOmust);
  }

  if (qSort.length > EZero.ZERO) {
    qOsort.sort = qSort;
    Object.assign(EQuery, qOsort);
  }

  if (request.from && request.to) {
    EQuery.from = request.from;
    EQuery.size = request.to;
  } else {
    EQuery.from = EZero.ZERO;
    EQuery.size = EPagination.PER_PAGE_COUNT;
  }
  console.log(EQuery);
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQuery
    );
    const { hits, total } = response.data.hits;
    result.status = true;
    result.data = {
      result: hits,
      total: total.value,
    };
    return result;
  } catch (error) {
    throw error;
  }
};
