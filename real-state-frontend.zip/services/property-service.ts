import axios, { AxiosResponse } from "axios";
import { TResultSet, TFilter, TTag } from "../types";

import {
  EQSearchPropertyList,
  EQRecommendedPropertyFORKSA,
  EQRecommendedPropertyFORInternational,
} from "../utils/elastic-queries";

/**
 * Get the search masters
 * @return result: TResultSet
 */
export const getRecommendedKSAProperties = async (): Promise<TResultSet> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORKSA
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const getRecommendedInternationalProperties = async (): Promise<
  TResultSet
> => {
  let result: TResultSet = {
    status: false,
    data: [],
  };
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQRecommendedPropertyFORInternational
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.message = error.message;
  }
  return result;
};

/**
 * Get the property search List
 * @return void
 */
export const getFilteredProperties = async (
  request: TFilter
): Promise<TResultSet> => {
  let result: TResultSet = {};
  const query = EQSearchPropertyList;

  const qMust = [];
  const qSort = [];

  const qOmust = {
    query: {
      bool: {
        must: {},
      },
    },
  };
  const qOsort = {
    sort: {},
  };

  if (request.for) {
    qMust.push({
      match: {
        "searchCriteria.propertyForId": request.for,
      },
    });
  }
  if (request.type) {
    qMust.push({
      match: {
        "searchCriteria.propertyMainTypeId": request.type,
      },
    });
  }
  if (request.sub_type) {
    qMust.push({
      match: {
        "searchCriteria.propertySubTypeId": request.sub_type,
      },
    });
  }
  if (request.bedrooms) {
    qMust.push({
      match: {
        "attribute.noOfBedrooms": request.bedrooms,
      },
    });
  }
  if (request.bathrooms) {
    qMust.push({
      match: {
        "attribute.noOfBathrooms": request.bathrooms,
      },
    });
  }

  if (request.locations) {
    request.locations.map((location: any) => {
      if (location.model == "country") {
        qMust.push({
          match: {
            "searchCriteria.countryId": location.model_id,
          },
        });
      }
      if (location.model == "city") {
        qMust.push({
          match: {
            "searchCriteria.cityId": location.model_id,
          },
        });
      }
      if (location.model == "zone") {
        qMust.push({
          match: {
            "searchCriteria.zoneId": location.model_id,
          },
        });
      }
    });
  }

  if (request.price) {
    if (request.size.min && request.size.max) {
      qSort.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
            lte: request.price.max,
          },
        },
      });
    } else if (request.price.min) {
      qSort.push({
        range: {
          "attribute.salePrice": {
            gte: request.price.min,
          },
        },
      });
    } else if (request.price.max) {
      qSort.push({
        range: {
          "attribute.salePrice": {
            lte: request.price.max,
          },
        },
      });
    }
  }

  if (request.size) {
    if (request.size.min && request.size.max) {
      qSort.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
            lte: request.size.max,
          },
        },
      });
    } else if (request.size.min) {
      qSort.push({
        range: {
          "attribute.builtUpArea": {
            gte: request.size.min,
          },
        },
      });
    } else if (request.size.max) {
      qSort.push({
        range: {
          "attribute.builtUpArea": {
            lte: request.size.max,
          },
        },
      });
    }
  }
  /*
   * there are match array assign
   */
  if (qMust.length > 0) {
    qOmust.query.bool.must = qMust;
  }

  qOsort.sort = qSort;
  query.from = 0;
  query.size = 10;

  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      query
    );
    result.status = true;
    result.data = response.data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};
