import axios, { AxiosResponse } from "axios";
import { TResultSet, TTag } from "../types";

/**
 * Get the search elements
 * @param locale: string
 * @return TResultSet
 */
export const mainSearchElements = async (
  locale: string
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/search-elements`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the locations of the for rent
 * @param locale: string
 * @param category: number
 * @return TResultSet
 */
export const forRentLocations = async (locale: string, category: number) => {
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/cities-for-rent/${category}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the locations of the for sale
 * @param locale: string
 * @param category: number
 * @return TResultSet
 */
export const forSaleLocations = async (
  locale: string,
  category: number
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/cities-for-sale/${category}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the locations of international
 * @param locale: string
 * @param category: string
 * @return TResultSet
 */
export const internationalLocations = async (
  locale: string,
  category: string
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/country-for-international/${category}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the property types
 * @param locale: string
 * @param category: string
 * @return TResultSet
 */
export const propertyTypes = async (
  locale: string,
  type: string
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.get(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/property-types/${type}`,
      {
        headers: {
          locale: locale,
        },
      }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the autocomplete location
 * @param locale: string
 * @param keyword: string
 * @param tags: object
 * @return TResultSet
 */
export const autocompleteLocations = async (
  locale: string,
  keyword: string,
  tags: TTag[]
): Promise<TResultSet> => {
  let result: TResultSet = {};
  try {
    let body: object = {};
    if (tags.length > 0) {
      body = {
        keyword: keyword,
        model_id: tags[tags.length - 1].model_id,
        model: tags[tags.length - 1].model,
      };
    } else {
      body = { keyword: keyword };
    }
    const response = await axios.post(
      `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/locations`,
      body,
      { headers: { locale: locale } }
    );
    const { data } = response.data;
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};
