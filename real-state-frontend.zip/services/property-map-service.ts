import axios, { AxiosResponse } from "axios";
import { TResultSet } from "../types";
import {
  EQSearchPropertyOnMap,
  EQSearchPropertyList,
  EQClusterProperty,
  EQPolygonPropertyLatLng,
  EQPolygonPropertyList
} from "../utils/elastic-properties-map-queries";

/**
 * Get the search masters
 * @return result: TResultSet
 */
export const searchPropertiesOnMap = async (): Promise<TResultSet> => {    
  let result: TResultSet = {};
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      // 'http://176.227.193.212:9900/properties/property_development_test_mapping/_search',
      EQSearchPropertyOnMap
    );
    const { hits } = response.data.hits;
    result.status = true;
    result.data = hits;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const searchPropertiesListOnMap = async (from: number, noofproperties: number): Promise<
  TResultSet
> => {
  let result: TResultSet = {};
  const query: any = EQSearchPropertyList;
  query.from = from;
  query.size = noofproperties;
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      EQSearchPropertyList       
    );
    const { hits, total } = response.data.hits;
    const data = {"total": total.value, "result": hits};
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const propertiesOfClusterOnMap = async (ids: number[], from: number, noofproperties: number): Promise<
  TResultSet
> => {
  let result: TResultSet = {};
  const query: any = EQClusterProperty;
  query.from = from;
  query.size = noofproperties;
  query.query.bool.filter.terms.id = ids;
  try {
    const response: AxiosResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      query
    );
    const { hits, total } = response.data.hits;    
    const data = {"total": total.value, "result": hits};
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};

/**
 * Get the search masters
 * @return result: ResultSet
 */
export const propertiesInPolygonOnMap = async (points: { "lat": string, "lon": string }[]): Promise<
  TResultSet
> => {
  let result: TResultSet = {};
  const query: any = EQPolygonPropertyLatLng;  
  query.query.bool.filter.geo_polygon.location.points = points;
  try {
    const response: AxiosResponse = await axios.post(
      // `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      'http://176.227.193.212:9900/properties/property_development_test_mapping/_search',
      query
    );
    const { hits, total } = response.data.hits;    
    const data = {"total": total.value, "result": hits};
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};
/**
 * Get the search masters
 * @return result: ResultSet
 */
export const propertiesListInPolygonOnMap = async (points: { "lat": string, "lon": string }[], from: number, noofproperties: number): Promise<
  TResultSet
> => {
  let result: TResultSet = {};
  const query: any = EQPolygonPropertyList;
  query.from = from;
  query.size = noofproperties;
  query.query.bool.filter.geo_polygon.location.points = points;
  try {
    const response: AxiosResponse = await axios.post(
      // `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
      'http://176.227.193.212:9900/properties/property_development_test_mapping/_search',
      query
    );
    const { hits, total } = response.data.hits;    
    const data = {"total": total.value, "result": hits};
    result.status = true;
    result.data = data;
  } catch (error) {
    result.status = false;
    result.message = error.message;
  }
  return result;
};