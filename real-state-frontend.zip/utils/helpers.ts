import { TFLocation, TTag, TTagRequest } from "../types";

/**
 * Get locations from autocomplete
 */
export const getLocationFromAutocomplete = (locations: Array<TTag>) => {
  let locationObj: TFLocation = {};
  if (locations) {
    locations.map((location: TTag) => {
      if (location.model == "country") {
        locationObj = { ...locationObj, country: location.model_id };
      } else if (location.model == "state") {
        locationObj = { ...locationObj, state: location.model_id };
      } else if (location.model == "city") {
        locationObj = { ...locationObj, city: location.model_id };
      } else if (location.model == "zone") {
        locationObj = { ...locationObj, zone: location.model_id };
      } else {
      }
    });
  }
  return locationObj;
};

/**
 * Get tag request from filters
 */
export const getTagRequestFromFilters = (locations: Array<TTag>) => {
  let locationObj: Array<TTagRequest> = [];
  if (locations) {
    locations.map((location: TTag) => {
      if (location.model == "country") {
        locationObj.push({
          model: "country",
          model_id: location.model_id,
        });
      } else if (location.model == "state") {
        locationObj.push({
          model: "state",
          model_id: location.model_id,
        });
      } else if (location.model == "city") {
        locationObj.push({
          model: "city",
          model_id: location.model_id,
        });
      } else if (location.model == "zone") {
        locationObj.push({
          model: "zone",
          model_id: location.model_id,
        });
      } else {
      }
    });
  }
  return locationObj;
};

/**
 * Get filters from params
 */
export const getFiltersFromParams = async (
  params: any,
  query: any
): Promise<{}> => {
  const filterObj = {
    for: params.slug || "",
    type: query.type || "",
    sub_type: query.category || "",
    locations: [{}],
    country: query.country || "",
    bedrooms: query.bedrooms || "",
    bathrooms: query.bathrooms || "",
    price: { min: query.min_price || "Any", max: query.max_price || "Any" },
    size: { min: query.min_size || "Any", max: query.max_size || "Any" },
  };
  if (query.country) {
    filterObj.locations.push({
      model: "country",
      model_id: query.country,
    });
  }
  if (query.state) {
    filterObj.locations.push({
      model: "state",
      model_id: query.state,
    });
  }
  if (query.city) {
    filterObj.locations.push({
      model: "city",
      model_id: query.city,
    });
  }
  if (query.zone) {
    filterObj.locations.push({
      model: "zone",
      model_id: query.zone,
    });
  }
  return filterObj;
};
