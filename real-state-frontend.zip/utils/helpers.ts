import { TFilter, TFLocation, TTag, TTagRequest } from "../types";

/**
 * Get locations from autocomplete
 */
export const getLocationFromAutocomplete = async (
  locations: Array<TTag>
): Promise<TFLocation> => {
  let locationObj: TFLocation = {};
  if (locations) {
    locations.map((location: TTag) => {
      if (location.model == "country") {
        locationObj = { ...locationObj, country: location.model_id };
      } else if (location.model == "state") {
        locationObj = { ...locationObj, state: location.model_id };
      } else if (location.model == "city") {
        locationObj = { ...locationObj, city: location.model_id };
      } else if (location.model == "zone") {
        locationObj = { ...locationObj, zone: location.model_id };
      } else {
      }
    });
  }
  return locationObj;
};

/**
 * Get tag request from filters
 */
export const getTagRequestFromFilters = (locations: Array<TTag>) => {
  let locationObj: Array<TTagRequest> = [];
  if (locations) {
    locations.map((location: TTag) => {
      if (location.model == "country") {
        locationObj.push({
          model: "country",
          model_id: location.model_id,
        });
      } else if (location.model == "state") {
        locationObj.push({
          model: "state",
          model_id: location.model_id,
        });
      } else if (location.model == "city") {
        locationObj.push({
          model: "city",
          model_id: location.model_id,
        });
      } else if (location.model == "zone") {
        locationObj.push({
          model: "zone",
          model_id: location.model_id,
        });
      } else {
      }
    });
  }
  return locationObj;
};

/**
 * Get filters from params
 */
export const getRequestFromFilters = async (filters: TFilter): Promise<any> => {
  let filterObj = {
    for: filters.for || "",
    type: filters.type || "",
    sub_type: filters.sub_type || "",
    bedrooms: filters.bedrooms || "",
    bathrooms: filters.bathrooms || "",
    price: { min: filters.price.min || "Any", max: filters.price.max || "Any" },
    size: { min: filters.size.min || "Any", max: filters.size.max || "Any" },
    country: "" /*filters.country || EPropertyRegionValue.KSA*/,
    state: "",
    city: "",
    zone: "",
  };
  const locations = await getLocationFromAutocomplete(
    filters.locations as TTag[]
  );
  if (locations.hasOwnProperty("country")) {
    filterObj = { ...filterObj, country: locations.country as string };
  }
  if (locations.hasOwnProperty("state")) {
    filterObj = { ...filterObj, state: locations.state as string };
  }
  if (locations.hasOwnProperty("city")) {
    filterObj = { ...filterObj, city: locations.city as string };
  }
  if (locations.hasOwnProperty("zone")) {
    filterObj = { ...filterObj, zone: locations.zone as string };
  }
  return filterObj;
};

/**
 * Get filters from params
 */
export const getFiltersFromParams = async (
  params: any,
  query: any
): Promise<{}> => {
  let filterObj = {
    for: params.slug || "",
    type: query.type || "",
    sub_type: query.category || "",
    bedrooms: query.bedrooms || "",
    bathrooms: query.bathrooms || "",
    price: { min: query.min_price || "Any", max: query.max_price || "Any" },
    size: { min: query.min_size || "Any", max: query.max_size || "Any" },
  };
  let locations: any = [];
  if (query.country) {
    locations.push({
      model: "country",
      model_id: query.country,
    });
  }
  if (query.state) {
    locations.push({
      model: "state",
      model_id: query.state,
    });
  }
  if (query.city) {
    locations.push({
      model: "city",
      model_id: query.city,
    });
  }
  if (query.zone) {
    locations.push({
      model: "zone",
      model_id: query.zone,
    });
  }
  if (locations) {
    Object.assign(filterObj, { locations: locations });
  }
  return filterObj;
};
