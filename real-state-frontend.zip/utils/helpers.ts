import { TFLocation, TTag } from "../types";
import { EPropertyFor } from "../utils";

/**
 * Get locations from autocomplete
 */
export const getLocationFromAutocomplete = (locations: Array<TTag> | null) => {
  let locationObj: TFLocation = {};
  if (locations) {
    locations.map((location: TTag) => {
      if (location.model == "country") {
        locationObj = { ...locationObj, country: location.model_id };
      } else if (location.model == "state") {
        locationObj = { ...locationObj, state: location.model_id };
      } else if (location.model == "city") {
        locationObj = { ...locationObj, city: location.model_id };
      } else if (location.model == "zone") {
        locationObj = { ...locationObj, zone: location.model_id };
      } else {
      }
    });
  }
  return locationObj;
};

/**
 * Get filters from params
 */
export const getFiltersFromParams = async (params: any, query: any) => {
  const filterObj = {
    for: params.slug || "",
    type: query.type || "",
    sub_type: query.category || "",
    country: query.country || "",
    bedrooms: query.bedrooms || "",
    bathrooms: query.bathrooms || "",
    price: { min: query.min_price || "Any", max: query.max_price || "Any" },
    size: { min: query.min_size || "Any", max: query.max_size || "Any" },
  };
  return filterObj;
};
