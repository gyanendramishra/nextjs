/**
 * Beadroom list constants
 */

export const beadroomList = [
    1,
    2,
    3,
    5,
    5,
    6,
    7,
    8,
    9,
    10
]

/**
 * Bathroom list constants
 */

export const bathroomList = [
  1,
  2,
  3,
  5,
  5,
  6,
  7,
  8,
  9,
  10
]

/**
 * Min max priceList constants
 */

export const priceList = {
    min: [
        0,
        500,
        800,
        1000,
        1500,
        2500,
        3000
    ],
    max: [
      500,
      800,
      1000,
      1500,
      2500,
      3000
    ],
}

/**
 * Min max size list constants
 */

export const sizeList = {
  min: [
      0,
      500,
      800,
      1000,
      1500,
      2500,
      3000
  ],
  max: [
    500,
    800,
    1000,
    1500,
    2500,
    3000
  ],
}

