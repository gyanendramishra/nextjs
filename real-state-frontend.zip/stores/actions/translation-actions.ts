export type TTranslationAction = {
  LANGUAGE_CHANGED: string;
  LANGUAGE_CHANGE_FAILED: string;
};

export const translationActions: TTranslationAction = {
  LANGUAGE_CHANGED: "LANGUAGE_CHANGED",
  LANGUAGE_CHANGE_FAILED: "LANGUAGE_CHANGE_FAILED",
};

export const languageChanged = (language: string) => {
  return {
    type: translationActions.LANGUAGE_CHANGED,
    payload: {
      language: language,
    },
  };
};

export const languageChangeFailed = (error: any) => {
  return {
    type: translationActions.LANGUAGE_CHANGED,
    error,
  };
};
