export type TSearchAction = {
  FOR_FILTER_CHANGED: string;
  TYPE_FILTER_CHANGED: string;
  SUB_TYPE_FILTER_CHANGED: string;
  BEDROOM_FILTER_CHANGED: string;
  BATHROOM_FILTER_CHANGED: string;
  PRICE_FILTER_CHANGED: string;
  SIZE_FILTER_CHANGED: string;
  COUNTRY_FILTER_CHANGED: string;
  FILTER_CHANGE_FAILED: string;
};

export const searchActions: TSearchAction = {
  FOR_FILTER_CHANGED: "FOR_FILTER_CHANGED",
  TYPE_FILTER_CHANGED: "TYPE_FILTER_CHANGED",
  SUB_TYPE_FILTER_CHANGED: "SUB_TYPE_FILTER_CHANGED",
  BEDROOM_FILTER_CHANGED: "BEDROOM_FILTER_CHANGED",
  BATHROOM_FILTER_CHANGED: "BATHROOM_FILTER_CHANGED",
  PRICE_FILTER_CHANGED: "PRICE_FILTER_CHANGED",
  SIZE_FILTER_CHANGED: "SIZE_FILTER_CHANGED",
  COUNTRY_FILTER_CHANGED: "COUNTRY_FILTER_CHANGED",
  FILTER_CHANGE_FAILED: "FILTER_CHANGE_FAILED",
};

export const forFilterChanged = (propertyFor: string) => {
  return {
    type: searchActions.FOR_FILTER_CHANGED,
    payload: {
      for: propertyFor,
    },
  };
};

export const typeFilterChanged = (propertyType: string) => {
  //alert(propertyType);
  return {
    type: searchActions.TYPE_FILTER_CHANGED,
    payload: {
      type: propertyType,
    },
  };
};

export const subTypeFilterChanged = (propertySubType: string) => {
  return {
    type: searchActions.SUB_TYPE_FILTER_CHANGED,
    payload: {
      sub_type: propertySubType,
    },
  };
};
export const beadroomsFilterChanged = (beadrooms: string) => {
  return {
    type: searchActions.BEDROOM_FILTER_CHANGED,
    payload: {
      beadrooms: beadrooms,
    },
  };
};

export const bathroomsFilterChanged = (bathrooms: string) => {
  return {
    type: searchActions.BATHROOM_FILTER_CHANGED,
    payload: {
      bathrooms: bathrooms,
    },
  };
};

export const priceFilterChanged = (minPrice: number, maxPrice: number) => {
  return {
    type: searchActions.PRICE_FILTER_CHANGED,
    payload: {
      minPrice: minPrice,
      maxPrice: maxPrice,
    },
  };
};

export const sizeFilterChanged = (minSize: number, maxSize: number) => {
  return {
    type: searchActions.SIZE_FILTER_CHANGED,
    payload: {
      minSize: minSize,
      maxSize: maxSize,
    },
  };
};

export const countryFilterChanged = (country: string) => {
  return {
    type: searchActions.COUNTRY_FILTER_CHANGED,
    payload: {
      country: country,
    },
  };
};

export const filterChangeFailed = (error: any) => {
  return {
    type: searchActions.FILTER_CHANGE_FAILED,
    error,
  };
};
