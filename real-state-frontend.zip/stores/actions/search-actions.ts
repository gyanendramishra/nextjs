export type TSearchAction = {
  FOR_FILTER_CHANGED: string;
  TYPE_FILTER_CHANGED: string;
  SUB_TYPE_FILTER_CHANGED: string;
  BEDROOM_FILTER_CHANGED: string;
  BATHROOM_FILTER_CHANGED: string;
  PRICE_FILTER_CHANGED: string;
  SIZE_FILTER_CHANGED: string;
  COUNTRY_FILTER_CHANGED: string;
  FILTER_CHANGE_FAILED: string;
};

export const searchAction: TSearchAction = {
  FOR_FILTER_CHANGED: "FOR_FILTER_CHANGED",
  TYPE_FILTER_CHANGED: "TYPE_FILTER_CHANGED",
  SUB_TYPE_FILTER_CHANGED: "SUB_TYPE_FILTER_CHANGED",
  BEDROOM_FILTER_CHANGED: "BEDROOM_FILTER_CHANGED",
  BATHROOM_FILTER_CHANGED: "BATHROOM_FILTER_CHANGED",
  PRICE_FILTER_CHANGED: "PRICE_FILTER_CHANGED",
  SIZE_FILTER_CHANGED: "SIZE_FILTER_CHANGED",
  COUNTRY_FILTER_CHANGED: "COUNTRY_FILTER_CHANGED",
  FILTER_CHANGE_FAILED: "FILTER_CHANGE_FAILED",
};

export const forFilterChanged = (propertyFor: string) => {
  return {
    type: searchAction.FOR_FILTER_CHANGED,
    payload: {
      for: propertyFor,
    },
  };
};

export const typeFilterChanged = (propertyType: string) => {
  return {
    type: searchAction.TYPE_FILTER_CHANGED,
    payload: {
      type: propertyType,
    },
  };
};

export const subTypeFilterChanged = (propertySubType: string) => {
  return {
    type: searchAction.SUB_TYPE_FILTER_CHANGED,
    payload: {
      subType: propertySubType,
    },
  };
};
export const beadroomsFilterChanged = (beadrooms: string) => {
  return {
    type: searchAction.BEDROOM_FILTER_CHANGED,
    payload: {
      beadrooms: beadrooms,
    },
  };
};

export const bathroomsFilterChanged = (bathrooms: string) => {
  return {
    type: searchAction.BATHROOM_FILTER_CHANGED,
    payload: {
      bathrooms: bathrooms,
    },
  };
};

export const priceFilterChanged = (minPrice: number, maxPrice: number) => {
  return {
    type: searchAction.PRICE_FILTER_CHANGED,
    payload: {
      minPrice: minPrice,
      maxPrice: maxPrice,
    },
  };
};

export const sizeFilterChanged = (minSize: number, maxSize: number) => {
  return {
    type: searchAction.SIZE_FILTER_CHANGED,
    payload: {
      minSize: minSize,
      maxSize: maxSize,
    },
  };
};

export const countryFilterChanged = (country: string) => {
  return {
    type: searchAction.COUNTRY_FILTER_CHANGED,
    payload: {
      country: country,
    },
  };
};

export const filterChangeFailed = (error: any) => {
  return {
    type: searchAction.FILTER_CHANGE_FAILED,
    error,
  };
};
