import { TSearchAction } from "../../types";

export const searchActions: TSearchAction = {
  FOR_FILTER_CHANGED: "FOR_FILTER_CHANGED",
  TYPE_FILTER_CHANGED: "TYPE_FILTER_CHANGED",
  SUB_TYPE_FILTER_CHANGED: "SUB_TYPE_FILTER_CHANGED",
  BEDROOM_FILTER_CHANGED: "BEDROOM_FILTER_CHANGED",
  BATHROOM_FILTER_CHANGED: "BATHROOM_FILTER_CHANGED",
  PRICE_FILTER_CHANGED: "PRICE_FILTER_CHANGED",
  SIZE_FILTER_CHANGED: "SIZE_FILTER_CHANGED",
  COUNTRY_FILTER_CHANGED: "COUNTRY_FILTER_CHANGED",
  FILTER_CHANGE_FAILED: "FILTER_CHANGE_FAILED",
  LOCATION_FILTER_CHANGED: "LOCATION_FILTER_CHANGED",
  ADVANCE_SEARCH_FILTER_CHANGED: "ADVANCE_SEARCH_FILTER_CHANGED",
};

export const forFilterChanged = (propertyFor: string) => {
  return {
    type: searchActions.FOR_FILTER_CHANGED,
    payload: {
      for: propertyFor,
    },
  };
};

export const typeFilterChanged = (propertyType: string) => {
  return {
    type: searchActions.TYPE_FILTER_CHANGED,
    payload: {
      type: propertyType,
    },
  };
};

export const advanceSearchFilterChanged = (advanceSearch: boolean) => {
  return {
    type: searchActions.ADVANCE_SEARCH_FILTER_CHANGED,
    payload: {
      advanceSearch: advanceSearch,
    },
  };
};

export const filterChangeFailed = (error: any) => {
  return {
    type: searchActions.FILTER_CHANGE_FAILED,
    error,
  };
};

export const locationFilterChanged = (location: Array<{}>) => {
  return {
    type: searchActions.LOCATION_FILTER_CHANGED,
    payload: {
      type: location,
    },
  };
};
