import { AnyAction } from "redux";
import { HYDRATE } from "next-redux-wrapper";
import { translationActions } from "../actions";

type translationStateType = {
  error: boolean;
  language: string;
};

const translationState: translationStateType = {
  error: false,
  language: "en",
};

export function translationReducer(
  state: translationStateType = translationState,
  action: AnyAction
) {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    case translationActions.LANGUAGE_CHANGE_FAILED:
      return {
        ...state,
        ...{ error: action.error },
      };

    case translationActions.LANGUAGE_CHANGED:
      return {
        ...state,
        ...{ language: action.payload.language },
      };

    default:
      return state;
  }
}

export default translationReducer;
