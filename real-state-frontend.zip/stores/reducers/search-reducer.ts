import { AnyAction } from "redux";
import { HYDRATE } from "next-redux-wrapper";
import { searchActions } from "../actions";
import { EPropertyFor, EPropertyType } from "../../utils";

type searchStateType = {
  error: boolean;
  for: string;
  type: string;
  locations: string | null;
  category: number | null;
  country: number | null;
};

const searchState: searchStateType = {
  error: false,
  for: EPropertyFor.RENT,
  type: EPropertyType.RESIDENTIAL,
  locations: null,
  category: null,
  country: null,
};

export function searchReducer(
  state: searchStateType = searchState,
  action: AnyAction
) {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    case searchActions.FOR_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: { for: action.payload.for } },
      };

    case searchActions.TYPE_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: { type: action.payload.type } },
      };

    case searchActions.SUB_TYPE_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: action.payload.sub_type },
      };

    case searchActions.BEDROOM_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: action.payload.beadrooms },
      };

    case searchActions.BATHROOM_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: action.payload.bathrooms },
      };

    case searchActions.PRICE_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: action.payload },
      };

    case searchActions.SIZE_FILTER_CHANGED:
      return {
        ...state,
        ...{ filters: action.payload },
      };

    default:
      return state;
  }
}

export default searchReducer;
