import { AnyAction } from "redux";
import { HYDRATE } from "next-redux-wrapper";
import { searchActions } from "../actions";
import { EPropertyFor } from "../../utils";
import { TSSearch } from "../../types";

const searchState: TSSearch = {
  for: EPropertyFor.SALE,
};

export function searchReducer(
  state: TSSearch = searchState,
  action: AnyAction
) {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    case searchActions.FOR_FILTER_CHANGED:
      return {
        ...state,
        ...{ for: action.payload.for },
      };

    default:
      return state;
  }
}

export default searchReducer;
