import { AnyAction } from "redux";
import { HYDRATE } from "next-redux-wrapper";
import { searchActions } from "../actions";
import { TSSearch } from "../../types";
import { EPropertyFor, EPropertyType } from "../../utils";

const searchState: TSSearch = {
  for: EPropertyFor.RENT,
  type: EPropertyType.RESIDENTIAL,
  locations: null,
  category: null,
  country: null,
};

export function searchReducer(
  state: TSSearch = searchState,
  action: AnyAction
) {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    case searchActions.FOR_FILTER_CHANGED:
      return {
        ...state,
        ...{ for: action.payload.for },
      };

    case searchActions.TYPE_FILTER_CHANGED:
      return {
        ...state,
        ...{ type: action.payload.type },
      };

    case searchActions.SUB_TYPE_FILTER_CHANGED:
      return {
        ...state,
        ...{ sub_type: action.payload.sub_type },
      };

    case searchActions.BEDROOM_FILTER_CHANGED:
      return {
        ...state,
        ...{ beadrooms: action.payload.beadrooms },
      };

    case searchActions.BATHROOM_FILTER_CHANGED:
      return {
        ...state,
        ...{ bathrooms: action.payload.bathrooms },
      };

    case searchActions.PRICE_FILTER_CHANGED:
      return {
        ...state,
        ...{ price: action.payload },
      };

    case searchActions.SIZE_FILTER_CHANGED:
      return {
        ...state,
        ...{ size: action.payload },
      };

    default:
      return state;
  }
}

export default searchReducer;
