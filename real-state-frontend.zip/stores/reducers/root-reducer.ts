import { combineReducers } from "redux";
import { translationReducer } from "./";

const rootReducer = combineReducers({
  translation: translationReducer,
});

export default rootReducer;
