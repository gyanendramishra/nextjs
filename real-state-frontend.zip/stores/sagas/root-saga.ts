import { all } from "redux-saga/effects";

import TranslationSaga from "./translation-saga";

function* rootSaga() {
  yield all([...TranslationSaga]);
}

export default rootSaga;
