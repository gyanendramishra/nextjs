import { all } from "redux-saga/effects";

import SearchSaga from "./search-saga";

function* rootSaga() {
  yield all([...SearchSaga]);
}

export default rootSaga;
