import { all } from "redux-saga/effects";

import SearchSaga from "./search-saga";
import TranslationSaga from "./translation-saga";

function* rootSaga() {
  yield all([...TranslationSaga, ...SearchSaga]);
}

export default rootSaga;
