import { call, put, take } from "redux-saga/effects";

import { searchActions } from "../actions";

function* forFilterChnagedSaga() {
  try {
    const filter = yield take(searchActions.FOR_FILTER_CHANGED);
    yield put({
      type: searchActions.FOR_FILTER_CHANGED,
      payload: filter.payload,
    });
  } catch (error) {
    yield put({ type: searchActions.FILTER_CHANGE_FAILED, error });
    console.log(error);
  }
}

export default [call(forFilterChnagedSaga)];
