import { call, put, take } from "redux-saga/effects";

import { translationActions } from "../actions";

function* runTranslationSaga() {
  try {
    const language = yield take(translationActions.LANGUAGE_CHANGED);
    yield put({
      type: translationActions.LANGUAGE_CHANGED,
      payload: language.payload,
    });
  } catch (error) {
    yield put({ type: translationActions.LANGUAGE_CHANGE_FAILED, error });
  }
}

export default [call(runTranslationSaga)];
