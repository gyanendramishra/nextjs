import createSagaMiddleware from "redux-saga";
import storage from "redux-persist/lib/storage";
import { createWrapper } from "next-redux-wrapper";
import { applyMiddleware, createStore } from "redux";
import { persistStore, persistReducer } from "redux-persist";
/* App elements */
import rootSaga from "./sagas/root-saga";
import rootReducer from "./reducers/root-reducer";

const persistConfig = {
  key: "root",
  storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const bindMiddleware = (middleware: any) => {
  if (process.env.NODE_ENV !== "production") {
    const { composeWithDevTools } = require("redux-devtools-extension");
    return composeWithDevTools(applyMiddleware(...middleware));
  }
  return applyMiddleware(...middleware);
};

export const makeStore = () => {
  const sagaMiddleware = createSagaMiddleware();
  const store = createStore(persistedReducer, bindMiddleware([sagaMiddleware]));

  (store as any).__PERSISTOR = persistStore(store);
  (store as any).sagaTask = sagaMiddleware.run(rootSaga);
  //const persistor = persistStore(store);
  //return { store, persistor };
  return store;
};

export const wrapper = createWrapper(makeStore, { debug: true });
