import {
  TPSource,
  TPropertyAttribute,
  TPropertyOwner,
  TPropertyFile,
  TPropertyTranslation,
} from "../types/property";

export class Property {
  id: number;
  slug: string;
  attributes: TPropertyAttribute;
  owner: TPropertyOwner;
  files: TPropertyFile;
  en_translations: TPropertyTranslation;
  ar_translations: TPropertyTranslation;
  externalUrl: string;
  externalVideoLink: string;
  isExclusive: boolean;
  isGreatPrice: boolean;
  isHighInvestmentReturn: boolean;
  locale: string;

  /**
   * Create the new property instance
   * @return string
   */
  constructor(property: TPSource, locale: string = "en") {
    this.locale = locale;
    this.id = property._source.id;
    this.slug = property._source.slug;
    this.attributes = property._source.attribute;
    this.owner = property._source.propertyOwner;
    this.files = property._source.propertyFiles;
    this.en_translations = property._source.en;
    this.ar_translations = property._source.ar;
    this.externalUrl = property._source.externalUrl;
    this.externalVideoLink = property._source.externalVideoLink;
    this.isExclusive = property._source.isExclusive;
    this.isGreatPrice = property._source.isGreatPrice;
    this.isHighInvestmentReturn = property._source.isHighInvestmentReturn;
  }

  /**
   * Get the property title
   * @return string
   */
  title = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.title
      : this.en_translations.title;
  };

  /**
   * Get the property address
   * @return string
   */
  address = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.address
      : this.en_translations.address;
  };

  /**
   * Get the property short address
   * @return string
   */
  shortAddress = (): string => {
    return this.locale === "ar"
      ? `${this.ar_translations.city}, ${this.ar_translations.country}`
      : `${this.en_translations.city}, ${this.en_translations.country}`;
  };

  /**
   * Get the property formated price
   * @return string
   */
  formatedPrice() {
    const formatter = new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 0,
    });
    return formatter.format(this.attributes.salePrice);
  }

  /**
   * Get the property area unit type
   * @return string
   */
  areaUnit = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.unitType
      : this.en_translations.unitType;
  };

  /**
   * Get the property price unit type
   * @return string
   */
  priceUnit = (): string => {
    return this.locale === "ar"
      ? this.ar_translations.currencyType
      : this.en_translations.currencyType;
  };

  /**
   * Get the property main images
   * @return array
   */
  mainImages = (): [] => {
    if (Object.keys(this.files) && this.files.mainImages.length) {
      return this.files.mainImages;
    }
    return [];
  };
}
