import React from "react";
import ReactPaginate from 'react-paginate';

/**
 * Import utils, types etc.
 */
import { EPagination } from '../../utils';

/**
 * Import styles
 */
import styles from '../../styles/listing/pagination.module.scss';

type TProps = {
    handlePagination: Function;
    totalResult: number;
}
const Pagination = (props : TProps) => {

    const { handlePagination, totalResult } = props;
    const pageCount = Math.ceil(totalResult/EPagination.PER_PAGE_COUNT);

    /**
     * Handle the pagination
     * @return void
     */
    const handlePaginationClick = (selectedItem: { selected: number; }):void => {
        handlePagination(selectedItem);
    }
    /**
     * Render html
     * @return mix
     */

    return (
        <div className={styles.pagination_block}>
            <ReactPaginate
                previousLabel={'<'}
                nextLabel={'>'}
                breakLabel={'...'}
                pageCount={ pageCount }
                marginPagesDisplayed={10}
                pageRangeDisplayed={EPagination.PAGINATION_LINK_COUNT}
                onPageChange={handlePaginationClick}
                breakClassName={'page-item'}
                breakLinkClassName={'page-link'}
                containerClassName={styles.pagination}
                pageClassName={'page-item'}
                pageLinkClassName={'page-link'}
                previousClassName={'page-item'}
                previousLinkClassName={'page-link'}
                nextClassName={'page-item'}
                nextLinkClassName={'page-link'}
                activeClassName={'active'}
                initialPage={EPagination.INITIAL_PAGE}
            />
        </div>
    );
}
export default Pagination;
