import React, { Component } from "react";
import styles from '../../styles/listing/pagination.module.scss';

import ReactPaginate from 'react-paginate';
// export default class Pagination extends Component {
  // render() {
const Pagination = (props) => {
  
    return (
     <div className={styles.pagination_block}>
       <ReactPaginate
          previousLabel={'<'}
          nextLabel={'>'}
          breakLabel={'...'}
          pageCount={props.pageCount}
          marginPagesDisplayed={10}
          pageRangeDisplayed={3}
          onPageChange={props.handlePageClick}
          breakClassName={'page-item'}
          breakLinkClassName={'page-link'}
          containerClassName={styles.pagination}
          pageClassName={'page-item'}
          pageLinkClassName={'page-link'}
          previousClassName={'page-item'}
          previousLinkClassName={'page-link'}
          nextClassName={'page-item'}
          nextLinkClassName={'page-link'}
          activeClassName={'active'}
          initialPage={0}
          // forcePage={1}
          />
       {/* <ul className={styles.pagination}>
    <li className={`${styles.page_item} ${styles.item_first} ${styles.disabled}`}>
      <a className={styles.page_link}><img src="/images/arrow1.svg" alt=""/></a>
    </li>
    <li className={`${styles.page_item} ${styles.active}`}>
      <a className={styles.page_link} href="#">1</a>
      </li>
      <li className={styles.page_item}>
      <a className={styles.page_link}>2</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link} href="#">3</a>
      </li>
      <li className={styles.page_item}>
      <a className={styles.page_link}>4</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link}>5</a>
    </li>
    <li className={styles.page_item}>
      <a className={styles.page_link}>6</a>
    </li>
      <li className={`${styles.page_item} ${styles.item_last}`}>
      <a className={styles.page_link} href="#"><img src="/images/arrow1.svg" alt=""/></a>
    </li>
  </ul> */}
     </div>
    );
  // }
}

export default Pagination;
