import React from "react";
import { Field } from "formik";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import components
 */

import PropertyType from "@/components/search/property-type";
import MinMaxPicker from "@/components/search/min-max-picker";
import Autocomplete from "@/components/search/autocomplete";

/**
 * Import utill, classes, types and etc
 */
import { TFilter, TTagRequest } from "../../types";
import { bedroomList, bathroomList, priceList, sizeList, EPropertyFor, EPropertyType} from "../../utils";

/**
 * Import styles
 */
import styles from '../../styles/listing/search-filter.module.scss';

type TProps = {
    filters:TFilter;
    styles: TStyle;
    handleTypeOnChange: Function;
    initialAutoCompleteTags: Array<TTagRequest>;
}
type TStyle = {
    readonly [key: string]: string;
}

const SearchFilterWebForm = (props: TProps) => {
    const { t } = useTranslation();
    const { filters, handleTypeOnChange, initialAutoCompleteTags } = props;

    /**
     * Render the html
     */
    return (
        <>
            <div className={styles.search_filter_outer}>
                <div className={styles.search_filter}>
                    <div className={styles.container}>
                        <div className={`${styles.adv_row}`}>
                            <div className={styles.adv_col1}>
                                <Field as="select" className={styles.form_control} name="for">
                                    <option value={EPropertyFor.SALE}>{ t("search:SEARCH_FOR.FOR_SALE") }</option>
                                    <option value={EPropertyFor.RENT}>{ t("search:SEARCH_FOR.FOR_RENT") }</option>
                                </Field>
                            </div>
                            <div className={styles.adv_col1}>
                                <Field
                                    as="select"
                                    name="type"
                                    className={styles.form_control}
                                    onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                                >
                                    <option value={EPropertyType.RESIDENTIAL}>
                                        {t("search:SEARCH_TYPE.RESIDENTIAL")}
                                    </option>
                                    <option value={ EPropertyType.COMMERCIAL }>
                                        {t("search:SEARCH_TYPE.COMMERCIAL")}
                                    </option>
                                </Field>
                            </div>
                            <div className={styles.adv_col1}>
                                <PropertyType
                                    name="sub_type"
                                    lable = { t("search:LABELS.PROPERTY_TYPE")}
                                    category = { filters.type }
                                    styles = { styles }
                                ></PropertyType>
                            </div>
                            <div className={styles.adv_col1}>
                                <Field 
                                    as="select" 
                                    className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                    name="bedrooms" 
                                >
                                    <option value="">{ t("search:LABELS.BEDS") }</option>
                                    { bedroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </Field>
                            </div>
                            <div className={styles.adv_col1}>
                                <Field 
                                    as="select" 
                                    className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                    name="bathrooms" 
                                >
                                    <option value="">{ t("search:LABELS.BATHS") }</option>
                                    { bathroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </Field>
                            </div>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker 
                                    name="price"
                                    initialData= { {min: filters.price.min, max:filters.price.max } }
                                    label={ t("search:LABELS.PRICE") }
                                    options={ priceList }
                                ></MinMaxPicker> 
                            </div>
                        </div>
                        <div className={`${styles.adv_row}`}>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker 
                                    initialData= { {min: filters.size.min, max:filters.size.max } }
                                    name="size"
                                    label={ t("search:LABELS.SIZE") }
                                    options={ sizeList }
                                ></MinMaxPicker>
                            </div>
                            <div className={styles.mobile_residential_dropdown}>
                                <Field
                                    as="select"
                                    name="type"
                                    className={styles.form_control}
                                    onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                                >
                                    <option value={EPropertyType.RESIDENTIAL}>
                                        {t("search:SEARCH_TYPE.RESIDENTIAL")}
                                    </option>
                                    <option value={ EPropertyType.COMMERCIAL }>
                                        {t("search:SEARCH_TYPE.COMMERCIAL")}
                                    </option>
                                </Field>
                            </div>
                            {(filters.for === EPropertyFor.INTERNATIONL) && (
                                <div className={`${styles.adv_col1} ${styles.country_col}`}>
                                    <Field
                                        as="select"
                                        name="country"
                                        className={styles.form_control}
                                    >
                                        <option>country1</option>
                                        <option>country2</option>
                                    </Field>
                                </div>
                            )}
                            <div className={styles.adv_col3}>
                                <Autocomplete 
                                    name="locations"
                                    initialTagRequest= { initialAutoCompleteTags }
                                ></Autocomplete>
                            </div>
                            <div className={styles.adv_col4}>
                                <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>
                                    { t("search:LABELS.FIND") }
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default SearchFilterWebForm;
