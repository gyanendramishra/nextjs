import React, { Component, Props, useEffect, useState } from "react";
import { useTranslation } from 'react-i18next';
import styles from '../../styles/listing/search-filter.module.scss';
// import Autocomplete2 from '../autocomplete2';
// import Autocomplete3 from '../autocomplete3';

import { Formik, Field, Form, FormikHelpers } from "formik";

/**
 * Import component utils
 */
import { bedroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";
import MinMaxPicker from "@/components/search/min-max-picker";
import Autocomplete from "@/components/search/autocomplete";

type TFilter = {
  propertyForId: string;
  propertyMainTypeId: string;
  propertySubTypeId: string | null;
  noOfBedrooms: number | null;
  noOfBathrooms: number | null;
  locations: [] | null;
  price: {min:string, max:string} | null;
  size: {min:string, max:string} | null;
  sortSearch:string;
  selectedPage:number;
  from:number;
  noOfPropertiesOnPage:number;
  
};

// export default class SearchFilter extends Component {
  // render() {
const SearchFilter = (props) => {
    const [filter,setFilter] = useState({
      propertyForId: "3",
      propertyMainTypeId: "3",
      propertySubTypeId:null,
      noOfBedrooms: null,
      noOfBathrooms:  null,
      locations: [],
      price: {min: '',max: ''},
      size: {min:'', max:''},
      sortSearch:'relevence',
      selectedPage:1,
      from:1,
      noOfPropertiesOnPage:3,
    });

    const [categories, setCategories] = useState([]);

    const { t } = useTranslation();

    return (
      <div className={styles.search_filter_outer}>

      {/* Desktop Search Filter */}

       <div className={styles.search_filter}>
       <div className={styles.container}>
       <Formik
              initialValues={
                  filter
              }
              onSubmit={
                  async (values: TFilter, {  }: FormikHelpers<TFilter>) => {
                      console.log(values);
                      props.handleSearchFilter(values);
                      // this.setState({forType:values.propertyForId})
                      // await this.onHandleSubmit(values);
                      //setSubmitting(false);
                  }
              }
              >
              {() => (
                  <Form>
                      <div className={`${styles.adv_row} ${styles.mbl_row}`}>
                          <div className={styles.adv_col1}>
                              <Field as="select" className={styles.form_control} name="propertyForId">
                                  <option value="3">{ t("MAIN_SEARCH.SEARCH_FOR.FOR_SALE") }</option>
                                  <option value="4">{ t("MAIN_SEARCH.SEARCH_FOR.FOR_RENT") }</option>
                              </Field>
                          </div>
                          <div className={styles.adv_col1}>
                              <select className={styles.form_control} name="propertyMainTypeId" onChange={(e)=>{this.getPropertyTypes(e.target.value )}} >
                                  <option value='3'>{ t("MAIN_SEARCH.SEARCH_TYPE.RESIDENTIAL") }</option>
                                  <option value='1'>{ t("MAIN_SEARCH.SEARCH_TYPE.COMMERCIAL") }</option>
                              </select>
                          </div>
                          <div className={styles.adv_col1}>
                              <Field as="select" className={styles.form_control} name="propertySubTypeId">
                                  <option value="">{ t("MAIN_SEARCH.LABELS.PROPERTY_TYPE") }</option>
                                  {categories && categories.map((value, index) => {
                                      return (
                                          <option key={index} value={ value.id }>{ value.name }</option>
                                      );
                                  })}
                              </Field>
                          </div>
                          <div className={styles.adv_col1}>
                              <Field as="select" className={styles.form_control} name="noOfBedrooms">
                                  <option value="">{ t("MAIN_SEARCH.LABELS.BEDS") }</option>
                                  { bedroomList.map((option, index) => {
                                      return (
                                          <option key={index} value={ option }>{ option }</option>
                                      );
                                  })}
                              </Field>
                          </div>
                          <div className={styles.adv_col1}>
                              <Field as="select" className={styles.form_control} name="noOfBathrooms">
                                  <option value="">{ t("MAIN_SEARCH.LABELS.BATHS") }</option>
                                  { bathroomList.map((option, index) => {
                                      return (
                                          <option key={index} value={ option }>{ option }</option>
                                      );
                                  })}
                              </Field>
                          </div>
                          <div className={styles.adv_col2}>
                              <MinMaxPicker 
                                  name="price"
                                  label={ t("MAIN_SEARCH.LABELS.PRICE") }
                                  options={ priceList }
                              ></MinMaxPicker>
                          
                          </div>
                      </div>
                      <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
                          <div className={styles.adv_col2}>
                              <MinMaxPicker 
                                  name="size"
                                  label={ t("MAIN_SEARCH.LABELS.SIZE") }
                                  options={ sizeList }
                              ></MinMaxPicker>
                          </div>
                          <div className={styles.adv_col3}> 
                              <Autocomplete name="locations" containerClass={styles.web_autocomplete}></Autocomplete>
                          </div>
                          
                          <div className={styles.adv_col4}>
                              <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button> <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
                          </div>
                      </div>
                  </Form>
              )}
          </Formik>
         {/* <div className={`${styles.adv_row} ${styles.mbl_row}`}>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>For Sale</option>
                 <option>For Rent</option>
                 <option>International</option>
               </select>
           </div>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
                 <option>Residential</option>
                 <option>Commercial</option>
               </select>
           </div>
            <div className={styles.adv_col1}>
               <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
               </select>
             </div>
            <div className={styles.adv_col1}>
              <select className={styles.form_control}>
                <option>Beds</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5+</option>
              </select>
            </div>
            <div className={styles.adv_col1}>
              <select className={styles.form_control}>
                <option>Baths</option>
              </select>
            </div>
            <div className={styles.adv_col2}>
               <div className={`${styles.form_control} ${styles.click_btn1}`}>
                 <label className={styles.lbl}>Price</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box1}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
         </div>
         <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
         <div className={styles.adv_col2}>
                <div className={`${styles.form_control} ${styles.click_btn2}`}>
                 <label className={styles.lbl}>Size</label>
                 <span className={styles.span}>to</span>
                 <label className={styles.lbl}></label>
               </div>
               <div className={`${styles.price_select_card} ${styles.open_box2}`}>
                 <div className={styles.card_block1}>
                   <div className={styles.card_lt}>
                     <div className={styles.label_value}>MIN:</div>
                     <input type="text" placeholder="0" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>0</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                   <div className={styles.card_rt}>
                     <div className={styles.label_value}>MAX:</div>
                     <input type="text" placeholder="Any" className={styles.form_control}/>
                     <ul className={styles.listing_block}>
                       <li><a className={styles.active}>Any</a></li>
                       <li><a>500</a></li>
                       <li><a>800</a></li>
                       <li><a>1000</a></li>
                       <li><a>1500</a></li>
                       <li><a>2000</a></li>
                       <li><a>2500</a></li>
                       <li><a>3000</a></li>
                     </ul>
                   </div>
                 </div>
                 <div className={styles.btn_outer1}>
                   <a className={styles.close_btn1}>Close</a>
                 </div>
               </div>
             </div>
         <div className={styles.adv_col3}>
         {/* <Autocomplete2></Autocomplete2> */}
         {/* </div>
         <div className={styles.adv_col4}>
           <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button>
           <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
         </div>
         </div> */}
       </div>
    </div>
      
      {/* Desktop Search Filter */}



      {/* Mobile Popup Search Filter */}

       <div className={styles.search_mobile_block_outer}>
       <div className={styles.search_category_nav}>
          <ul className="d-flex">
            <li><a className={styles.active}>For Sale</a></li>
            <li><a>For Rent</a></li>
            <li><a>International</a></li>
          </ul>
          </div>
         

       {/* FOR SALE SECTION */}
          <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>


 {/* FOR RENT SECTION */}
 <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>


 {/* INTERNATIONAL SECTION */}
 <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
           <div className={styles.adv_col_full}>
           {/* <Autocomplete3></Autocomplete3> */}
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
             <option>Residential</option>
             <option>Commercial</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Property Type</option>
               <option>Apartment</option>
               <option>Commercial</option>
               <option>Land</option>
               <option>Private Island</option>
               <option>Villa / Townhouse</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Beds</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5+</option>
             </select>
           </div>
           <div className={styles.adv_col_full}>
             <select className={styles.form_control}>
               <option>Baths</option>
             </select>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Price</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Price</option>
             </select>
             </div>
           </div>
           <div className={styles.min_max_outer}>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Min: Size</option>
             </select>
             </div>
             <div className={styles.wd2}>
               <span>to</span>
             </div>
             <div className={styles.wd1}>
               <select className={styles.form_control}>
               <option>Max: Size</option>
             </select>
             </div>
           </div>
           <div className={styles.adv_col_full}>
           <button type="submit" className={styles.mbl_find_btn}>Find</button>
           </div>
           <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
              <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a>
           </div>
          </div>

       </div>
    
      {/* Mobile Popup Search Filter */}
      </div>
   );
// }
}

export default SearchFilter;
