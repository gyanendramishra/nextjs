import React, { useState, useLayoutEffect } from "react";
import { connect } from 'react-redux';
import { Formik, Form, FormikHelpers } from "formik";

/**
 * Import components
 */

import SearchFilterWebForm from "@/components/listing/search-filter-web-form";
import SearchFilterMobileForm from "@/components/listing/search-filter-mobile-form";

/**
 * Import utill, classes, types and etc
 */
import { TFilter, TSSearch } from "../../types";
import { getTagRequestFromFilters } from "../../utils";
import { forFilterChanged } from "../../stores/actions";

/**
 * Import styles
 */
import styles from '../../styles/listing/search-filter.module.scss';

type TProps = {
    storeFilters: TSSearch;
    initialFilters:TFilter;
    handleSearch: Function;
    dispatchForFilter: Function;
}
const SearchFilter = (props: TProps) => {
    const { initialFilters, handleSearch, dispatchForFilter } = props;
    
    const [isMobile, setIsMobile] = useState<boolean>(false);
    const [advancesearch, setAdvanceSearch] = useState<boolean>(false);
    const [filters, setFilters] = useState<TFilter>(initialFilters);

    /**
     * Handle screen resize
     */
    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }

    /**
     * Handle type on change
     * @param e: React.ChangeEvent<HTMLInputElement>
     */
    const handleTypeOnChange = async (e: React.ChangeEvent<HTMLInputElement>):Promise<string> => {
        const type = e.target.value;
        //const type = (filters.type === EPropertyType.RESIDENTIAL) ? EPropertyType.COMMERCIAL : EPropertyType.RESIDENTIAL;
        setFilters((prevState) => {
            prevState.type = type;
            return ({
                ...prevState
            });
        });
        return type;
    }

    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = async (propertyFor: string): Promise<void> => {
        await dispatchForFilter(propertyFor);
        setFilters((prevState) => {
            prevState.for = propertyFor;
            return({
              ...prevState
            })
          }
        );
       
    };

    const toggleAdvanceSearch = ():void =>{
        if(advancesearch === true){
            setAdvanceSearch(false);
        }else{
            setAdvanceSearch(true);
        }
    }

    /**
     * Handle form on submit
     * @param formData:TFilter
     */
    const onHandleSearch = async (formData:TFilter): Promise<void> => {
        setAdvanceSearch(false);
        await handleSearch(formData);
    }

    /**
     * Seach component
     */
    let searchComponent: {} | null | undefined;

    if(isMobile === true){
        searchComponent = (
            <SearchFilterMobileForm
                filters = { filters }
                styles = { styles }
                advancesearch = { advancesearch }
                toggleAdvanceSearch = { toggleAdvanceSearch }
                changePropertyFor = { changePropertyFor }
                handleTypeOnChange = { handleTypeOnChange }
                initialAutoCompleteTags = { getTagRequestFromFilters(filters.locations as any) }
            />
        );
    }else{
        searchComponent = (
            <SearchFilterWebForm
                filters = { filters }
                styles = { styles }
                handleTypeOnChange = { handleTypeOnChange }
                initialAutoCompleteTags = { getTagRequestFromFilters(filters.locations  as any) }
            />
        )
    }
    
    return (
        <>
            <Formik
                enableReinitialize={ true }
                initialValues={
                    filters
                }
                onSubmit={
                    async (values: TFilter, { setSubmitting }: FormikHelpers<TFilter>) => {
                        await onHandleSearch(values);
                        setSubmitting(false);
                    }
                }
            >
                {() => (
                    <Form>
                        { searchComponent }
                    </Form>
                )}
            </Formik>
        </>
    );
}

const mapDispatchToProps = (dispatch: any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor))
});

const mapStateToProps = (state: any) => ({
    storeFilters:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(SearchFilter);
