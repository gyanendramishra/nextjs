import React from "react";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import utill, classes, types and etc
 */
import { EPropertyFor, EPropertyDisplayMode, EPropertySort } from "utils";

/**
 * Import styles
 */
import styles from '../../styles/listing/property-sort-filter.module.scss';

type TProps = {
    searchFor: string;
    totalResult: number;
    proprtyDisplayMode: string;
    handleSorting: Function;
    switchPropertyDisplayMode : Function;
}

const PropertySortFilter = (props: TProps) => {
    const { searchFor, totalResult, proprtyDisplayMode, handleSorting, switchPropertyDisplayMode } = props;
    const { t } = useTranslation();
    /**
     * Render the Html
     */
    return (

        <div className={styles.sort_lt}>
            <div className={styles.hd_block2}>
                <h2>{ (searchFor === EPropertyFor.SALE) ? t("search:SORT_FILTER.LABELS.PROPRTIES_FOR_SALE_SAUDIA"): t("search:SORT_FILTER.LABELS.PROPRTIES_FOR_RENT_SAUDIA") }</h2>
                <p>{totalResult} { t("search:SORT_FILTER.LABELS.RESULTS") }</p>
            </div>
            <div className={styles.rt_filter}>
                <div className={styles.rt_col1}>
                    <select className={styles.form_control} onChange={(event)=> handleSorting(event)}>
                        <option value={ EPropertySort.RELEVENCE }>{ t("search:SORT_FILTER.LABELS.RELEVANCE") }</option>
                        <option value={ EPropertySort.EXCLUSIVE }>{ t("search:SORT_FILTER.LABELS.EXCLUSIVE") }</option>
                        <option value={ EPropertySort.PRICE_LOW_TO_HIGH }>{ t("search:SORT_FILTER.LABELS.LOW_TO_HIGH") }</option>
                        <option value={ EPropertySort.PRICE_HIGH_TO_LOW }>{ t("search:SORT_FILTER.LABELS.HIGH_TO_LOW") }</option>
                    </select>
                </div>
                <div className={styles.rt_col1}>
                    <a className={styles.form_control}>
                        <i className="icon-pin"></i> {t("search:SORT_FILTER.LABELS.VIEW_VIA_MAP")}
                    </a>
                </div>
                <div className={styles.rt_col2}>
                    <a className={`${styles.grid_btn} ${ (proprtyDisplayMode === EPropertyDisplayMode.GRID) ? styles.active : ''}`} onClick={()=> switchPropertyDisplayMode(EPropertyDisplayMode.GRID) }>
                        {t("search:SORT_FILTER.LABELS.GRID_VIEW")}
                    </a>
                </div>
                <div className={styles.rt_col2}>
                    <a className={`${styles.list_btn} ${ (proprtyDisplayMode === EPropertyDisplayMode.LIST) ? styles.active : ''}`} onClick={()=> switchPropertyDisplayMode(EPropertyDisplayMode.LIST) }>
                        {t("search:SORT_FILTER.LABELS.LIST_VIEW")}
                    </a>
                </div>
            </div>
        </div>
       
    );
}

export default PropertySortFilter;

