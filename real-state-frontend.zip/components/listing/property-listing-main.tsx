import React, { Component } from "react";
// import PropertyItem from "@/components/property/item";
// import PropertyItemList from "@/components/property/Item-list";
// import Pagination from "@/components/listing/Pagination";
import styles from '../../styles/listing/property-listing-main.module.scss';


export default class PropertyListingMain extends Component {
  render() {
    return (
     <div className={styles.property_listing_main}>
       <div className={styles.container}>
         <div className="row">
           <div className="col-md-8">
             <div className={`${styles.grid_view} ${styles.dis_block}`}>
              <div className="row">
                {/* <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div> */}
                {/* <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div> */}
              </div>
             </div>
             <div className={`${styles.list_view} ${styles.dis_none}`}>
               <div className="row">
                 {/* <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div> */}
               </div>
             </div>
             {/* <Pagination></Pagination> */}
           </div>
           <div className="col-md-4">
              <div className={styles.ad_block1}>
                <a href="#"><img src="/images/Add1.svg" alt=""/></a>
              </div>
              <div className={styles.ad_block2}>
                <a href="#"><img src="/images/Add2.svg" alt=""/></a>
              </div>
           </div>
         </div>
       </div>
     </div>
    );
  }
}
