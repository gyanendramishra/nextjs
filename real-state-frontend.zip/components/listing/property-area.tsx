import React from "react";
import { TFunction } from 'next-i18next';
// import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

import styles from '../../styles/listing/property-area.module.scss';


interface Props extends ReactI18nextWithTranslation {
  readonly t: TFunction,
  cityAreaList:any;
}

export default class PropertyArea extends React.Component<Props> {
  render() {
    const{cityAreaList} = this.props;
    
    return (
     <div className={styles.property_area}>
       <div className={styles.container}>
         <div className={styles.area_inr}>
           <ul>
              {cityAreaList.status &&
              cityAreaList.data.data.length>0 &&
                cityAreaList.data.data.map((val:any)=>(
                <li><a href="#">{val.name}</a></li>
                ))
              } 
           </ul>
           <div className={styles.area_rt_btn}><a href="#">View ALL <img src="/images/arrow2.svg" alt=""/></a></div>
         </div>
       </div>
     </div>
    );
  }
}
