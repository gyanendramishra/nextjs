import React, { Component, Props, useEffect, useState } from "react";

import { useRouter } from 'next/router';

import PropertyItem from "@/components/property/item-grid";
import PropertyItemList from "@/components/property/item-list";
import Pagination from "@/components/listing/pagination";
import styles from '../../styles/listing/property-listing-map.module.scss';
import ShowMap from "@/components/map/show-map";

import  decodePolyline from 'decode-google-map-polyline';

import { 
  searchPropertiesOnMap, 
  searchPropertiesListOnMap, 
  propertiesOfClusterOnMap, 
  propertiesInPolygonOnMap,
  propertiesListInPolygonOnMap 
} from '../../services';
import { Property } from '../../classes/property';

type TStates = {
  propertieslatlng: any[],
  properties: any[],
  pageCount: number,
  noOfPropertiesOnPage: number,
  apiCallName: string
  ids: number[],
  selectedPage: number,
  coordinatePoints: any
}

// export default class PropertyListingMain extends Component {
//   render() {
const PropertyListingMain = (props: TProps) =>{

  const router = useRouter();
  const { locale } = useRouter();
    let polygonDataArray: [] = [];
    let polygonData: any = "";
    if(router.query["polygonData"] !== undefined){      
        polygonData = router.query["polygonData"];
        const coordinatePoints = decodePolyline(polygonData);        
        polygonDataArray = coordinatePoints;
    }
    let center: any = {lat: -28.024, lng: 140.887};
        const zoom = 10;
        let places: any = [];

      useEffect(() => {
        async function fetchData() {
            await PropertiesLatLongOnMap();
            await PropertiesListOnMap();
        }
        fetchData();
      },[]); 
    
      const [mapstate, setMapState]:[TStates, Function] = useState({
        propertieslatlng : [],
        properties : props.property,
        pageCount: 0,
        noOfPropertiesOnPage: 4,
        apiCallName: "",
        ids: [],
        selectedPage: 0,
        coordinatePoints: []
    });  

    /*
    * Function for getting 
    * @return void
    */
    const PropertiesLatLongOnMap = async () =>{ 
      const resultOnMap = await searchPropertiesOnMap();        
      if(resultOnMap.status === true){ 
          setMapState((prevState: TStates) => {
              prevState.propertieslatlng = resultOnMap.data;
              prevState.apiCallName = "searchPropertiesOnMap";
              return({
              ...prevState
              })
          });
      }else{
          console.error(resultOnMap.message);
      }
    }
    /*
    * Function for getting 
    * @return void
    */
    const PropertiesListOnMap = async () =>{        
        const result = await searchPropertiesListOnMap(0,mapstate.noOfPropertiesOnPage);
        console.log(result);
        if(result.status === true){
            const noofpage = result.data.total/mapstate.noOfPropertiesOnPage;            
            setMapState((prevState: TStates) => {
                prevState.properties = result.data.result;
                prevState.pageCount = noofpage;
                prevState.apiCallName = "searchPropertiesListOnMap";
                return({
                ...prevState
                })
            });
        }else{
            console.error(result.message);
        }
    }
    
    let propertyJson: {id: number, lat: number, lng: number};
    let properties: any[] = [];
    if(mapstate.propertieslatlng){
      mapstate.propertieslatlng.map((property, index)=>{
          if(index == 0) {
              center = {
                          lat: property._source.propertyLocation.latitude,
                          lng: property._source.propertyLocation.longitude
                       }
          }
          propertyJson = {
                          id: property._source.id, 
                          lat: property._source.propertyLocation.latitude,
                          lng: property._source.propertyLocation.longitude
                         };
          
          places.push(propertyJson);
      });
    }

    if(mapstate.properties){
      mapstate.properties.map((property: any)=>{
          properties.push(property);
      });
    }

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const populateVideo = (src: string): void => {
      // setModal((prevState) => {
      //     prevState.opened = true;
      //     prevState.title = t("RECOMMENDED_PROPERTY.VIDEO_MODAL_TITLE");
      //     prevState.src = src;
      //     return({
      //       ...prevState
      //     })
      //   }
      // );
    }

    const handlePageClick = (data) =>{
        const noOfPropertiesOnPage = mapstate.noOfPropertiesOnPage;
        const from = (data.selected * noOfPropertiesOnPage);
        // let filter = this.state.filter;
        // filter.from = from;
        // this.setState({filter:filter})
        // let paginationData:TData ={from:from, noOfPropertiesOnPage:noOfPropertiesOnPage}
        // this.onHandleSubmit(paginationData)
    }

    return (
     <div className={styles.property_listing_map}>
       <div className={styles.listing_left}>

             <div className={styles.property_sort_filter}>
            <div className={styles.sort_lt}>
            <div className={styles.hd_block2}>
            <h2>Properties for Rent in Saudi Arabia</h2>
            <p>786 results</p>
            </div>
            <div className={styles.rt_filter}>
              <div className={styles.rt_col1}>
              <select className={styles.form_control}>
                 <option>Sort by: All</option>
               </select>
              </div>
              <div className={styles.rt_col1}>
                <a className={styles.form_control}><i className="icon-pin"></i> View On map</a>
              </div>
              <div className={styles.rt_col2}>
                <a className={`${styles.grid_btn} ${styles.active}`} href="#">Grid</a>
              </div>
              <div className={styles.rt_col2}>
              <a className={styles.list_btn}href="#">List</a>
              </div>
            </div>
            </div>
     </div>

             <div className={`${styles.grid_view} ${styles.dis_block}`}>
              <div className="row">
              { properties && properties.map((property)=>{
                    const mProperty = new Property(property, locale);
                    return (
                      <div className="col-md-6">
                        <PropertyItem 
                          property={mProperty}
                          handleVideo={ populateVideo }></PropertyItem>
                      </div>
                    )
                  })
                 }
                {/* <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div>
                <div className="col-md-6">
                <PropertyItem></PropertyItem>
                </div> */}
              </div>
             </div>
            
             <div className={`${styles.list_view} ${styles.dis_none}`}>
               <div className="row">
                 {/* { properties && properties.map((property)=>{
                    <div className="col-md-12">
                      <PropertyItemList property={property}></PropertyItemList>
                    </div>
                  })
                 } */}
                 {/* <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div>
                 <div className="col-md-12">
                   <PropertyItemList></PropertyItemList>
                 </div> */}
               </div>
             </div>
            
             <Pagination pageCount={mapstate.pageCount} handlePageClick={props.handlePageClick}></Pagination>


       </div>
       <div className={styles.map_right}>
         {/* <img className={styles.full_img} src="images/map.jpg" alt=""/> */}
          <ShowMap 
            center={center} 
            zoom={zoom} 
            places={places} 
            polygonData={polygonDataArray}
            // getPropertiesId={(ids: number[])=>{getPropertiesId(ids)}}
            // getPropertiesPolygon={(coordinatesArray: [])=>{getPropertiesPolygon(coordinatesArray)}}
          ></ShowMap>
         <div className={styles.map_search_amenities}>
   <span className={styles.label}>Show</span>
   <div className={styles.list_container}>
      <ul className={styles.list}>
         <li className={styles.list_item}>
         <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="schools" name="layers"></input>
             <label htmlFor="schools" className={styles.input_label}>Schools</label>
        </li>
         <li className={styles.list_item}>
           <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="restaurants" name="layers"></input>
             <label htmlFor="restaurants" className={styles.input_label}>Restaurants</label>
         </li>
      </ul>
      <ul className={`${styles.list} ${styles.list_collapsible}`}>
         <li className={styles.list_item}>
           <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="groceries" name="layers"></input>
             <label htmlFor="groceries" className={styles.input_label}>Groceries</label>
             </li>
         <li className={styles.list_item}>
           <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="medical" name="layers"></input>
             <label htmlFor="medical" className={styles.input_label}>Hospitals</label>
             </li>
         <li className={styles.list_item}>
           <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="religious" name="layers"></input>
             <label htmlFor="religious" className={styles.input_label}>Religious</label>
             </li>
         <li className={styles.list_item}>
           <input type="radio" className={`${styles.radio_button_input} ${styles.input}`} id="fitness" name="layers"></input>
             <label htmlFor="fitness" className={styles.input_label}>Fitness</label>
             </li>
      </ul>
   </div>
   <button className={`${styles.button_2} ${styles.toggle}`}>
      More
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" className={`${styles.toggle_icon}`}>
         <g fill="#403B45" fillRule="evenodd">
            <path d="M16.026 18.067l-7.795-7.79a.447.447 0 01.002-.634l7.79-7.708a.547.547 0 00.001-.774.553.553 0 00-.778-.002l-7.79 7.709a1.536 1.536 0 00-.005 2.18l7.795 7.79a.552.552 0 00.778.003.546.546 0 00.002-.774z"></path>
            <path d="M12.026 18.067l-7.795-7.79a.447.447 0 01.002-.634l7.79-7.708a.547.547 0 00.001-.774.553.553 0 00-.778-.002l-7.79 7.709a1.536 1.536 0 00-.005 2.18l7.795 7.79a.552.552 0 00.778.003.546.546 0 00.002-.774z"></path>
         </g>
      </svg>
   </button>
</div>



        
         
       </div>
     </div>
    );
  // }
}

export default PropertyListingMain;
