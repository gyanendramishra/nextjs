import React from "react";
import { useTranslation } from 'react-i18next';
import { Field } from "formik";

/**
 * Import services, types and utils
 */
import { TFilter, TMaster } from "../../types";
import { EPropertyType, EPropertyFor } from "../../utils";
import { bedroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import Autocomplete from "@/components/search/autocomplete";
import PropertyType from "@/components/search/property-type";

type TProps = {
    styles: TStyle;
    masters: TMaster;
    filters: TFilter;
    advanceSearch: boolean;
    toggleAdvanceSearch: Function;
    changePropertyFor: Function;
    handleTypeOnChange: Function;
}

type TStyle = {
    readonly [key: string]: string;
}

const MainSearchMobileForm = (props:TProps) => {
    const { t } = useTranslation();
    const { 
        styles, 
        masters,
        filters,
        advanceSearch,
        toggleAdvanceSearch,
        changePropertyFor,
        handleTypeOnChange
    } = props;

    /**
     * Render the html
     * @return void
     */
    return (
        <>
            <div className={(filters.for === EPropertyFor.INTERNATIONL) ? styles.search_inner+" "+styles.international_col: styles.search_inner}>
                <div className={styles.select_block}>
                    <Field
                        as="select"
                        name="type"
                        className={styles.form_control}
                        onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                    >
                        <option value={EPropertyType.RESIDENTIAL}>
                            {t("MAIN_SEARCH.SEARCH_TYPE.RESIDENTIAL")}
                        </option>
                        <option value={ EPropertyType.COMMERCIAL }>
                            {t("MAIN_SEARCH.SEARCH_TYPE.COMMERCIAL")}
                        </option>
                    </Field>
                </div>
                <div className={styles.search_field}>
                    {/* Auto complete */}
                    <Autocomplete name="locations"></Autocomplete>         
                </div>
                <div className={styles.search_btn}>
                    <button type="submit" className={styles.find_btn}>
                        {t("MAIN_SEARCH.LABELS.FIND")}
                    </button>
                </div>
            </div> 
            <div className={styles.srch1}>
                <div className={styles.srch1_inr}>
                    <a className={styles.left_link} href="#">
                        <i className="icon-pin"></i> { t("MAIN_SEARCH.LABELS.SEARCH_ON_MAP") }
                    </a>
                    <a className={`${styles.right_link} ${styles.mobile_link}`} onClick={()=> toggleAdvanceSearch()}>
                        <i className="icon-levels"></i> { t("MAIN_SEARCH.LABELS.ADVANCED_SEARCH") }
                    </a>
                </div>
            </div> 
            <div className={ (advanceSearch === true) ? styles.open_advance : ''}>                              
                <div className={`${styles.search_mobile_block_outer}`}>
                    <div className={styles.search_category_nav}>
                        <ul className="d-flex">
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.SALE ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.SALE)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.FOR_SALE")}
                                </a>
                            </li>
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.RENT ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.RENT)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.FOR_RENT")}
                                </a>
                            </li>
                            <li>
                                <a
                                    className={ filters.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                    onClick={() => changePropertyFor(EPropertyFor.INTERNATIONL)}
                                >
                                    {t("MAIN_SEARCH.SEARCH_FOR.INTERNATIONAL")}
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
                        <div className={styles.adv_col_full}>
                            <Autocomplete name="locations"></Autocomplete>
                        </div>
                        <div className={styles.adv_col_full}>
                            <Field
                                as="select"
                                name="type"
                                className={styles.form_control}
                                onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                            >
                                <option value={EPropertyType.RESIDENTIAL}>
                                    {t("MAIN_SEARCH.SEARCH_TYPE.RESIDENTIAL")}
                                </option>
                                <option value={ EPropertyType.COMMERCIAL }>
                                    {t("MAIN_SEARCH.SEARCH_TYPE.COMMERCIAL")}
                                </option>
                            </Field>
                        </div>
                        {(filters.for === EPropertyFor.INTERNATIONL) && (
                            <div className={styles.adv_col_full}>
                                <Field
                                    as="select"
                                    name="country"
                                    className={styles.form_control}
                                >
                                    <option value="">{t("MAIN_SEARCH.LABELS.COUNTRY")}</option>
                                    {masters.countries.map((country, index: number) => {
                                        return (
                                            <option value={country.id} key={index}>
                                                {country.name}
                                            </option>
                                        );
                                    })}
                                </Field>
                            </div>
                        )}
                        <div className={styles.adv_col_full}>
                            <PropertyType
                                name="sub_type"
                                lable = { t("MAIN_SEARCH.LABELS.PROPERTY_TYPE")}
                                category = { filters.type }
                                styles = { styles }
                            ></PropertyType>
                        </div>
                        <div className={styles.adv_col_full}>
                            <Field 
                                as="select" 
                                className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`}
                                name="bedrooms" 
                            >
                                <option value="">{ t("MAIN_SEARCH.LABELS.BEDS") }</option>
                                { bedroomList.map((option, index) => {
                                    return (
                                        <option key={index} value={ option }>{ option }</option>
                                    );
                                })}
                            </Field>
                        </div>
                        <div className={styles.adv_col_full}>
                            <Field 
                                as="select" 
                                className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`}
                                name="bathrooms" 
                                disabled={ (filters.type === EPropertyType.COMMERCIAL) }
                            >
                                <option value="">{ t("MAIN_SEARCH.LABELS.BATHS") }</option>
                                { bathroomList.map((option, index) => {
                                    return (
                                        <option key={index} value={ option }>{ option }</option>
                                    );
                                })}
                            </Field>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <Field as="select" name="price[min]" className={styles.form_control}>
                                    { priceList.min.map((minPrice, index) => {
                                        return (
                                            <option key={index} value={minPrice}>{ minPrice }</option>
                                        )
                                    })}
                                </Field>
                            </div>
                            <div className={styles.wd2}>
                                <span>to</span>
                            </div>
                            <div className={styles.wd1}>
                                <Field as="select" name="price[max]" className={styles.form_control}>
                                    { priceList.max.map((maxPrice, index) => {
                                        return (
                                            <option key={index} value={maxPrice}>{ maxPrice }</option>
                                        )
                                    })}
                                </Field>
                            </div>
                        </div>
                        <div className={styles.min_max_outer}>
                            <div className={styles.wd1}>
                                <Field as="select" name="size[min]" className={styles.form_control}>
                                    { sizeList.min.map((minSize, index) => {
                                        return (
                                            <option key={index} value={minSize}>{ minSize }</option>
                                        )
                                    })}
                                </Field>
                            </div>
                            <div className={styles.wd2}>
                                <span>to</span>
                            </div>
                            <div className={styles.wd1}>
                                <Field as="select" name="size[max]" className={styles.form_control}>
                                    { sizeList.max.map((maxSize, index) => {
                                        return (
                                            <option key={index} value={ maxSize }>{ maxSize }</option>
                                        )
                                    })}
                                </Field>
                            </div>
                        </div>
                        <div className={styles.adv_col_full}>
                            <button type="submit" className={styles.mbl_find_btn}>Find</button>
                        </div>
                        <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
                            <a className={`${styles.right_link} ${styles.mobile_link}`} onClick={()=> toggleAdvanceSearch()}><i className="icon-levels"></i> Close Advanced Search</a>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}


export default MainSearchMobileForm;

