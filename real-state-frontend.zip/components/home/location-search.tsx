import React from "react";
import axios from "axios";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import component types
 */
import { TTranslation, TCLocation, TCategory } from "../../types";

/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    propertyFor: string;
    categories : TCategory[];
    translation: TTranslation;   
}

interface States {
    activeCategory: number;
    categoryLocations: TCLocation[];
}

class LocationSearch extends React.Component<Props, States>  {

    /**
     * New component instance
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            activeCategory : 0,
            categoryLocations: []
        }
    }

    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Swith the search category
     * @return void
     */
    switchCategory = async (categoryId: number) => {
        this.setState({
            ...this.state,
            activeCategory: categoryId,
            categoryLocations: []
        });
        await this.getLocationsOfCategory(categoryId);
    }

    /**
     * Get the locations of the category
     * @return void
     */
    getLocationsOfCategory = async (categoryId: number) => {
        const { translation,  propertyFor} = this.props;
        try {
            const route = (propertyFor === 'sale') ? `cities-for-sale/${categoryId}` : `cities-for-rent/${categoryId}`; 
            const response = await axios.get(
                `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/${route}`, 
                {
                headers: {
                    "locale": translation.language
                }
            });
            const { data } = response.data;
            this.setState({"categoryLocations": data});
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * Get the locations of the labels
     * @return void
     */
    getLocationsOfLabels = async (type: string) => {
        const { translation } = this.props;
        try {
            const response = await axios.get(
                `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/country-for-international/${type}`, 
                {
                headers: {
                    "locale": translation.language
                }
            });
            const { data } = response.data;
            this.setState({"categoryLocations": data});
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = () => {
        const { categories } = this.props;
        if(Object.keys(categories).length){
            let categoryId = categories[0].id;
            this.switchCategory(categoryId);
        }
    }
    /**
     * Render the html in dom
     */
    render() {
        const { categories, propertyFor } = this.props;
        const { activeCategory, categoryLocations} = this.state;

        let locationComponent;
        if (propertyFor === "international") {
            locationComponent = (
                <div className={styles.advance_search_block}>
                    <div className={`${styles.custom_tab}`}>
                        <ul className={styles.prop_tab}>
                            <li>
                                <a className={`${(activeCategory == 1) ? "active" : ""}`} onClick={() => this.getLocationsOfLabels('is_high_investment_return')}>
                                    High Investment Return
                                </a>
                            </li>
                            <li>
                                <a className={`${(activeCategory == 2) ? "active" : ""}`} onClick={() => this.getLocationsOfLabels('is_great_price')}>
                                    Great Price
                                </a>
                            </li>
                            <li>
                                <a className={`${(activeCategory == 3) ? "active" : ""}`} onClick={() => this.getLocationsOfLabels('is_featured')}>
                                    Featured
                                </a>
                            </li>     
                        </ul>
                        {categoryLocations &&
                            <div className={`${styles.tab_content}`}>
                                <ul className={styles.link2}>
                                    {categoryLocations.map((location:TCLocation, index:number) => {
                                        return (
                                            <li key={index}>
                                                <a href="#">{location.name}</a>
                                            </li>
                                        )
                                    })}
                                </ul>
                                <div className={styles.all_properties}>
                                    <a href="#">View all properties</a>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            );
        }else if(Object.keys(categories).length){
            locationComponent = (
                <div className={styles.advance_search_block}>
                    <div className={`${styles.custom_tab}`}>
                        <ul className={styles.prop_tab}>
                            { categories.map((category, index)=>{
                                return (
                                    <li key={index}>
                                        <a className={`${(activeCategory == category.id) ? "active" : ""}`} onClick={() => this.switchCategory(category.id)}>
                                            {category.name}
                                        </a>
                                    </li>
                                )
                            })}
                        </ul>
                        {categoryLocations &&
                            <div className={`${styles.tab_content}`}>
                                <ul className={styles.link2}>
                                    {categoryLocations.map((location:TCLocation, index:number) => {
                                        return (
                                            <li key={index}>
                                                <a href="#">{location.name}</a>
                                            </li>
                                        )
                                    })}
                                </ul>
                                <div className={styles.all_properties}>
                                    <a href="#">View all properties</a>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            );
        }
        return (
            <>
                { locationComponent }
            </>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("main-search")(LocationSearch))