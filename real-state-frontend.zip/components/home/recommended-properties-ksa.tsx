import React from "react";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from 'next-i18next';
import axios, { AxiosResponse } from "axios";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import components
 */
import PropertyItem from "@/components/property/item";

/**
 * import types and queries
 */
import { EQRecommendedPropertyFORKSA } from '../../utils/elastic-queries';
import { RecommendedProperty, TPSource } from '../../classes/recommended-property';

/**
 * component styles
 */
import styles from '../../styles/home/recommended-properties-ksa.module.scss';


interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    translation: TTranslation;
}

type TTranslation = {
    language: string;
}

type States = {
    properties:TPSource[]
}

export class RecommendedPropertiesKSA extends React.Component<Props, States> {
    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            properties : []
        }
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
        namespacesRequired: ["recommended-properties"],
        };
    }

    /**
     * Get the search masters
     * @return void
     */
    getProperties = async () => {
        try {
            const response:AxiosResponse = await axios.post(
                `${process.env.NEXT_PUBLIC_ELASTIC_SEARCH_SERVICE_END_POINT}`,
                EQRecommendedPropertyFORKSA 
            );
            const { hits }  = response.data.hits;
            this.setState({"properties": hits});
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = async () => {
        await this.getProperties();
    }

    /**
     * Render the template
     * @return mix html
     */
    render() {
        const { t, translation } = this.props;
        const { properties } = this.state;
        if(!Object.keys(properties).length){
            return ("");
        }
        return (
            <div className={styles.home_section1}>
                <div className="container">
                    <h2 className="text-center">{ t("TITLE_KSA") }</h2>
                    <div className="row">
                        {properties.map((property:TPSource, index:number) => {
                            const rProperty = new RecommendedProperty(property, translation.language);
                            return (
                                <div className="col-md-4">
                                    <PropertyItem
                                        key={index}
                                        property={rProperty}
                                    ></PropertyItem>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("recommended-properties")(RecommendedPropertiesKSA))
