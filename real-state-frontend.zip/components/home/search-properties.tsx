import React from "react";
import PropTypes from "prop-types";
import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { Formik, Form, Field, FormikHelpers } from "formik";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { mainSearchElements, propertyTypes } from "../../services";
import { EPropertyFor, EPropertyType } from "../../utils";
import { TTranslation, TCountry, TCategory } from "../../types";

/**
 * Import page components
 */
import LocationSearch from "@/components/home/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";

/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    translation: TTranslation;
    filters: TFilter;    
}

interface States {
    advanceSearch:boolean;
    masters: TMaster;
    filters: TFilter;
}

type TFilter = {
    advanceSearch: boolean;
    for: string;
    type: string;
    locations: Array<{}>;
    category: number | null;
    country: number | null;
    sub_type: string | null;
    beadrooms : number | null;
    bathrooms : number | null;
    minPrice: number | null;
    maxPrice: number | null;
    minSize: number | null;
};

type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};


export class SearchProperties extends React.Component<Props, States> {
    /**
     * New component instance
     */
    constructor(props: Props) {
        super(props);
        this.state = {
            advanceSearch: false,
            masters: {
                categories: [],
                countries: [],
            },
            filters: {
                advanceSearch: false,
                for: EPropertyFor.SALE,
                type: EPropertyType.COMMERCIAL,
                locations: [],
                category : null,
                country : null,
                sub_type: null,
                beadrooms : null,
                bathrooms : null,
                minPrice: null,
                maxPrice: null,
                minSize: null,
            }
        };
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Toggle advance search
     * @return void
     */
    public toggleAdvanceSearch = (): void => {
        const { advanceSearch } = this.state;
        if (advanceSearch === true) {
            this.setState({
                ...this.state,
                advanceSearch: false
            });
        } else {
            this.setState({
                ...this.state,
                advanceSearch: true
            });
        }
        
    };

    /**
     * Switch property for
     * @param propertyFor: string
     * @return void
     */
    public switchPropertyFor = (propertyFor: string): void => {
        const { filters } = this.state;
        filters.for = propertyFor;
        this.setState({
            ...this.state,
            filters: filters
        });
        //this.props.forFilterChanged(propertyFor);
    };

    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    public onHandleSearch = async (formData: TFilter) => {
        alert(JSON.stringify(formData, null, 2));
    };

    /**
     * Prepare form validation schema
     * @param t: TFunction
     * @return Yup.object
     */
    public validationSchema = (t: TFunction) => {
        // return Yup.object().shape({
        //     locations: Yup.string().required(
        //         t("validations:REQUIRED", { attribute: t("FORM.LABELS.LOCATIONS") })
        //     ),
        // });
    };

    /**
     * Get the search masters
     * @return void
     */
    getMainSearchElements = async () : Promise<void> => {
        const { translation } = this.props;
        const result = await mainSearchElements(translation.language);
        if(result.status === true){
            this.setState({ masters: result.data });
        }else{
            console.error(result.message);
        }
    };

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = async () => {
        await this.getMainSearchElements();
    };

    /**
     * Triggers on prop change
     * @return void
     */
    componentDidUpdate = async (prevProps: Props) => {
        const { translation } = this.props;
        if(translation.language != prevProps.translation.language){
            await this.getMainSearchElements();
        }
    } 

    render() {
        const { t, translation } = this.props;
        const { filters, masters } = this.state;
        const { categories } = masters;
        return (
        <div className={styles.search_outer}>
            <div className={styles.container}>
                <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                        <MainSearchWebForm
                            styles = { styles }
                            masters = { masters }
                            filters = { filters } 
                            handleSearch = { this.onHandleSearch }
                            changePropertyFor = { this.switchPropertyFor }
                            toggleAdvanceSearch = { this.toggleAdvanceSearch}
                        />
                        <MainSearchMobileForm
                            styles = { styles }
                            masters = { masters }
                            filters = { filters } 
                            handleSearch = { this.onHandleSearch }
                            changePropertyFor = { this.switchPropertyFor }
                            toggleAdvanceSearch = { this.toggleAdvanceSearch}
                         />
                    </div>
                    {/* Location search component */}
                    <LocationSearch 
                        categories={categories}
                        propertyFor={filters.for}
                    ></LocationSearch>
                    {/* Mobile Popup Search Filter */}
                    
                </div>
            </div>
        );
    }
}

export default withTranslation("main-search")(SearchProperties);
