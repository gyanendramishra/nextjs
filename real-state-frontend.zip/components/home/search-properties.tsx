import React from "react";
import * as Yup from "yup";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { Formik, Field, FormikHelpers } from "formik";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { mainSearchElements } from "../../services";
import { EPropertyFor, EPropertyType } from "../../utils";
import { TTranslation, TCountry, TCategory } from "../../types";

/**
 * Import page components
 */
import LocationSearch from "@/components/home/location-search";
import Autocomplete from "@/components/search/autocomplete";
import AdvanceSearch from "@/components/home/advance-search";

/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    translation: TTranslation;    
}

interface States {
    masters: TMaster;
    filter: TFilter;
}

type TFilter = {
    for: string;
    type: string;
    locations: string | null;
    category: number | null;
    country: number | null;
};

type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};

export class SearchProperties extends React.Component<Props, States> {
    /**
     * New component instance
     */
    constructor(props: Props) {
        super(props);
        this.state = {
            masters: {
                categories: [],
                countries: [],
            },
            filter: {
                for: EPropertyFor.SALE,
                type: EPropertyType.COMMERCIAL,
                locations: null,
                category : null,
                country : null,
            }
        };
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Switch property for
     * @param propertyFor: string
     * @return void
     */
    public switchPropertyFor = (propertyFor: string): void => {
        const { filter } = this.state;
        filter.for = propertyFor;
        this.setState({
            ...this.state,
            filter: filter
        });
    };

    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    public onHandleSearch = async (formData: TFilter) => {
        alert(JSON.stringify(formData, null, 2));
    };

    /**
     * Prepare form validation schema
     * @param t: TFunction
     * @return Yup.object
     */
    public validationSchema = (t: TFunction) => {
        return Yup.object().shape({
            locations: Yup.string().required(
                t("validations:REQUIRED", { attribute: t("FORM.LABELS.LOCATIONS") })
            ),
        });
    };

    /**
     * Get the search masters
     * @return void
     */
    getMainSearchElements = async () : Promise<void> => {
        const { translation } = this.props;
        const result = await mainSearchElements(translation.language);
        if(result.status === true){
            this.setState({ masters: result.data });
        }else{
            console.error(result.message);
        }
    };

    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = async () => {
        await this.getMainSearchElements();
    };

    /**
     * Triggers on prop change
     * @return void
     */
    componentDidUpdate = async (prevProps: Props) => {
        const { translation } = this.props;
        if(translation.language != prevProps.translation.language){
            await this.getMainSearchElements();
        }
    } 

    /**
     * Triggers when component is failed
     * @return void
     */
    componentDidCatch = () => {
        console.error("Opps somthing went wrong. Search component not rendered.");
    };

    render() {
        const { t } = this.props;
        const { filter, masters } = this.state;
        const { countries, categories } = masters;
        return (
        <div className={styles.search_outer}>
            <div className={styles.container}>
                <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    <Formik
                        initialValues={filter}
                        validationSchema={this.validationSchema(t)}
                        onSubmit={async (
                            values: TFilter,
                            {
                                setSubmitting,
                            }: FormikHelpers<TFilter>
                        ) => {
                            await this.onHandleSearch(values);
                            setSubmitting(false);
                        }}
                    >
                        <>
                            <div className={styles.search_category_nav}>
                                <ul className="d-flex">
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.SALE ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.SALE)}
                                        >
                                            {t("SEARCH_FOR.FOR_SALE")}
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.RENT ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.RENT)}
                                        >
                                            {t("SEARCH_FOR.FOR_RENT")}
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            className={ filter.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                            onClick={() => this.switchPropertyFor(EPropertyFor.INTERNATIONL)}
                                        >
                                            {t("SEARCH_FOR.INTERNATIONAL")}
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className={styles.dis_block}>
                                <div className={styles.search_inner}>
                                    <div className={styles.select_block}>
                                        <Field
                                            as="select"
                                            name="type"
                                            className={styles.form_control}
                                        >
                                            <option value={EPropertyType.RESIDENTIAL}>
                                                {t("SEARCH_TYPE.RESIDENTIAL")}
                                            </option>
                                            <option value={ EPropertyType.COMMERCIAL }>
                                                {t("SEARCH_TYPE.COMMERCIAL")}
                                            </option>
                                        </Field>
                                    </div>
                                    {(filter.for === EPropertyFor.INTERNATIONL) && (
                                        <div className={styles.select_block}>
                                            <Field
                                                as="select"
                                                name="country"
                                                className={styles.form_control}
                                            >
                                                {countries.map((country: TCountry, index: number) => {
                                                    return (
                                                        <option value={country.id} key={index}>
                                                            {country.name}
                                                        </option>
                                                    );
                                                })}
                                            </Field>
                                        </div>
                                    )}
                                    <div className={styles.search_field}>
                                        {/* Auto complete */}
                                        <Autocomplete></Autocomplete>                
                                    </div>
                                    <div className={styles.search_btn}>
                                        <button type="submit" className={styles.find_btn}>
                                            {t("LABELS.FIND")}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </>
                    </Formik>
                    <AdvanceSearch
                        propertyType={filter.type}
                    ></AdvanceSearch>
                    </div>
                    {/* Location search component */}
                    <LocationSearch 
                        categories={categories}
                        propertyFor={filter.for}
                    ></LocationSearch>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("main-search")(SearchProperties));
