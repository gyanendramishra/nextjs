import React from "react";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { TTranslation, TPropertyType } from "../../types";
import { propertyTypes } from "../../services";
import { beadroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import MinMaxPicker from "@/components/search/min-max-picker";


/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    propertyType: string;
    translation: TTranslation;   
};

interface States {
    advanceSearch: boolean;
    propertyTypes: TPropertyType[];
    filter: TFilter;
};

type TFilter = {
    type: string | null;
    beadrooms : number | null;
    bathrooms : number | null;
    minPrice: number | null;
    maxPrice: number | null;
    minSize: number | null;
    maxNumber: number | null;
};

class AdvanceSearch extends React.Component<Props, States>  {

    /**
     * New component instance
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            advanceSearch: false,
            propertyTypes: [],
            filter: {
                type: null,
                beadrooms : null,
                bathrooms : null,
                minPrice: null,
                maxPrice: null,
                minSize: null,
                maxNumber: null
            }
        }
    }

    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
        propertyType: PropTypes.string.isRequired,
    };

    /**
     * Get initial props
     * @return array
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["main-search"],
        };
    }

    /**
     * Toggle advance search
     * @return void
     */
    public toggleAdvanceSearch = (): void => {
        const { advanceSearch } = this.state;
        if (advanceSearch === true) {
            this.setState({
                ...this.state,
                advanceSearch: false
            });
        } else {
            this.setState({
                ...this.state,
                advanceSearch: true
            });
        }
        
    };

    /**
     * Triggers on prop change
     * @return void
     */
    componentDidUpdate = async (prevProps: Props) => {
        const { translation, propertyType } = this.props;
        if(prevProps.propertyType != propertyType){
            const result = await propertyTypes(translation.language, propertyType);
            if(result.status === true){
                this.setState({ propertyTypes: result.data });
            }else{
                console.error(result.message);
            }
        }
    } 
    
    /**
     * Render the html in dom
     */
    render() {
        const { t } = this.props;
        const { advanceSearch, propertyTypes } = this.state;

        return (
            <div className={styles.srch1}>
                { (advanceSearch === true) && (
                    <div className={styles.adv_block}>
                        <div className={styles.adv_row}>
                            <div className={styles.adv_col1}>
                                <select className={styles.form_control}>
                                    <option>{ t("LABELS.PROPERTY_TYPE") }</option>
                                    { propertyTypes.map((propertyType, index)=>{
                                        return(
                                            <option value={propertyType.id} key={index}>{propertyType.name}</option>
                                        )
                                    })}
                                </select>
                            </div>
                            <div className={styles.adv_col1}>
                                <select className={styles.form_control}>
                                    <option value="">{ t("LABELS.BEDS") }</option>
                                    { beadroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </select>
                            </div>
                            <div className={styles.adv_col1}>
                                <select className={styles.form_control}>
                                    <option value="">{ t("LABELS.BATHS") }</option>
                                    { bathroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </select>
                            </div>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker 
                                    label={ t("LABELS.PRICE") }
                                    options={ priceList }
                                ></MinMaxPicker>
                            </div>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker 
                                    label={ t("LABELS.SIZE") }
                                    options={ sizeList }
                                ></MinMaxPicker>
                            </div>
                        </div>
                    </div>
                )}
                <div className={styles.srch1_inr}>
                    <a className={styles.left_link} href="#">
                        <i className="icon-pin"></i> { t("LABELS.SEARCH_ON_MAP") }
                    </a>
                    <a className={styles.right_link} onClick={this.toggleAdvanceSearch}>
                        <i className="icon-levels"></i>{advanceSearch ? t("LABELS.CLOSE_ADVANCED_SEARCH") : t("LABELS.ADVANCED_SEARCH")}
                    </a>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("main-search")(AdvanceSearch))