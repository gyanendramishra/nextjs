import React from "react";
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import components
 */
import PropertyItem from "@/components/property/item";
import FrameModal from "@/components/shared/elements/frame-modal";

/**
 * import clases and services
 */
import { recommendedInternationalProperties } from '../../services';
import { RecommendedProperty, TPSource } from '../../classes/recommended-property';

/**
 * component styles
 */
import styles from '../../styles/home/recommended-properties-international.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    translation: TTranslation;
}

type TTranslation = {
    language: string;
}

type States = {
    properties:TPSource[];
    modal:TModal;
}

type TModal = {
    opened: boolean;
    title?: string;
    src?: string;
}

export class RecommendedPropertiesInternational extends React.Component<Props, States> {

    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
        this.state = {
            properties : [],
            modal: {
                opened: false,
                title: "",
                src: ""
            }
        }
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["recommended-properties"],
        };
    }
    /**
     * Triggers when component is mounting
     * @return void
     */
    componentDidMount = async () => {
        const result = await recommendedInternationalProperties();
        if(result.status === true){
            this.setState({"properties": result.data});
        }else{
            console.error(result.message);
        }
    }

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    public populateVideo = (src: string): void => {
        const { t } = this.props;
        const { modal } = this.state;
        modal.opened = true;
        modal.title = t("VIDEO_MODAL_TITLE");
        modal.src = src;
        this.setState({
            ...this.state,
            modal: modal
        });
    }

    /**
     * Handle modal on close
     * @param src: string
     * @return void
     */
    public handleModelClose = (): void => {
        const { modal } = this.state;
        modal.opened = false;
        modal.title = "";
        modal.src = "";
        this.setState({
            ...this.state,
            modal: modal
        });
    }

    /**
     * Render the template
     * @return mix html
     */
    render() {
        const { t, translation } = this.props;
        const { properties, modal } = this.state;
        if(!Object.keys(properties).length){
            return ("");
        }
        return (
            <div className={styles.home_section1}>
                <div className={styles.container}>
                    <h2 className="text-center">{ t("TITLE_INTERNATIONAL") }</h2>
                    <div className="row">
                        {properties.map((property:TPSource, index:number) => {
                            const rProperty = new RecommendedProperty(property, translation.language);
                            return (
                                <div 
                                    className="col-md-4"
                                    key={index}
                                >
                                    <PropertyItem
                                        property={rProperty}
                                        handleVideo={this.populateVideo}
                                    ></PropertyItem>
                                </div>
                            )
                        })}
                    </div>
                </div>
                <FrameModal 
                    title={ modal.title }
                    opened={ modal.opened }
                    src={ modal.src }
                    onModalClose = { this.handleModelClose}
                ></FrameModal>
            </div>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

export default connect(mapStateToProps)(withTranslation("recommended-properties")(RecommendedPropertiesInternational))
