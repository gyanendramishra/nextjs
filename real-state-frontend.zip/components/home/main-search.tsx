import React, { useState, useLayoutEffect } from "react";
import { connect } from 'react-redux';
import { useRouter } from 'next/router';
import { Formik, Form, FormikHelpers } from "formik";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import services, types and utils
 */
import { forFilterChanged } from "../../stores/actions";
import { TFilter, TMaster, TSSearch, TTag  } from "../../types";
import { EPropertyType, EPropertyFor, EPropertySort, EPagination, getLocationFromAutocomplete  } from "../../utils";

/**
 * Import page components
 */
import LocationSearch from "@/components/home/location-search";
import MainSearchWebForm from "@/components/home/main-search-web-form";
import MainSearchMobileForm from "@/components/home/main-search-mobile-form";

/**
 * Component styles
 */
import styles from "../../styles/home/main-search.module.scss";

type TProps = {
    storeFilters: TSSearch;
    searchElements: TMaster;
    dispatchForFilter: Function;
};

const MainSearch = (props:TProps) => {
    const {
        storeFilters, 
        searchElements,
        dispatchForFilter
    } = props;
    
    const { t } = useTranslation();
    const router = useRouter();
    
    const [isMobile, setIsMobile] = useState<boolean>(false);
    const [advanceSearch, setAdvanceSearch] = useState<boolean>(false);
    const [filters, setFilters] = useState<TFilter>({
        for: storeFilters.for,
        type: EPropertyType.RESIDENTIAL,
        sub_type: '',
        locations: [],
        country : '',
        bedrooms : '',
        bathrooms : '',
        price: {
            min: '',
            max: ''
        },
        size: {
            min: '',
            max: ''
        },
        sort: EPropertySort.DATE_DESC,
        from : 0,
        to : EPagination.PER_PAGE_COUNT
    });

    /**
     * Handle screen resize
     */
    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });
    
    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }
    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = async (propertyFor: string): Promise<void> => {
        setFilters((prevState) => {
            prevState.for = propertyFor;
            return({
              ...prevState
            })
          }
        );
        await dispatchForFilter(propertyFor);
    };

    /**
     * Handle type on change
     * @param e: React.ChangeEvent<HTMLInputElement>
     */
    const handleTypeOnChange = async (e: React.ChangeEvent<HTMLInputElement>):Promise<string> => {
        const type = e.target.value;
        setFilters((prevState) => {
            prevState.type = type;
            return ({
                ...prevState
            });
        });
        return type;
    }

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = async (): Promise<void> => {
        if (advanceSearch === true) {
            setAdvanceSearch(false);
        } else {
            setAdvanceSearch(true);
        }
    };

    /**
     * Handle form submit
     * @param filters: TFilter
     * @return void
     */
    const onHandleSearch = async (filters:TFilter): Promise<void> => {
        setAdvanceSearch(false);
        let QProperty = {};
        const locations = getLocationFromAutocomplete(filters.locations as TTag[]);
        QProperty = { ...QProperty, 
            slug: filters.for, 
            type: filters.type, 
            category: filters.sub_type, 
            bedrooms: filters.bedrooms, 
            bathrooms: filters.bathrooms,
            min_price: filters.price.min,
            max_price: filters.price.max,
            min_size: filters.size.min,
            max_size: filters.size.max,
        }
        if(locations.hasOwnProperty('country')){
            QProperty = { ...QProperty, country:locations.country}
        }
        if(locations.hasOwnProperty('state')){
            QProperty = { ...QProperty, state:locations.state}
        }
        if(locations.hasOwnProperty('city')){
            QProperty = { ...QProperty, city:locations.city}
        }
        if(locations.hasOwnProperty('zone')){
            QProperty = { ...QProperty, zone:locations.zone}
        }
        await router.push({
            pathname: '/[slug]/search',
            query: QProperty,
        });
    }

    /**
     * Handle form submit
     * @param categoryId: string | number 
     * @return void
     */
    const onHandleAllLocationSearch = async (categoryId: string | number): Promise<void> => {
        let QProperty = {};
        QProperty = { ...QProperty, 
            slug: filters.for
        }
        if(filters.for === EPropertyFor.INTERNATIONL){
            QProperty = { ...QProperty,
                flag: categoryId
            }
        }else{
            QProperty = { ...QProperty, 
                category: categoryId
            }
        }
        await router.push({
            pathname: '/[slug]/search',
            query: QProperty,
        });
    }

    /**
     * Handle form submit
     * @param categoryId: string | number 
     * @param locationId:string | number
     * @return void
     */
    const onHandleLocationSearch = async (categoryId: string | number, locationId: string | number): Promise<void> => {
        let QProperty = {};
        QProperty = { ...QProperty, 
            slug: filters.for
        }
        if(filters.for === EPropertyFor.INTERNATIONL){
            QProperty = { ...QProperty,
                flag: categoryId,
                country: locationId,
            }
        }else{
            QProperty = { ...QProperty,
                category: categoryId,
                city: locationId,
            }
        }
        await router.push({
            pathname: '/[slug]/search',
            query: QProperty,
        });
    }

    /**
     * Seach component
     */
    let searchComponent: {} | null | undefined;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                advanceSearch = { advanceSearch}
                toggleAdvanceSearch = { toggleAdvanceSearch }
                changePropertyFor = { changePropertyFor }
                handleTypeOnChange = { handleTypeOnChange }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                handleTypeOnChange = { handleTypeOnChange }
            />
        )
    }
    /**
     * Render the html
     */
    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("search:LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    <Formik
                        enableReinitialize={ true }
                        initialValues={filters}
                        onSubmit={ async (
                            values: TFilter,
                            {
                                setSubmitting,
                            }: FormikHelpers<TFilter>
                        ) => {
                            await onHandleSearch(values);
                            setSubmitting(false);
                        }}
                    >
                        {() => (
                            <Form>
                                <div className={styles.search_category_nav}>
                                    <ul className="d-flex">
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.SALE ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.SALE)}
                                            >
                                                {t("search:SEARCH_FOR.FOR_SALE")}
                                            </a>
                                        </li>
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.RENT ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.RENT)}
                                            >
                                                {t("search:SEARCH_FOR.FOR_RENT")}
                                            </a>
                                        </li>
                                        <li>
                                            <a
                                                className={ filters.for === EPropertyFor.INTERNATIONL ? styles.active : "" }
                                                onClick={() => changePropertyFor(EPropertyFor.INTERNATIONL)}
                                            >
                                                {t("search:SEARCH_FOR.INTERNATIONAL")}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                { searchComponent }
                            </Form>
                        )}
                    </Formik>
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ searchElements.categories }
                    propertyFor={ filters.for }
                    onHandleLocationSearch = { onHandleLocationSearch }
                    onHandleAllLocationSearch = { onHandleAllLocationSearch }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

const mapDispatchToProps = (dispatch: any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor))
});

const mapStateToProps = (state: any) => ({
    storeFilters:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(MainSearch);
