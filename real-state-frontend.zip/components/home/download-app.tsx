import React, { Component } from "react";
import styles from '../../styles/home/download-app.module.scss';

export default class DownloadApp extends Component {
  render() {
      return (
          <div className={styles.property_servies}>
              <div className={styles.container}>
                  <div className={styles.app_download_block}>
                      <div className={styles.app_block1}>
                          <img src="/images/phone-banner.svg" alt=""/>
                      </div>
                      <div className={styles.app_block2}>
                          <h2>Find A New Home On The Go</h2>
                          <p>Download our app Where convenience<br></br> is at your fingertip</p>
                      </div>
                      <div className={styles.app_block3}>
                          <a href="#"><img src="/images/app-store.svg" alt=""/></a>
                          <a href="#"><img src="/images/google-pay.svg" alt=""/></a>
                      </div>
                  </div>
              </div>
          </div>
      );
  }
}
