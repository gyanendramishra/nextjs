import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * component styles
 */
import styles from '../../styles/home/home-links.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction
}

export class HomeLinks extends React.Component<Props> {

    /**
     * New component instance
     */
    constructor(props:Props) {
        super(props);
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["home-links"],
        };
    }

    render() {
        const { t } = this.props;
        return (
            <div className={styles.home_links}>
                <div className={styles.container}>
                    <div className={styles.ftr_row}>
                        <div className={styles.ftr_col}>
                            <a className={styles.ftr_logo} href="#">
                                <img src="/images/logo-white.svg" alt=""/>
                            </a>
                        </div>
                        <div className={styles.ftr_col}>
                            <div className={styles.ftr_hd}>
                                { t("ABOUT_DAR_AL_ARKAN_ONLINE.LABEL") }
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.OUR_STORY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.MORTGAGE") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("ABOUT_DAR_AL_ARKAN_ONLINE.OPTIONS.REGISTER_YOUR_COMPANY") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className={styles.ftr_hd}>
                                <a href="#">
                                    { t("REGISTER.LABEL") }
                                </a>
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("REGISTER.OPTIONS.LIST_YOUR_PROPERTY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("REGISTER.OPTIONS.LOGIN") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className={styles.ftr_col}>
                            <div className={styles.ftr_hd}>
                                { t("PROPERTIES.LABEL") }
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_SAUDI_ARABIA") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_UNITED_KINGDOM") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_CYPRUS") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_FRANCE") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_ITALY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_SWITZERLAND") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("PROPERTIES.OPTIONS.PROPERTIES_IN_SPAIN") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className={styles.ftr_col}>
                            <div className={styles.ftr_hd}>
                                { t("EXPERIENCE.LABEL") }
                            </div>
                            <div className={styles.ftr_nav}>
                                <ul>
                                    <li>
                                        <a href="#">
                                            { t("EXPERIENCE.OPTIONS.BUILDING_EVALUATION") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("EXPERIENCE.OPTIONS.AREA_DIRECTORY") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("EXPERIENCE.OPTIONS.REAL_ESTATE_BLOG") }
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            { t("EXPERIENCE.OPTIONS.REAL_ESTATE_FINANCE") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className={styles.ftr_col}>
                            <div className={styles.ftr_hd}>
                                { t("OUR_SOCIAL_MEDIA.LABEL") }
                            </div>
                            <div className={styles.contact_info}>
                                <ul className="d-flex">
                                    <li>
                                        <a href="#">
                                            <i className="icon-fb"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i className="icon-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i className="icon-linkedin"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i className="icon-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i className="icon-youtube"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default withTranslation("home-links")(HomeLinks);