import Head from "next/head";
import PropTypes from "prop-types";
import React, { ReactNode } from "react";
import PageHeader from "@/components/shared/partials/page-header";
import PageFooter from "@/components/shared/partials/page-footer";

type Props = {
    children: ReactNode;
    title: string;
    keywords?: string;
    description?: string;
};

export class Layout extends React.Component<Props> {

    static defaultProps = {
        title: "Home: Dar Al Arkan",
        keywords: "Home: Dar Al Arkan",
        description: "Home: Dar Al Arkan",
    };

    /**
     * Validate prop types
     */
    public static propTypes = {
        title: PropTypes.string.isRequired,
    };

    render() {
        return (
            <>
                {/* Layout Head  */}
                <Head>
                    <meta charSet="utf-8" />
                    <meta
                      name="viewport"
                      content="initial-scale=1.0, width=device-width"
                    />
                    <meta name="keyword" content={this.props.keywords} />
                    <meta name="description" content={this.props.description} />
                    <title>{this.props.title}</title>
                </Head>
                {/* Layout Header Seaction */}
                <PageHeader />
                    {/* Layout Main Seaction  */}
                    {this.props.children}
                    {/* Layout Footer Seaction */}
                <PageFooter />
            </>
        );
    }
}

export default Layout;
