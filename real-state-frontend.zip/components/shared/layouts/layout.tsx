import Head from "next/head";
import React, { ReactNode } from "react";
import PageHeader from "@/components/shared/partials/page-header";
import PageFooter from "@/components/shared/partials/page-footer";

type TProps = {
    children: ReactNode;
    title: string;
    keywords?: string;
    description?: string;
};

const Layout = (props: TProps) => {
    const { children, title, keywords, description } = props;

    return (
        <>
            {/* Layout Head  */}
            <Head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="initial-scale=1.0, width=device-width"/>
                <meta name="keyword" content={ keywords } />
                <meta name="description" content={ description } />
                <title>{ title }</title>
            </Head>
            {/* Layout Header Seaction */}
            <PageHeader />
                {/* Layout Main Seaction  */}
                { children }
                {/* Layout Footer Seaction */}
            <PageFooter /> 
        </>
    );
}

Layout.defaultProps = {
    title: "Home: Dar Al Arkan",
    keywords: "Home: Dar Al Arkan",
    description: "Home: Dar Al Arkan",
};

export default Layout;
