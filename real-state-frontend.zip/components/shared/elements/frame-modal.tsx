import React from "react";
import PropTypes from "prop-types";

type TProps = {
    readonly opened : boolean;
    readonly title?: string;
    readonly src?: string;
    onModalClose: Function;
};


const FrameModal = (props: TProps) => {

    const { opened, title, src, onModalClose } = props;

    /**
     * Close the modal
     * @return void
     */
    const closeModal =  (): void => {
        onModalClose();
    }

    /**
     * Render the component html
     * @return mix
     */
    
    return (
        <>
            {(opened === true) &&
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{ title }</h5>
                                <button type="button" className="close" onClick={ closeModal }>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <iframe src={ src } width="100%" height="100%"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            }
        </>
    );
}

FrameModal.propTypes = {
    title: PropTypes.string,
    src: PropTypes.string
}

export default FrameModal;
