import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * component styles
 */
//import styles from '../../../styles/shared/footer.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    readonly opened : boolean;
    readonly title?: string;
    readonly src?: string;
    onModalClose: Function;
}


export class FrameModal extends React.Component<Props> {
    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
    };
    /**
     * Validate prop types
     */
    public static propTypes = {
        title: PropTypes.string,
        src: PropTypes.string,
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static getInitialProps = async () => {
        return {
            namespacesRequired: ["footer"],
        };
    };

    /**
     * Close the modal
     * @return void
     */
    public closeModal =  (): void => {
        this.props.onModalClose();
    }

    /**
     * Render the component html
     * @return mix
     */
    render() {
        const { t, opened, title, src } = this.props;
        return (
            <>
                {(opened === true) &&
                    <div className="modal fade show" style={{ display: "block" }}>
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">{ title }</h5>
                                    <button type="button" className="close" onClick={ this.closeModal }>
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div className="modal-body">
                                    <iframe src={ src } width="100%" height="100%"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        );
    };
}

export default withTranslation("footer")(FrameModal);
