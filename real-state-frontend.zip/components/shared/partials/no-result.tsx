import React from "react";

/**
 * Import styles
 */
import styles from '../../../styles/shared/no-result.module.scss';

const NoResult = () => {
    return (
        <div className={styles.no_record_found}>
            <h1>Oops...</h1>
            <h2>No Data Found!</h2>
            <div className={styles.not_found_img}>
                <img src="/images/not-found.jpg" alt=""/>
            </div>
        </div>
    );
}
export default NoResult;
