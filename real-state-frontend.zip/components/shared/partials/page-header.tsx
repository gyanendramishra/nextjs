import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation, i18n } from "../../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

import { connect } from 'react-redux';
import { languageChanged } from '../../../stores/actions/translation-actions';

/**
 * component styles
 */
import styles from '../../../styles/shared/header.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    changedLanguage: Function;
    translation: TTranslation;
}

type TTranslation = {
    language: string;
}

export class PageHeader extends React.Component<Props>  {

    /**
     * Create new component instance
     * @return void
     */
    constructor(props:Props) {
        super(props);
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
        changedLanguage: PropTypes.func.isRequired
    };

    /**
     * Get initial props
     * @return response
     */
    static getInitialProps = async () => {
        return {
            namespacesRequired: ["navigations"],
        };
    }

    /**
     * Swith the app language
     * @return void
     */
    switchLanguage = async (): Promise<any> => {
        let lang: string = i18n.language === "en" ? "ar" : "en";
        let dir: string = lang === "en" ? "ltr" : "rtl";
        await i18n.changeLanguage(lang);
        document.documentElement.dir = dir;
        document.documentElement.lang = lang;
        this.props.changedLanguage(lang);
    }

    /**
     * Render the compoent
     * @return mix
     */
    render() {

        const { t } = this.props;
        return (
            <header className={styles.header}>
                <div className={styles.container}>
                    <div className={styles.hdr_btm_inr}>
                        <a className={styles.logo} href="#">
                            <img src="/images/logo.svg" alt=""/>
                        </a>
                        <a className={`${styles.menu_button} ${styles.menuImage}`} href="#">
                            <img src="/images/berger-menu.svg" alt=""/>
                        </a>
                        <div className={`${styles.menu} ${styles.iphonNav}`} data-ref="iphonNav">
                            <ul className={styles.nav1}>
                                <li className={styles.sub_nav}>
                                    <a href="#">{ t("MAIN_NAVIGATIONS.FOR_SALE.LABEL") }</a>
                                    <div className={styles.sub_nav_outer}>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.RIYADH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.JEDDAH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MEDINA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.DAMMAM") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MECCA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_KHOBAR") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TABUK") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.YANBU") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TAIF") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_JUBAIL") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.ABHA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.NAJRAN") }
                                                </a>
                                            </li>
                                        </ul>
                                        <a className={styles.all_link} href="#">
                                            { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                        </a>
                                    </div>
                                </li>
                                <li className={styles.sub_nav}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.FOR_RENT.LABEL") }
                                    </a>
                                    <div className={styles.sub_nav_outer}>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.RIYADH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.JEDDAH") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MEDINA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.DAMMAM") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.MECCA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_KHOBAR") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TABUK") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.YANBU") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.TAIF") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.AL_JUBAIL") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.ABHA") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.FOR_SALE.OPTIONS.NAJRAN") }
                                                </a>
                                            </li>
                                        </ul>
                                        <a className={styles.all_link} href="#">
                                            { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                        </a>
                                    </div>
                                </li>
                                <li className={styles.sub_nav}>
                                    <a href="#">
                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.LABEL") }
                                    </a>
                                    <div className={styles.sub_nav_outer}>
                                        <div className={styles.nav_hd}>
                                            { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.LABEL") }
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.OPTIONS.HIGH_INVESTMENT_RETURN") }
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.VALUE.OPTIONS.GREAT_PRICE") }
                                                </a>
                                            </li>
                                        </ul>
                                        <div className={styles.nav_hd}>
                                            { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.LABEL") }
                                        </div>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.BOSINA_AND_HERZEGOVINA") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.UNITED_ARAB_AMIRATES") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.MALTA") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.UNITED_KINGDOM") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.MONACO") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.SWITZERLAND") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.CYPRUS") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.FRANCE") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.SPAIN") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.GREECE") }
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        { t("MAIN_NAVIGATIONS.INTERNATIONAL.OPTIONS.COUNTRIES.OPTIONS.ITALY") }
                                                    </a>
                                                </li>
                                            </ul>
                                            <a className={styles.all_link} href="#">
                                                { t("MAIN_NAVIGATIONS.ALL_DETAILS") }
                                            </a>
                                        </div>
                                    </li>
                                    <li className={styles.sub_nav}>
                                        <a href="#">
                                            { t("MAIN_NAVIGATIONS.SERVICES.LABEL") }
                                        </a>
                                    </li>
                                    <li className={styles.sub_nav}>
                                        <a href="#">
                                            { t("MAIN_NAVIGATIONS.EXPERIENCE.LABEL") }
                                        </a>
                                    </li>
                                </ul>
                                <ul className={styles.nav2}>
                                    <li>
                                        <a className={styles.setting} href="#">
                                            { t("RIGHT_NAVIGATIONS.SETTING") }
                                        </a>
                                    </li>
                                    <li>
                                        <a className={styles.saved} href="#"> 
                                            { t("RIGHT_NAVIGATIONS.SAVED") }
                                            <i className="icon-heart"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a className={styles.name} onClick={this.switchLanguage}>
                                            { t("RIGHT_NAVIGATIONS.LANGUAGE") }
                                        </a>
                                    </li>
                                    <li>
                                        <a className={styles.sign_btn} href="#">
                                            { t("RIGHT_NAVIGATIONS.LOGIN") }
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <a className={styles.button_line} href="#">
                                { t("MAIN_NAVIGATIONS.LIST_YOUR_PROPERTY.LABEL") }
                            </a>
                    </div>
                </div>
            </header>
        );
    }
}

const mapStateToProps = (state:Props) => ({
    translation:{
        language: state.translation.language
    }
});

const mapDispatchToProps = (dispatch:any) => {
    return {
        changedLanguage: (lang:string) => {
            dispatch(languageChanged(lang))
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withTranslation("navigations")(PageHeader));
