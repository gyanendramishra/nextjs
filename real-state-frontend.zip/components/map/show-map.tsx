import React from "react";
import GoogleMapReact from "google-map-react";
import MarkerClusterer from "@googlemaps/markerclustererplus";
import polyline from '@mapbox/polyline';

import styles from '../../styles/listing/property-listing-map.module.scss';

type TPointsPolygon = {
  lat: Function, 
  lng: Function
}

type TMapProps = {
    center: {lat: number, lng: number},
    zoom: number,
    places: [],
    polygonData: [],
    // getPropertiesId: Function,
    // getPropertiesPolygon: Function
}

let gGoogleMapRef: any;
let gGoogleRef: any;
let placeService: any;
let allmarkers: any  = [];

type TPlace = {
  geometry: {location: any},
  name: string,
  icon: string,
  place_id: string
}

function nearbyCallback (results: any, status: any) {
  // console.log('OK',greef);
  if (status == gGoogleRef.places.PlacesServiceStatus.OK) {
    createMarkers(results);
  }
}

// Set markers at the location of each place result
function createMarkers(places: TPlace[]) {
  places.forEach(place => {
    let marker = new gGoogleRef.Marker({
      position: place.geometry.location,
      map: gGoogleMapRef,
      title: place.name,
      icon: place.icon
    });

    /* TODO: Step 4B: Add click listeners to the markers */
    // Add click listener to each marker
    gGoogleRef.event.addListener(marker, 'click', () => {
      let request = {
        placeId: place.place_id,
        fields: ['name', 'formatted_address', 'geometry', 'rating',
          'website', 'photos']
      };

      /* Only fetch the details of a place when the user clicks on a marker.
       * If we fetch the details for all place results as soon as we get
       * the search response, we will hit API rate limits. */
      placeService.getDetails(request, (placeResult: any, status: any) => {
        showDetails(placeResult, marker, status)
      });
    });

    allmarkers.push(marker);

    // Adjust the map bounds to include the location of this marker
    // bounds.extend(place.geometry.location);
  });
  /* Once all the markers have been placed, adjust the bounds of the map to
   * show all the markers within the visible area. */
  // gGoogleMapRef.fitBounds(bounds);
}

/* TODO: Step 4C: Show place details in an info window */
// Builds an InfoWindow to display details above the marker
function showDetails(placeResult: any, marker: any, status: string) {
  if (status == gGoogleRef.places.PlacesServiceStatus.OK) {
    let placeInfowindow = new gGoogleRef.InfoWindow();
    let rating = "None";
    if (placeResult.rating) rating = placeResult.rating;
    placeInfowindow.setContent('<div><strong>' + placeResult.name +
      '</strong><br>' + 'Rating: ' + rating + '</div>');
    placeInfowindow.open(marker.map, marker);
    // currentInfoWindow:  any = placeInfowindow;
    // currentInfoWindow.close();
    
    // showPanel(placeResult);
  } else {
    console.log('showDetails failed: ' + status);
  }
}

// export class ShowMap extends React.Component<TMapProps> {  
const ShowMap = (props: TMapProps) =>{
  const setGoogleMapRef = async (map: any, maps: any, locations: [], polygonDataX: []) => {
    console.log('show-map: Line no: 17 ',locations);
    let googleMapRef = map;
    let googleRef = maps;
    let all_overlays: any = [];
    
    let encodePoints: string;
    let ploygonData: any;
    let showSchoolsOnMap = false;
    let showRestaurantOnMap = false;

    let drawingManager: any;

    gGoogleMapRef = googleMapRef;
    gGoogleRef = googleRef;

    // Create an array of alphabetical characters used to label the markers.
    const labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    let markerClusterer = new MarkerClusterer(googleMapRef, [], {
        imagePath:
        "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
    });
    
    if(locations.length > 0){
      if(polygonDataX.length == 0){
        // Add some markers to the map.
        const markers = locations.map((location: {id: number}, i: number) => {
          let locationId: number = location.id;
          let marker = new googleRef.Marker({
              position: location,
              label: labels[i % labels.length],
              customId: locationId
          });
          marker.addListener("click", () => {
            const ids=[locationId];
            // props.getPropertiesId(ids);
          });
          allmarkers.push(marker);
          return marker;        
        });
        for (var i = 0; i < allmarkers.length; i++) {
          allmarkers[i].setMap(null);
        }
        markerClusterer.clearMarkers();
  
        // Add a marker clusterer to manage the markers.
        // @ts-ignore MarkerClusterer defined via script
        markerClusterer = new MarkerClusterer(googleMapRef, markers, {
            imagePath:
            "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
        }); 
        googleRef.event.addListener(markerClusterer, "click", (cluster: any) => {
          console.log(cluster)
          var markers = cluster.getMarkers();
          const ids=[];
          //Get all the titles
          for(var i = 0; i < markers.length; i++) {
            ids.push(markers[i].customId);
          }
          
          // props.getPropertiesId(ids);
        });
      } else {
        console.log('show-map: Line no: 62 ',allmarkers);
        markerClusterer.clearMarkers();
        for (var i = 0; i < allmarkers.length; i++) {
          allmarkers[i].setMap(null);
        }
        console.log("Show Map: Line no:60",locations.length);
        console.log("Show Map: Line no:61",locations);
        locations.map((location: {id: number}, i: number) => {
          let locationId: number = location.id;
          let marker = new googleRef.Marker({
              position: location,
              label: labels[i % labels.length],
              customId: locationId
          });
          marker.addListener("click", () => {
            const ids=[locationId];
            // props.getPropertiesId(ids);
            setGoogleMapRef(googleMapRef, googleRef, [], polygonDataX);
          });  
          marker.setMap(googleMapRef);    
        });        
      }
    }
    drawingManager = new googleRef.drawing.DrawingManager({
      drawingControl: false,      
      markerOptions: {
        icon:
          "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png",
      },
      polygonOptions: {
        fillColor: "#ffff00",
        fillOpacity: 0,
        strokeWeight: 5,
        clickable: false,
        editable: false,
        zIndex: 1,
      },
    });
    googleRef.event.addListener(drawingManager, 'overlaycomplete', (polygon: any) => {
      all_overlays.push(polygon);
      var coordinatesArray = polygon.overlay.getPath().getArray();
      let coordinatePoints: any[] = [];
      coordinatesArray.map((point: TPointsPolygon)=>{
        const lat = point.lat();
        const long = point.lng();
        const coordPoint: any[] = [ lat, long ];
        console.log(coordinatePoints);
        coordinatePoints.push(coordPoint);
      });
      console.log(coordinatePoints);
      // encodePoints = googleRef.geometry.encoding.encodePath(coordinatesArray);      
      encodePoints = polyline.encode(coordinatePoints);
      console.log(coordinatesArray)
      console.log(encodePoints);
      drawingManager.setDrawingMode(null);

    });
    
    googleRef.event.addDomListener(document.getElementById('draw_option'), 'click', function() {
           
      if(polygonDataX.length != 0){
        googleMapRef.setZoom(14);
        ploygonData = new googleRef.Polygon({
          paths: polygonDataX,
          fillColor: "#ffff00",
          fillOpacity: 0,
          strokeWeight: 5,
          clickable: false,
          editable: false,
          zIndex: 1,
        });
        ploygonData.setMap(googleMapRef);      
      }

      if(all_overlays.length>0) {
        all_overlays[0].overlay.setMap(null);
        all_overlays = [];
      }
      // console.log(locations)
      googleMapRef.setZoom(14);
      drawingManager.setMap(googleMapRef);      
      drawingManager.setDrawingMode(googleRef.drawing.OverlayType.POLYGON);
      if(polygonDataX.length != 0){
        ploygonData.setMap(null);
      } 
    });
    // googleRef.event.addDomListener(document.getElementById('applypolygonbtn'), 'click', () => {
    //   markerClusterer.clearMarkers();
    //   for (var i = 0; i < allmarkers.length; i++) {
    //     allmarkers[i].setMap(null);
    //   }
    //   // props.getPropertiesPolygon(encodePoints);
    //   drawingManager.setMap(null);
    // });

    // googleRef.event.addDomListener(document.getElementById('searchSchoolBtn'), 'click', function() {
      
    //   let request = {
    //     location: {lat: 26.842492, lng: 75.774352},
    //     rankBy: googleRef.places.RankBy.DISTANCE,
    //     keyword: 'schools'
    //   };

    //   for (var i = 0; i < allmarkers.length; i++) {
    //     allmarkers[i].setMap(null);
    //   }

    //   if(showSchoolsOnMap == false){
    //     let service = new googleRef.places.PlacesService(googleMapRef);
    //     placeService = service;
    //     service.nearbySearch(request, nearbyCallback);
    //   }
    //   showRestaurantOnMap = false;
    //   showSchoolsOnMap = !showSchoolsOnMap;
    // });

  //   googleRef.event.addDomListener(document.getElementById('searchRestaurantBtn'), 'click', function() {
      
  //     let request = {
  //       location: {lat: 26.842492, lng: 75.774352},
  //       rankBy: googleRef.places.RankBy.DISTANCE,
  //       keyword: 'restaurant'
  //     };
      
  //     for (var i = 0; i < allmarkers.length; i++) {
  //       allmarkers[i].setMap(null);
  //     }
      
  //     if(showRestaurantOnMap == false){
  //       let service = new googleRef.places.PlacesService(googleMapRef);
  //       placeService = service;
  //       service.nearbySearch(request, nearbyCallback);
  //     }
  //     showSchoolsOnMap = false;
  //     showRestaurantOnMap = !showRestaurantOnMap;
  //   });
  // }  

  // const setGoogleMapRef1 = (map: any, maps: any, places) => {
  //   let googleMapRef = map;
  //   let googleRef = maps;
  //   let all_overlays: any = [];

  //   places.map((location: {id: number}, i: number) => {
  //     let locationId: number = location.id;
  //     let marker = new googleRef.Marker({
  //         position: location,
  //         label: 'OK',
  //         customId: locationId
  //     });
  //     console.log("Clicked", locationId);
  //     marker.addListener("click", () => {
  //       const ids=[locationId];
  //       console.log("Clicked", ids);
  //       props.getPropertiesId(ids);
  //       marker.setMap(null); 
  //       setGoogleMapRef1(googleMapRef, googleRef, []);
  //     });  
  //     marker.setMap(googleMapRef);    
  //   });

  //   const drawingManager = new googleMapRef.drawing.DrawingManager({
  //     drawingControl: false,      
  //     markerOptions: {
  //       icon:
  //         "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png",
  //     },
  //     polygonOptions: {
  //       fillColor: "#ffff00",
  //       fillOpacity: 0,
  //       strokeWeight: 5,
  //       clickable: false,
  //       editable: false,
  //       zIndex: 1,
  //     },
  //   });
  //   googleRef.event.addDomListener(document.getElementById('polygonbtn'), 'click', function() {
  //     console.log('OK123');
  //     setGoogleMapRef1(googleMapRef, googleRef, []);
  //   });
  // }
  // let googleComponent;
  // useEffect(() => {
  //   googleComponent = <GoogleMapReact
  //                       bootstrapURLKeys={{ key: "AIzaSyAeHbHwrOUCerQ-UVL7x4KOG5B66LRVeUM",libraries: ['drawing','places']}}
  //                       yesIWantToUseGoogleMapApiInternals={true}
  //                       onGoogleApiLoaded={({ map, maps }) => {setGoogleMapRef(map, maps, places, polygonData)}}
  //                       defaultCenter={center}
  //                       defaultZoom={zoom}
  //                       options={{ streetViewControl: true }}              
  //                     ></GoogleMapReact>
  // },[]);

    let {center, zoom, places, polygonData } = props;
    if(typeof places !== 'undefined' && places.length > 0){
      // console.log('show-map: Line no: 240 ',places);
      // center = {lat: -28.024, lng: 140.887};
      return (
        <div style={{ height: "100%", width: "100%", float: "left"}}>
          <a className={styles.exit_map} href="#"><img src="/images/arrow1.svg" alt=""/> Exit map</a>
          <div className={styles.group_btn}>  {/* .ps4 */}
            {/* <a className={styles.apply_btn} href="#">Apply</a> */}
            <a className={styles.draw_btn} href="#" id="draw_option">Draw</a>
          </div>
          {/* <input id="polygonbtn" type="button" value="Draw Polygon"/>
          <input id="applypolygonbtn" type="button" value="Apply"/>
          <input id="searchSchoolBtn" type="button" value="School"/>
          <input id="searchRestaurantBtn" type="button" value="Restaurant"/> */}
          {/* {console.log('show-map: Line no: 247 ',places)} */}
          
          <GoogleMapReact
              bootstrapURLKeys={{ key: "AIzaSyAeHbHwrOUCerQ-UVL7x4KOG5B66LRVeUM", libraries: ['drawing','places'] }}
              yesIWantToUseGoogleMapApiInternals={true}
              onGoogleApiLoaded={({ map, maps }) => {setGoogleMapRef(map, maps, places, polygonData)}}
              // onGoogleApiLoaded={({ map, maps }) => {setGoogleMapRef1(map, maps, places)}}
              defaultCenter={center}
              defaultZoom={zoom}
              options={{ streetViewControl: true }}              
          >            
          </GoogleMapReact>
        </div>
      );
    } else {
      center = {lat: 26.922070, lng: 75.778885};
      zoom = 10;
      // {console.log('OK')}
      return (
        <div style={{ height: "100vh", width: "50%", float: "left"}}>
          <div>No Map</div>
          {/* <GoogleMapReact
              bootstrapURLKeys={{ key: "AIzaSyAeHbHwrOUCerQ-UVL7x4KOG5B66LRVeUM"}}
              defaultCenter={center}
              defaultZoom={zoom}             
          ></GoogleMapReact> */}
        </div>
      );
    }
}
}

export default ShowMap