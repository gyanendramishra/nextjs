import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Scrollbar } from 'swiper';
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * component styles
 */
import styles from '../../styles/property/item.module.scss';

/**
 * import classes
 */
import { RecommendedProperty } from '../../classes/recommended-property';

SwiperCore.use([Pagination, Scrollbar]);

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction,
    property: RecommendedProperty
}

export class PropertyItem extends React.Component<Props> {

    /**
     * New component instance
     */
    constructor(props:Props) {
        super(props);
    }
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["property-item"],
        };
    }

    render() {
        const { t , property} = this.props;
        return (
            <div className={styles.property_list}>
                <div className={styles.property_img}>
                    <div className={styles.property_main_img}>
                        <Swiper
                            slidesPerView={1}
                            scrollbar={{ draggable: true, hide: true }}
                            pagination={{type:"fraction"}}
                        >
                            {property.mainImages().map((propertyFile, index) => {
                                return (
                                    <SwiperSlide key={index}>
                                        <a href="#">
                                            <img src={ propertyFile } alt=""/>
                                        </a>
                                    </SwiperSlide>
                                )
                            })}
                        </Swiper>
                    </div>
                    <div className={styles.overlay_top}>
                        <div className={styles.top_lt}>
                        </div>
                        <div className={styles.top_rt}>
                            <a href="#">
                                <img src="/images/line-heart.png" alt=""/>
                            </a>
                        </div>
                    </div>
                </div>
                <div className={styles.prd_detail}>
                    <div className={styles.prd_sub_hd}>
                        {property.address()}
                    </div>
                    <div className={styles.prd_hd}>
                        <a href="#">
                            {property.title()}
                        </a>
                    </div>
                    <ul className={styles.amenities_block}>
                        <li>
                            <i className="icon-bedroom"></i> 
                            {property.attributes.noOfBedrooms} {t("LABELS.BEDS")}
                        </li>
                        <li>
                            <i className="icon-bath"></i> {property.attributes.noOfBedrooms} {t("LABELS.BATHS")}
                        </li>
                        <li>
                            <i className="icon-size"></i> {property.attributes.builtUpArea} {property.areaUnit()}
                        </li>
                    </ul>
                    <div className={styles.prc_block}>
                        <div className={styles.prc}>
                            {property.attributes.salePrice} {property.priceUnit()} 
                        </div>
                        <div className={styles.prd_logo}>
                            <img src="/images/aqua.png" alt=""/>
                        </div>
                    </div>
                    <ul className={styles.prd_social}>
                        <li>
                            <a href={"tel:"+property.owner.phone} target="_blank">
                                <img src="/images/phone.svg" alt=""/> {t("ACTIONS.CALL")}
                            </a>
                        </li>
                        <li>
                            <a href={`https://api.whatsapp.com/send?phone=91${property.owner.whatsApp}`} target="_blank">
                                <img src="/images/whatsapp.svg" alt=""/> {t("ACTIONS.WHATSAPP")}
                            </a>
                        </li>
                        <li>
                            <a href={`mailto:"${property.owner.email}`} target="_blank">
                                <img src="/images/email.svg" alt=""/> {t("ACTIONS.EMAIL")}
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}

export default withTranslation("property-item")(PropertyItem);