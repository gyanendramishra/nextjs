import React, { useState } from "react";
import { useTranslation } from 'react-i18next';
import { Formik, Field, Form, FormikHelpers, FormikContext } from "formik";

/**
 * Import components
 */

import PropertyType from "@/components/search/property-type";
import MinMaxPicker from "@/components/search/min-max-picker";
import Autocomplete from "@/components/search/autocomplete";

/**
 * Import utill, classes, types and etc
 */
import { TFilter } from "../../types";
import { bedroomList, bathroomList, priceList, sizeList, EPropertyFor, EPropertyType, EPagination, EPropertySort} from "../../utils";

/**
 * Import styles
 */
import styles from '../../styles/listing/search-filter.module.scss';

type TProps = {
    handleSearch: Function
}
const SearchFilter = (props: TProps) => {
    const { t } = useTranslation();
    const { handleSearch } = props;

    const [filters, setFilters] = useState<TFilter>({
        for: EPropertyFor.SALE,
        type: EPropertyType.RESIDENTIAL,
        sub_type: null,
        locations: [],
        country : null,
        bedrooms : null,
        bathrooms : null,
        price: {
            min: null,
            max: null
        },
        size: {
            min: null,
            max: null
        },
        sort: EPropertySort.DATE_DESC,
        from : 0,
        to : EPagination.PER_PAGE_COUNT
    });

    /**
     * Handle type on change
     * @param e: React.ChangeEvent<HTMLInputElement>
     */
    const handleTypeOnChange = async (e: React.ChangeEvent<HTMLInputElement>):Promise<string> => {
        const type = e.target.value;
        //const type = (filters.type === EPropertyType.RESIDENTIAL) ? EPropertyType.COMMERCIAL : EPropertyType.RESIDENTIAL;
        setFilters((prevState) => {
            prevState.type = type;
            return ({
                ...prevState
            });
        });
        return type;
    }

    /**
     * Handle form on submit
     * @param formData:TFilter
     */
    const onHandleSearch = async (formData:TFilter): Promise<void> => {
        handleSearch(formData);
    }
    
    return (
        <>
            <Formik
                enableReinitialize={ true }
                initialValues={
                    filters
                }
                onSubmit={
                    async (values: TFilter, { setSubmitting }: FormikHelpers<TFilter>) => {
                        await onHandleSearch(values);
                        setSubmitting(false);
                    }
                }
            >
                {() => (
                    <Form>
                        <div className={styles.search_filter_outer}>
                            <div className={styles.search_filter}>
                                <div className={styles.container}>
                                    <div className={`${styles.adv_row} ${styles.mbl_row}`}>
                                        <div className={styles.adv_col1}>
                                            <Field as="select" className={styles.form_control} name="for">
                                                <option value={EPropertyFor.SALE}>{ t("MAIN_SEARCH.SEARCH_FOR.FOR_SALE") }</option>
                                                <option value={EPropertyFor.RENT}>{ t("MAIN_SEARCH.SEARCH_FOR.FOR_RENT") }</option>
                                            </Field>
                                        </div>
                                        <div className={styles.adv_col1}>
                                            <Field
                                                as="select"
                                                name="type"
                                                className={styles.form_control}
                                                onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                                            >
                                                <option value={EPropertyType.RESIDENTIAL}>
                                                    {t("MAIN_SEARCH.SEARCH_TYPE.RESIDENTIAL")}
                                                </option>
                                                <option value={ EPropertyType.COMMERCIAL }>
                                                    {t("MAIN_SEARCH.SEARCH_TYPE.COMMERCIAL")}
                                                </option>
                                            </Field>
                                        </div>
                                        <div className={styles.adv_col1}>
                                            <PropertyType
                                                name="sub_type"
                                                lable = { t("MAIN_SEARCH.LABELS.PROPERTY_TYPE")}
                                                category = { filters.type }
                                                styles = { styles }
                                            ></PropertyType>
                                        </div>
                                        <div className={styles.adv_col1}>
                                            <Field 
                                                as="select" 
                                                className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                                name="bedrooms" 
                                            >
                                                <option value="">{ t("MAIN_SEARCH.LABELS.BEDS") }</option>
                                                { bedroomList.map((option, index) => {
                                                    return (
                                                        <option key={index} value={ option }>{ option }</option>
                                                    );
                                                })}
                                            </Field>
                                        </div>
                                        <div className={styles.adv_col1}>
                                            <Field 
                                                as="select" 
                                                className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                                name="bathrooms" 
                                            >
                                                <option value="">{ t("MAIN_SEARCH.LABELS.BATHS") }</option>
                                                { bathroomList.map((option, index) => {
                                                    return (
                                                        <option key={index} value={ option }>{ option }</option>
                                                    );
                                                })}
                                            </Field>
                                        </div>
                                        <div className={styles.adv_col2}>
                                            <MinMaxPicker 
                                                name="price"
                                                label={ t("MAIN_SEARCH.LABELS.PRICE") }
                                                options={ priceList }
                                            ></MinMaxPicker> 
                                        </div>
                                    </div>
                                    <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
                                        <div className={styles.adv_col2}>
                                            <MinMaxPicker 
                                                name="size"
                                                label={ t("MAIN_SEARCH.LABELS.SIZE") }
                                                options={ sizeList }
                                            ></MinMaxPicker>
                                        </div>
                                        <div className={styles.adv_col3}>
                                            <Autocomplete 
                                                name="locations"
                                            ></Autocomplete>
                                        </div>
                                        <div className={styles.adv_col4}>
                                            <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button>
                                            <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Form>
                )}
            </Formik>
        </>
    );
}

export default SearchFilter;
