import React from "react";
import { useTranslation } from 'react-i18next';

/**
 * Import utill, classes, types and etc
 */
import { EPropertyDisplayMode, EPropertySort } from "utils";

/**
 * Import styles
 */
import styles from '../../styles/listing/property-sort-filter.module.scss';

type TProps = {
    totalResult: number;
    proprtyDisplayMode: string;
    handleSorting: Function;
    switchPropertyDisplayMode : Function;
}

const PropertySortFilter = (props: TProps) => {
    const { totalResult, proprtyDisplayMode, handleSorting, switchPropertyDisplayMode } = props;
    const { t } = useTranslation();
    /**
     * Render the Html
     */
    return (
        <div className={styles.property_sort_filter}>
            <div className={styles.container}>
                <div className="row">
                    <div className="col-md-8">
                        <div className={styles.sort_lt}>
                            <div className={styles.hd_block2}>
                                { (totalResult > 0) && (
                                    <>
                                        <h2>Properties for Rent in Saudi Arabia</h2>
                                        <p>{totalResult} results</p>
                                    </>
                                )}
                            </div>
                            <div className={styles.rt_filter}>
                                <div className={styles.rt_col1}>
                                    <select className={styles.form_control} onChange={(event)=> handleSorting(event)}>
                                        <option value={ EPropertySort.DATE_DESC}>Sort by: All</option>
                                        <option value={ EPropertySort.RELEVENCE }>{ t("SEARCH_SORT.RELEVANCE") }</option>
                                        <option value={ EPropertySort.EXCLUSIVE }>{ t("SEARCH_SORT.EXCLUSIVE") }</option>
                                        <option value={ EPropertySort.PRICE_LOW_TO_HIGH }>{ t("SEARCH_SORT.LOW_TO_HIGH") }</option>
                                        <option value={ EPropertySort.PRICE_HIGH_TO_LOW }>{ t("SEARCH_SORT.HIGH_TO_LOW") }</option>
                                    </select>
                                </div>
                                <div className={styles.rt_col1}>
                                    <a className={styles.form_control}><i className="icon-pin"></i> View On map</a>
                                </div>
                                <div className={styles.rt_col2}>
                                    <a className={`${styles.grid_btn} ${ (proprtyDisplayMode === EPropertyDisplayMode.GRID) ? styles.active : ''}`} onClick={()=> switchPropertyDisplayMode(EPropertyDisplayMode.GRID) }>Grid</a>
                                </div>
                                <div className={styles.rt_col2}>
                                    <a className={`${styles.list_btn} ${ (proprtyDisplayMode === EPropertyDisplayMode.LIST) ? styles.active : ''}`} onClick={()=> switchPropertyDisplayMode(EPropertyDisplayMode.LIST) }>List</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PropertySortFilter;

