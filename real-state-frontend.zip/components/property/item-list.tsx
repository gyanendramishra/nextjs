import React from "react";
import { useTranslation } from 'react-i18next';

import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Navigation, Scrollbar } from 'swiper';

SwiperCore.use([Navigation, Pagination, Scrollbar]);

/**
 * component styles
 */
import styles from '../../styles/property/item-list.module.scss';

/**
 * import classes
 */
import { Property } from '../../classes/property';

type TProps = {
    property: Property
}

const PropertyListItem = (props: TProps) => {
    const {  property} = props;
    const { t } = useTranslation();

    /**
     * Populate video of item
     * @param src: string
     * @return void
     */
    const handleVideo = (src: string): void => {
        //this.props.handleVideo(src);
    }
    /**
     * Render component template
     */
    return (
        <div className={styles.property_list}>
            <div className={styles.property_img}>
                <div className={styles.property_main_img}>
                    <Swiper
                        slidesPerView={1}
                        navigation
                        scrollbar={{ draggable: true, hide: true }}
                        pagination={{type:"fraction"}}
                    >
                        {property.mainImages().map((propertyFile, index) => {
                            return (
                                <SwiperSlide key={index}>
                                    <a href="#">
                                        <img src={ propertyFile } alt=""/>
                                    </a>
                                </SwiperSlide>
                            )
                        })}
                    </Swiper>
                </div>
                <div className={styles.overlay_top}>
                    <div className={styles.top_lt}>
                        <div className={styles.new}><i className="icon-circle-with-check-symbol"></i> Exclusive</div>
                    </div>
                    <div className={styles.top_rt}>
                        <a href="#">
                            <img src="/images/line-heart.png" alt=""/>
                        </a>
                    </div>
                    { ((property.externalVideoLink) || (property.externalUrl)) && (
                    <div className={styles.degree_icon}>
                        { (property.externalUrl) && (
                            <a className={styles.degree} href={ property.externalUrl } target="_blank">
                                <i className="icon-degrees"></i>
                            </a>
                        )}
                        { (property.externalVideoLink) && (
                            <a onClick={()=> handleVideo(property.externalVideoLink) }>
                                <i className="icon-play-button"></i>
                            </a>
                        )}
                    </div>
                    )}
                </div>
                <div className={styles.degree_icon}>
                    <a className={styles.degree} href="#"><i className="icon-degrees"></i></a>
                    <a href="#"><i className="icon-play-button"></i></a>
                </div>
            </div>
            
            <div className={styles.prd_detail}>
                <div className={styles.prd_sub_hd}>
                    {property.shortAddress()}
                </div>
                <div className={styles.prd_hd}>
                    <a href="#">
                        {property.title()}
                    </a>
                </div>
                <ul className={styles.amenities_block}>
                    <li>
                        <i className="icon-bedroom"></i> 
                        {property.attributes.noOfBedrooms} {t("PROPERTY_ITEM.LABELS.BEDS")}
                    </li>
                    <li>
                        <i className="icon-bath"></i> {property.attributes.noOfBedrooms} {t("PROPERTY_ITEM.LABELS.BATHS")}
                    </li>
                    <li>
                        <i className="icon-size"></i> {property.attributes.builtUpArea} {property.areaUnit()}
                    </li>
                </ul>
                <div className={styles.prc_block}>
                    <div className={styles.prc}>
                        { property.attributes.salePrice.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",")} {property.priceUnit()} 
                    </div>
                    <div className={styles.prd_logo}>
                        <img src="/images/aqua.png" alt=""/>
                    </div>
                </div>
                <ul className={styles.prd_social}>
                    <li>
                        <a href={"tel:"+property.owner.phone} target="_blank">
                            <i className="icon-call"></i> {t("PROPERTY_ITEM.ACTIONS.CALL")}
                        </a>
                    </li>
                    <li>
                        <a href={`https://api.whatsapp.com/send?phone=91${property.owner.whatsApp}`} target="_blank">
                            <i className="icon-whatsapp"></i> {t("PROPERTY_ITEM.ACTIONS.WHATSAPP")}
                        </a>
                    </li>
                    <li>
                        <a href={`mailto:"${property.owner.email}`} target="_blank">
                            <i className="icon-email"></i> {t("PROPERTY_ITEM.ACTIONS.EMAIL")}
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    );
}

export default PropertyListItem;