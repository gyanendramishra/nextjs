import React, { useState, useEffect } from "react";
import PropTypes from 'prop-types'
import { useTranslation } from 'react-i18next';
import {useField, FieldConfig } from "formik";

/**
 * Import services, types and utils
 */
import { getPropertyTypes } from "../../services";
import { TPropertyType } from "../../types";


type TProps =  {
    category: string;
    lable: string;
    styles: TStyle;
} & FieldConfig

type TStyle = {
    readonly [key: string]: string;
}

const PropertyType = (props:TProps) => {

    const { i18n } = useTranslation();
    const { language } = i18n;
    const [ field ] = useField(props);
    const { lable, styles, category } = props;

    const [types, setTypes] = useState<Array<TPropertyType>>([]);

    useEffect(() => { 
        findPropertyTypes(language, category);
    }, [category, language]);

    /**
     * Get locations by keyword
     * @param locale: string
     * @param category: string
     * @return void
     */
    const findPropertyTypes = async (locale: string, category: string) => {
        try{
            const result = await getPropertyTypes(locale, category);
            if(result.status === true){
                setTypes(result.data);
            }else{
                console.log(result.message);
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Render the html
     * @return void
     */
    return (
        <select className={styles.form_control} { ...field}>
            <option value="">{ lable }</option>
            {types && types.map((type, index) => {
                return (
                    <optgroup label={ type.name } key={ index }>
                        { type.options.map((option, index) => {
                            return (
                                <option key={ index } value={ option.option_id }>{ option.option_name }</option>
                            )
                        })}
                    </optgroup>
                );
            })}
        </select>
    )
};

  
PropertyType.propTypes = {
    category: PropTypes.string.isRequired,
    lable: PropTypes.string.isRequired,
}

export default PropertyType;