import React, { useContext, useState } from "react";
import { useTranslation } from 'react-i18next';
import { useField, FieldConfig, useFormikContext } from "formik";


/**
 * Import services, types and utils
 */
import { TSuggestion, TTag } from "../../types";
import { autocompleteLocations } from "../../services";
/**
 * component styles
 */
// import styles from '../../styles/components/autocomplete2.module.scss';
import styles from '../../styles/search/autocomplete.module.scss';

type TProps = {
    // readonly t: TFunction;
    containerClass : string;
} &  FieldConfig

const Autocomplete = (props:TProps) => {

    const { containerClass } = props;
    const [ field ] = useField(props);
    // const { i18n: { language } } = useContext(I18nContext);
    const { setFieldValue } = useFormikContext();

    const inputRef:React.RefObject<HTMLInputElement> = React.createRef();
    
    const [tags, setTags] = useState<Array<TTag>>([]);
    const [keyword, setKeyword] = useState<string>("");
    const [matchedIndex, setMatchedIndex] = useState<number>(0);
    const [suggestions, setSuggestions] = useState<Array<TSuggestion>>([]);
    const [matchedSuggestions, setMatchedSuggestions] = useState<Array<TSuggestion>>([]);

    const { t } = useTranslation();

    /**
     * Handle autocomplete on change
     * @param e:React.ChangeEvent<HTMLInputElement>
     * @return void
     */
    const handleAutocompleteOnChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        const keyword = e.currentTarget.value;
        const matchedSuggestions = suggestions.filter(
            suggestion => suggestion.name.toLowerCase().indexOf(keyword.toLowerCase()) > -1
        );
        setKeyword(keyword);
        setMatchedIndex(0);
        setMatchedSuggestions(matchedSuggestions);
    };

 

    /**
     * Handle selected suggestion from suggestion list
     * @param suggestion: string
     * @return void
     */
    const handleSuggestionSelect = (suggestion: string): void => {
        if (tags.find(tag => tag.name.toLowerCase() === suggestion.toLowerCase())) {
            return;
        }
        const selectedSuggestion = suggestions.find(item => item.name === suggestion);
        if(selectedSuggestion){
            tags.push({
                model_id : selectedSuggestion.model_id,
                name: selectedSuggestion.name,
                model: selectedSuggestion.model
            });
            setTags(tags);
            setFieldValue(field.name, tags);
        }
        setKeyword("");
        setMatchedIndex(0);
        setSuggestions([]);
        setMatchedSuggestions([]);

        if(inputRef.current){
            inputRef.current.value = "";
            inputRef.current.placeholder = "";
        }

        
    };

    /**
     * Handle selected suggestion on key down
     * @param e:React.KeyboardEvent<HTMLInputElement>, suggestion: string
     * @return void
     */
    const handleAutosuggestionOnKeyDown = (e: React.KeyboardEvent<HTMLInputElement>): void => {        
        if (e.key === '13') {
            setKeyword(matchedSuggestions[matchedIndex].name);
            setMatchedIndex(0);
        }else if (e.key === '38') {
            if (matchedIndex === 0) {
                return;
            }
            setMatchedIndex(matchedIndex - 1);
        }else if (e.key === '40') {
            if (matchedIndex - 1 === matchedSuggestions.length) {
                return;
            }
            setMatchedIndex(matchedIndex + 1);
        }
    };

    /**
     * Remove autocomplete tag
     * @param index: number
     * @return void
     */
    const removeAutocompleteTag = (index: number):void => {
        tags.splice(index, 1);
        setTags(tags);
        setFieldValue(field.name, tags);
        if((tags.length <= 0) && inputRef.current){
            inputRef.current.placeholder = t("PLACEHOLDER");
        }
    }

    /**
     * Handle autocomplete on input key down
     * @param e: React.ChangeEvent<HTMLInputElement>
     * @return void
     */
    const handleAutosuggestionoOnInputKeyDown = (e:React.KeyboardEvent<HTMLInputElement>) : void => { 
        let keyword = (e.target as HTMLInputElement).value;
        if (e.key === 'Enter' && keyword) {
            if(keyword.length > 2){
                const matchedSuggestion = matchedSuggestions[matchedIndex];
                if(!matchedSuggestion){
                    return
                }
                if (tags.find(tag => tag.name.toLowerCase() === matchedSuggestion.name.toLowerCase())) {
                    return;
                }
                tags.push({
                    model_id : matchedSuggestion.model_id,
                    name: matchedSuggestion.name,
                    model: matchedSuggestion.model
                });
                setTags(tags);
                setFieldValue(field.name, tags);
                (e.target as HTMLInputElement).value = "";
            }
        } else if ((e.key === 'Backspace') && !keyword) {
            if(tags.length){
                removeAutocompleteTag(tags.length - 1);
            }
        }
        if((e.key != 'ArrowDown') && (e.key != 'ArrowUp') && (e.key != 'Enter')) {
            if(keyword && keyword.length > 2){
                getLocationsByKeyword(keyword);
            }
        }
    }

    /**
     * Get locations by keyword
     * @param keyword: string
     * @return void
     */
    const getLocationsByKeyword = async (keyword: string) => {
        const result = await autocompleteLocations(
            'en',
            keyword,
            tags
        );
        if(result.status === true){
            setSuggestions(result.data);
            setMatchedSuggestions(result.data);
        }else{
            console.log(result.message);
        }
    }

    let suggestionsListComponent;

    if (suggestions.length) {
        suggestionsListComponent = (
            <ul className={styles.suggestions}>
                {suggestions.map((suggestion:TSuggestion, index) => {
                    return (
                        <li
                            className={styles.suggestion_active}
                            key={index}
                            onClick={()=> handleSuggestionSelect(suggestion.name)}
                        >
                            <div className={styles.suggestion_div}>
                                <span className={styles.left_search_text}>{suggestion.name}</span>
                                <span className={styles.right_search_text}>{suggestion.parent_name}</span>
                            </div>
                        </li>
                    );
                })}
            </ul>
        );
    }else if(keyword){
        suggestionsListComponent = (
            <div className={styles.no_suggestions}>
                <em>{ t("NO_SUGGESTED_LOCATIONS_FOUND") }</em>
            </div>
        );
    }
    
    return (
        <>
            <div className={styles.input_tag}>
                <ul className={styles.input_tag__tags}>
                    { tags.map((tag, index) => (
                        <li key={index}>
                            { tag.name }
                            <button type="button" onClick={() => { removeAutocompleteTag(index); }}>+</button>
                        </li>
                    ))}
                    <li className={styles.input_tag__tags__input}>
                        
                        <input 
                            type="text"
                            ref={inputRef}
                            onChange={(event)=> handleAutocompleteOnChange(event)}
                            onKeyUp={ (event)=>{ handleAutosuggestionoOnInputKeyDown(event); handleAutosuggestionOnKeyDown(event); }} 
                            placeholder={ t("PLACEHOLDER") }
                        />
                        <input  {...field} style={{ display: "none"}}  />
                    </li>

                </ul>
            </div>
            {suggestionsListComponent}
        </>
    )
};


// export default withTranslation("autocomplete")(Autocomplete)
export default Autocomplete