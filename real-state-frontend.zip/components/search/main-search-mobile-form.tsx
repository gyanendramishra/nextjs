import React from "react";
import PropTypes from "prop-types";
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { Formik, Form, Field, FormikHelpers } from "formik";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { TCountry, TCategory } from "../../types";
import { EPropertyFor, EPropertyType } from "../../utils";
import { beadroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import Autocomplete from "@/components/search/autocomplete";
import PropertyType from "@/components/search/property-type";

type TProps = {
    readonly t: TFunction; 
    styles: TStyle;
    masters: TMaster;
    filters: TFilter; 
    handleSearch : Function;
    changePropertyFor: Function;
    toggleAdvanceSearch: Function;
} & ReactI18nextWithTranslation

type TFilter = {
    advanceSearch: boolean;
    for: string;
    type: string;
    locations: Array<{}>;
    category: number | null;
    country: number | null;
    sub_type: string | null;
    beadrooms : number | null;
    bathrooms : number | null;
    minPrice: number | null;
    maxPrice: number | null;
    minSize: number | null;
};

type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};

type TStyle = {
    readonly [key: string]: string;
}

const MainSearchMobileForm = (props:TProps) => {

    const { 
        t, 
        styles, 
        filters,
        handleSearch,
    } = props;

    return (
        <div className={styles.open_advance}>                                     
            <div className={`${styles.search_mobile_block_outer}`}>
                <div className={styles.search_category_nav}>
                    <ul className="d-flex">
                        <li><a className={styles.active}>For Sale</a></li>
                        <li><a>For Rent</a></li>
                        <li><a>International</a></li>
                    </ul>
                </div>
                <Formik
                    initialValues={filters}
                    onSubmit={async (
                        values: TFilter,
                        {
                            setSubmitting,
                        }: FormikHelpers<TFilter>
                    ) => {
                        console.log(values);
                        await handleSearch(values);
                        setSubmitting(false);
                    }}
                >
                    {() => (
                        <Form>
                            <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
                                <div className={styles.adv_col_full}>
                                    <Autocomplete name="locations" ></Autocomplete>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field
                                        as="select"
                                        name="type"
                                        className={styles.form_control}
                                    >
                                        <option value={EPropertyType.RESIDENTIAL}>
                                            {t("SEARCH_TYPE.RESIDENTIAL")}
                                        </option>
                                        <option value={ EPropertyType.COMMERCIAL }>
                                            {t("SEARCH_TYPE.COMMERCIAL")}
                                        </option>
                                    </Field>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <PropertyType
                                        name="sub_type"
                                        lable = { t("LABELS.PROPERTY_TYPE")}
                                        category = { filters.type }
                                        styles = { styles }
                                    ></PropertyType>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field as="select" className={styles.form_control} name="beadrooms">
                                        <option value="">{ t("LABELS.BEDS") }</option>
                                        { beadroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field as="select" className={styles.form_control} name="bathrooms">
                                        <option value="">{ t("LABELS.BATHS") }</option>
                                        { bathroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.min_max_outer}>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="price[min]" className={styles.form_control}>
                                            { priceList.min.map((minPrice, index) => {
                                                <option key={index} value={minPrice}>{ minPrice }</option>
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.wd2}>
                                        <span>to</span>
                                    </div>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="price[max]" className={styles.form_control}>
                                            { priceList.max.map((maxPrice, index) => {
                                                <option key={index} value={maxPrice}>{ maxPrice }</option>
                                            })}
                                        </Field>
                                    </div>
                                </div>
                                <div className={styles.min_max_outer}>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="size[min]" className={styles.form_control}>
                                            { sizeList.min.map((minSize, index) => {
                                                <option key={index} value={minSize}>{ minSize }</option>
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.wd2}>
                                        <span>to</span>
                                    </div>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="size[max]" className={styles.form_control}>
                                            { sizeList.max.map((maxSize, index) => {
                                                <option key={index} value={ maxSize }>{ maxSize }</option>
                                            })}
                                        </Field>
                                    </div>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <button type="submit" className={styles.mbl_find_btn}>Find</button>
                                </div>
                                <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
                                    <a className={`${styles.right_link} ${styles.mobile_link}`}><i className="icon-levels"></i> Close Advanced Search</a>
                                </div>
                            </div>
                        </Form>
                    )}
                </Formik>
            </div>
        </div>
    );
}

MainSearchMobileForm.propTypes = {
    t: PropTypes.func.isRequired,
}

export default withTranslation("main-search")(MainSearchMobileForm);

