import React from "react";
import axios from "axios";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import component types
 */
import { TSuggestion } from "../../types";

/**
 * component styles
 */
import styles from '../../styles/search/autocomplete.module.scss';

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction
}

interface TState {
    keyword: string;
    tags: TTags[];
    suggestions: TSuggestion[];
    matchedSuggestions: TSuggestion[];
    matchedIndex: number;
};

type TTags = {
    model_id: number;
    name: string;
    model: string;
}

class Autocomplete extends React.Component<Props, TState> {
    /**
     * New component instance
     */
    private inputRef:React.RefObject<HTMLInputElement>;

    constructor(props: Props) {
        super(props);
        this.state = {
            tags: [],
            keyword: "",
            matchedIndex: 0,
            suggestions: [],
            matchedSuggestions: []
        };
        this.inputRef = React.createRef();
    }

    /**
     * Handle autocomplete on change
     * @param e:React.ChangeEvent<HTMLInputElement>
     * @return void
     */
    handleAutocompleteOnChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        const { suggestions } = this.state;
        const keyword = e.currentTarget.value;
        const matchedSuggestions = suggestions.filter(
            suggestion => suggestion.name.toLowerCase().indexOf(keyword.toLowerCase()) > -1
        );
        this.setState({
            matchedIndex: 0,
            matchedSuggestions,
            keyword: keyword
        });
    };

    /**
     * Handle selected suggestion from suggestion list
     * @param e:React.MouseEvent<HTMLLIElement, MouseEvent>, suggestion: string
     * @return void
     */
    handleSuggestionSelect = (e:React.MouseEvent<HTMLLIElement, MouseEvent>, suggestion: string): void => {
        const { suggestions, tags} = this.state;
        if (tags.find(tag => tag.name.toLowerCase() === suggestion.toLowerCase())) {
            return;
        }
        const selectedSuggestion = suggestions.find(item => item.name === suggestion);
        if(selectedSuggestion){
            tags.push({
                model_id : selectedSuggestion.model_id,
                name: selectedSuggestion.name,
                model: selectedSuggestion.model
            });
            this.setState({tags: tags});
        }
        this.setState({
            keyword: "",
            suggestions: [], 
            matchedIndex: 0,
            matchedSuggestions: []
        });
        
        //(e.target as HTMLInputElement).value = "";
        if(this.inputRef.current){
            this.inputRef.current.value = "";
            this.inputRef.current.placeholder = "";
        }

        
    };

    /**
     * Handle selected suggestion on key down
     * @param e:React.KeyboardEvent<HTMLInputElement>, suggestion: string
     * @return void
     */
    handleAutosuggestionOnKeyDown = (e: React.KeyboardEvent<HTMLInputElement>): void => {        
        const { matchedIndex, matchedSuggestions } = this.state;
        if (e.key === '13') {
            this.setState({
                matchedIndex: 0,
                keyword: matchedSuggestions[matchedIndex].name
            });
        }else if (e.key === '38') {
            if (matchedIndex === 0) {
                return;
            }
            this.setState({ matchedIndex: matchedIndex - 1 });
        }else if (e.key === '40') {
            if (matchedIndex - 1 === matchedSuggestions.length) {
                return;
            }
            this.setState({ matchedIndex: matchedIndex + 1 });
        }
    };

    /**
     * Remove autocomplete tag
     * @param index: number
     * @return void
     */
    removeAutocompleteTag = (index: number):void => {
        const { tags } = this.state;
        tags.splice(index, 1);
        this.setState({ tags: tags }); 
        if((tags.length <= 0) && this.inputRef.current){
            this.inputRef.current.placeholder = "Search City, Area";
        }
    }

    /**
     * Handle autocomplete on input key down
     * @param e: React.ChangeEvent<HTMLInputElement>
     * @return void
     */
    handleAutosuggestionoOnInputKeyDown = (e:React.KeyboardEvent<HTMLInputElement>) : void => { 
        const { tags, matchedSuggestions, matchedIndex } = this.state;
        let keyword = (e.target as HTMLInputElement).value;
        if (e.key === 'Enter' && keyword) {
            if(keyword.length > 2){
                const matchedSuggestion = matchedSuggestions[matchedIndex];
                if(!matchedSuggestion){
                    return
                }
                if (tags.find(tag => tag.name.toLowerCase() === matchedSuggestion.name.toLowerCase())) {
                    return;
                }
                tags.push({
                    model_id : matchedSuggestion.model_id,
                    name: matchedSuggestion.name,
                    model: matchedSuggestion.model
                });
                this.setState({tags: tags});
                (e.target as HTMLInputElement).value = "";
            }
        } else if ((e.key === 'Backspace') && !keyword) {
            if(tags.length){
                this.removeAutocompleteTag(tags.length - 1);
            }
        }
        if((e.key != 'ArrowDown') && (e.key != 'ArrowUp') && (e.key != 'Enter')) {
            if(keyword && keyword.length > 2){
                this.getLocationsByKeyword(keyword);
            }
        }
    }

    /**
     * Get locations by keyword
     * @param keyword: string
     * @return void
     */
    getLocationsByKeyword = (keyword: string):void => {
        const { tags } = this.state;
        let body: object = {};
        if(tags.length > 0){            
            body = {
                "keyword": keyword,
                "model_id": tags[(tags.length-1)].model_id,
                "model": tags[(tags.length-1)].model
            };
        } else {
            body = {"keyword": keyword};
        }
        axios.post(
            `${process.env.NEXT_PUBLIC_MISC_SERVICE_END_POINT}/search-box/locations`, 
            body, 
            { headers: {'locale': 'en'}} 
        ).then((response)=>{
            const { data } = response.data;
            this.setState({
                ...this.state,
                suggestions: data,
                matchedSuggestions: data
            });
        });
    }

    /**
     * Render the component
     * @param keyword: string
     * @return void
     */
    render(){
        const { suggestions, tags, keyword } = this.state;

        let suggestionsListComponent;

        if (suggestions.length) {
            suggestionsListComponent = (
                <ul className={styles.suggestions}>
                    {suggestions.map((suggestion:TSuggestion, index) => {
                        return (
                            <li
                                className={styles.suggestion_active}
                                key={index}
                                onClick={(event)=> this.handleSuggestionSelect(event, suggestion.name)}
                            >
                                <div className={styles.suggestion_div}>
                                    <span className={styles.left_search_text}>{suggestion.name}</span>
                                    <span className={styles.right_search_text}>{suggestion.parent_name}</span>
                                </div>
                            </li>
                        );
                    })}
                </ul>
            );
        }else if(keyword){
            suggestionsListComponent = (
                <div className={styles.no_suggestions}>
                    <em>No suggested locations found</em>
                </div>
            );
        }

        return (
            <>
                <div className={styles.input_tag}>
                    <ul className={styles.input_tag__tags}>
                        { tags.map((tag, index) => (
                            <li key={index}>
                                { tag.name }
                                <button type="button" onClick={() => { this.removeAutocompleteTag(index); }}>+</button>
                            </li>
                        ))}
                        <li className={styles.input_tag__tags__input}>
                            <input 
                                type="text"
                                ref={this.inputRef}
                                onChange={(event)=> this.handleAutocompleteOnChange(event)}
                                onKeyUp={ (event)=>{ this.handleAutosuggestionoOnInputKeyDown(event); this.handleAutosuggestionOnKeyDown(event); }} 
                                placeholder="Search City, Area" 
                            />
                        </li>
                    </ul>
                </div>
                {suggestionsListComponent}
            </>
        )
    }
    
}

export default withTranslation("autocomplete")(Autocomplete)