import React, { useState, useContext } from "react";
import PropTypes from "prop-types";
import { TFunction, I18nContext } from "next-i18next";
import { withTranslation } from "../../i18n";
import throttle from 'lodash.throttle';
import { connect } from 'react-redux';
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import services, types and utils
 */
import { EPropertyFor, EPropertyType} from "../../utils";
import { mainSearchElements } from "../../services";
import { TFilter, TMaster, TSSearch  } from "../../types";

/**
 * Import page components
 */
import LocationSearch from "@/components/search/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";

import { forFilterChanged } from "../../stores/actions";

/**
 * Component styles
 */
import styles from "../../styles/search/main-search.module.scss";

type TProps = {
    readonly t: TFunction; 
    storage: TSSearch;
    changeForFilter: Function;
} & ReactI18nextWithTranslation;

const MainSearch = (props:TProps) => {
    const { t, storage, changeForFilter } = props;
    const { i18n: { language } } = useContext(I18nContext);

    const [isMobile, setIsMobile] = useState<boolean>(false);
    
    const [masters, setMasters] = useState<TMaster>({
        categories: [],
        countries: []
    });

    const [filters, setFilters] = useState<TFilter>({
        advanceSearch: false,
        propertyFor: EPropertyFor.SALE,
        propertyType: EPropertyType.COMMERCIAL,
        propertySubType: null,
        locations: [],
        country : null,
        beadrooms : null,
        bathrooms : null,
        price: null,
        size: null,
    });

    /**
     * Trigger react lifecycle hook
     */
    React.useEffect(() => {
        getMainSearchElements();
        window.addEventListener('resize', throttledHandleWindowResize);
    }, [language, isMobile]);

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        return throttle(() => {
            if((window.innerWidth <= 767)){
                setIsMobile(true);
            }else{
                setIsMobile(false);
            }
        }, 200);
    }

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = (): void => {
        if (filters.advanceSearch === true) {
            setFilters((prevState) => {
                prevState.advanceSearch = false;
                return({
                  ...prevState
                })
              }
            );
        } else {
            setFilters((prevState) => {
                prevState.advanceSearch = true;
                return({
                  ...prevState
                })
              }
            );
        }
        
    };

    /**
     * Switch property for
     * @param propertyFor: string
     * @return void
     */
    const switchPropertyFor = (propertyFor: string): void => {
        changeForFilter(propertyFor);
        setFilters((prevState) => {
            prevState.propertyFor = propertyFor;
            return({
              ...prevState
            })
          }
        );
    };
    

    /**
     * Handle form submit
     * @param formData: TFilter
     * @return response
     */
    const onHandleSearch = (formData:TFilter):void => {
        //formData.propertyFor = filters.propertyFor;
        //alert(JSON.stringify(formData, null, 2));
        console.log(formData);
    }

    /**
     * Get the search masters
     * @return void
     */
    const getMainSearchElements = async () : Promise<void> => {
        const result = await mainSearchElements(language);
        if(result.status === true){
            setMasters(result.data);
        }else{
            console.error(result.message);
        }
    };

    /**
     * Seach component
     */
    let searchComponent;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { masters }
                filters = { filters } 
                storage = { storage }
                handleSearch = { onHandleSearch }
                changePropertyFor = { switchPropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { masters }
                filters = { filters } 
                storage = { storage }
                handleSearch = { onHandleSearch }
                changePropertyFor = { switchPropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        )
    }

    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    { searchComponent }
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ masters.categories }
                    propertyFor={ filters.propertyFor }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

/**
 * Validate prop types
 */
MainSearch.propTypes = {
    t: PropTypes.func.isRequired,
};

const mapDispatchToProps = (dispatch: (arg0: { type: string; payload: { for: string; }; }) => any) => ({
    changeForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor))
});

const mapStateToProps = (state: any) => ({
    storage:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslation("main-search")(MainSearch));
