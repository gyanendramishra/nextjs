import React, { useState, useLayoutEffect } from "react";
import { connect } from 'react-redux';
import { useTranslation } from 'react-i18next';

/**
 * Import services, types and utils
 */
import { TFilter, TMaster  } from "../../types";

/**
 * Import page components
 */
import LocationSearch from "@/components/search/location-search";
import MainSearchWebForm from "@/components/search/main-search-web-form";
import MainSearchMobileForm from "@/components/search/main-search-mobile-form";

import { forFilterChanged, advanceSearchFilterChanged } from "../../stores/actions";

/**
 * Component styles
 */
import styles from "../../styles/search/main-search.module.scss";

type TProps = {
    filters: TFilter;
    searchElements: TMaster;
    dispatchForFilter: Function;
    dispatchAdvanceSearchFilter: Function;
};

const MainSearch = (props:TProps) => {
    const {
        filters, 
        searchElements,
        dispatchForFilter, 
        dispatchAdvanceSearchFilter 
    } = props;

    const { t } = useTranslation();

    const [isMobile, setIsMobile] = useState<boolean>(false);


    useLayoutEffect(()=>{ 
        window.addEventListener('resize', throttledHandleWindowResize);
        return () => window.removeEventListener('resize', throttledHandleWindowResize);
    });

    /**
     * Trigger react Window Resize
     */
    const throttledHandleWindowResize = () => {
        if((window.innerWidth <= 767)){
            setIsMobile(true);
        }else{
            setIsMobile(false);
        }
    }

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = async (): Promise<void> => {
        if (filters.advanceSearch === true) {
            await dispatchAdvanceSearchFilter(false);
        } else {
            await dispatchAdvanceSearchFilter(true);
        }
    };

    /**
     * Change property for
     * @param propertyFor: string
     * @return void
     */
    const changePropertyFor = async (propertyFor: string):Promise<void> => {
        await dispatchForFilter(propertyFor);
    };

    /**
     * Seach component
     */
    let searchComponent;

    if(isMobile === true){
        searchComponent = (
            <MainSearchMobileForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                changePropertyFor = { changePropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        );
    }else{
        searchComponent = (
            <MainSearchWebForm
                styles = { styles }
                masters = { searchElements }
                filters = { filters }
                changePropertyFor = { changePropertyFor }
                toggleAdvanceSearch = { toggleAdvanceSearch }
            />
        )
    }

    return (
       <div className={styles.search_outer}>
           <div className={styles.container}>
               <div className={styles.search_block_outer}>
                    <div className="text-center">
                        <h1>{t("MAIN_SEARCH.LABELS.SEARCH_PROPERTIES_FOR_SALE_RENT")}</h1>
                    </div>
                    { searchComponent }
                </div>
                {/* Location search component */}
                <LocationSearch 
                    styles = { styles }
                    categories={ searchElements.categories }
                    propertyFor={ filters.for }
                ></LocationSearch>
                {/* Mobile Popup Search Filter */}
            </div>
        </div>
    );
}

const mapDispatchToProps = (dispatch: any) => ({
    dispatchForFilter: (propertyFor:string) => dispatch(forFilterChanged(propertyFor)),
    dispatchAdvanceSearchFilter: (advanceSearch:boolean) => dispatch(advanceSearchFilterChanged(advanceSearch))
});

const mapStateToProps = (state: any) => ({
    filters:state.filters
});

export default connect(mapStateToProps, mapDispatchToProps)(MainSearch);
