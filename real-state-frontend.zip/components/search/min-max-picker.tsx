import React, { ReactText } from "react";
import PropTypes from "prop-types";
import { TFunction } from "next-i18next";
import { withTranslation } from "../../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Component styles
 */
import styles from "../../styles/home/search-properties.module.scss";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    readonly label : string;
    readonly options: TPickerOption; 
}

interface States {
    min: ReactText | null;
    max: ReactText | null;
    opened : boolean; 
}

type TPickerOption = {
    min: ReactText[];
    max: ReactText[];
}

export class MinMaxPicker extends React.Component<Props, States> {

    /**
     * New component instance
     */
    constructor(props: Props) {
        super(props);
        this.state = {
            min: 0,
            max: "Any",
            opened: false 
        };
    }

    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
        label: PropTypes.string.isRequired
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["min-max-picker"],
        };
    }

    /**
     * Toggle the picker
     * @return void
     */
    public togglePicker = (): void => {
        const { opened } = this.state;
        if (opened === true) {
            this.setState({ opened: false });
        } else {
            this.setState({ opened: true });
        }
    };

    /**
     * Handle min value
     * @return void
     */
    public handleMinValue = (value : number | string): void => {
        this.setState({ min: value });
    };

    /**
     * Handle max value
     * @return void
     */
    public handleMaxValue = (value : number | string): void => {
        this.setState({ max: value });
    };

    /**
     * Handle min value on key up
     * @return void
     */
    public handleMinValueOnKeyUp = (e: React.KeyboardEvent<HTMLInputElement>): void => {
        this.handleMinValue((e.target as HTMLInputElement).value);
    };

    /**
     * Handle max value on key up
     * @return void
     */
    public handleMaxValueOnKeyUp = (e: React.KeyboardEvent<HTMLInputElement>): void => {
        this.handleMaxValue((e.target as HTMLInputElement).value);
    };


    /**
     * Triggers when component is failed
     * @return void
     */
    componentDidCatch = ():void => {
        console.error("Opps somthing went wrong. Min-max picker component not rendered.");
    };

    /**
     * Render the min max picker component
     * @return void
     */
    render(){
        const { t, label, options } = this.props;
        const { min, max, opened } = this.state;
        return (
            <>
                <div className={`${styles.form_control} ${styles.click_btn1}`} onClick={ this.togglePicker }>
                    <label className={styles.lbl}>{ label } {min}</label>
                        <span className={styles.span}>{ t("LABELS.TO") }</span>
                    <label className={styles.lbl}>{ max }</label>
                </div>
                { opened && (
                    <div className={`${styles.price_select_card} ${styles.open_box1}`}>
                        <div className={styles.card_block1}>
                            <div className={styles.card_lt}>
                                <div className={styles.label_value}>{ t("LABELS.MIN") }:</div>
                                <input type="text" placeholder={`${ min }`} className={styles.form_control} onKeyUp={ this.handleMinValueOnKeyUp }  />
                                <ul className={styles.listing_block}>
                                    { options.min.map((option, index) => {
                                        if(max as number <= option){
                                            return (
                                                <li key={index}>
                                                    <a className={ min == option ? styles.active : '' }>
                                                        <del>{ option }</del>
                                                    </a>
                                                </li>
                                            )
                                        }else{
                                            return (
                                                <li key={index}>
                                                    <a className={ min == option ? styles.active : '' } onClick={()=> this.handleMinValue(option)}>{ option }</a>
                                                </li>
                                            )
                                        }
                                    })}
                                </ul>
                            </div>
                            <div className={styles.card_rt}>
                                <div className={styles.label_value}>{ t("LABELS.MAX") }:</div>
                                <input type="text" placeholder={`${ max }`} className={styles.form_control} onKeyUp={ this.handleMaxValueOnKeyUp } />
                                <ul className={styles.listing_block}>
                                    <li>
                                        <a onClick={()=> this.handleMaxValue('Any')}>{ t("LABELS.ANY") }</a>
                                    </li>
                                    { options.max.map((option, index) => {
                                        if(min as number >= option){
                                            return (
                                                <li key={index}>
                                                    <a className={ max == option ? styles.active : '' }>
                                                        <del>{ option }</del>
                                                    </a>
                                                </li>
                                            )
                                        }else{
                                            return (
                                                <li key={index}>
                                                    <a className={ max == option ? styles.active : '' } onClick={()=> this.handleMaxValue(option)}>{ option }</a>
                                                </li>
                                            )
                                        }
                                    })}
                                </ul>
                            </div>
                        </div>
                        <div className={styles.btn_outer1}>
                            <a className={styles.close_btn1} onClick={ this.togglePicker }>
                                { t("LABELS.CLOSE") }
                            </a>
                        </div>
                    </div>
                )}
            </>
        );
    }
}

export default withTranslation("min-max-picker")(MinMaxPicker);