/*
 * Property type
 */
export type TPropertyType = {
  id: number;
  name: string;
  slug: string;
  options: TPropertyTypeOption[];
};

export type TPropertyTypeOption = {
  option_id: number;
  option_name: string;
  option_slug: string;
};
