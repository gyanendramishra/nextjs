import { TCategory, TCountry } from "./";

/**
 * Proprerty filter type
 */
export type TFilter = {
  for: string;
  type: string;
  sub_type: string | null;
  locations: Array<{}>;
  country: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  price: TMinMax;
  size: TMinMax;
};

export type TMinMax = {
  min: number | null;
  max: number | null;
};

/**
 * Master elements type
 */
export type TMaster = {
  categories: TCategory[];
  countries: TCountry[];
};
