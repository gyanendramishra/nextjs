import { TCategory, TCountry } from "./";

/**
 * Proprerty filter type
 */
export type TFilter = {
  for: string;
  type: string;
  sub_type: string | string[];
  locations: Array<{}>;
  country: number | string | string[];
  bedrooms: number | string | string[];
  bathrooms: number | string | string[];
  price: TMinMax;
  size: TMinMax;
  sort: string;
  from: number;
  to: number;
};

export type TMinMax = {
  min: string | number | null;
  max: string | number | null;
};

/**
 * Master elements type
 */
export type TMaster = {
  categories: TCategory[];
  countries: TCountry[];
};
