/*
 * Category location type
 */
export type TCLocation = {
  id: number;
  name: string;
  slug: string;
  count: number;
};

/*
 * Country type
 */
export type TCountry = {
  id: number;
  name: string;
  slug: string;
};

/*
 * Location autocomplete type
 */
export type TSuggestion = {
  id: number;
  parent_id: number;
  model_id: number;
  name: string;
  model: string;
  parent_name: string;
};

/*
 * Filter location type
 */
export type TFLocation = {
  country?: number | string;
  city?: number | string;
  state?: number | string;
  zone?: number | string;
};
