/*
 * Auto complete tag
 */

export type TTag = {
  model_id: number;
  name: string;
  model: string;
};

export type TTagRequest = {
  model_id: number;
  model: string;
};
