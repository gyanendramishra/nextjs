export type TTranslation = {
  language: string;
}
