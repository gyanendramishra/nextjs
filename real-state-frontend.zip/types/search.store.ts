/*
 * Category type
 */
export type TSSearch = {
  for: string;
};

export type TSearchAction = {
  FOR_FILTER_CHANGED: string;
  FILTER_CHANGE_FAILED: string;
};
