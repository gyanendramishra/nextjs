export type TPropertyAttribute = {
  builtUpArea: number;
  noOfBedrooms: number;
  noOfBathrooms: number;
  salePrice: number;
};

export type TPropertyFile = {
  mainImages: [];
};

export type TPropertyOwner = {
  phone: number;
  whatsApp: number;
  email: string;
  comapnyLogo: string;
};

export type TPropertyTranslation = {
  title: string;
  address: string;
  unitType: string;
  currencyType: string;
};

export type TProperty = {
  id: number;
  slug: string;
  attribute: TPropertyAttribute;
  propertyOwner: TPropertyOwner;
  propertyFiles: TPropertyFile;
  en: TPropertyTranslation;
  ar: TPropertyTranslation;
  externalUrl: string;
  externalVideoLink: string;
  isExclusive: boolean;
  isGreatPrice: boolean;
  isHighInvestmentReturn: boolean;
};

export type TPSource = {
  _id: number;
  _index: string;
  _score: number;
  _source: TProperty;
  _type: string;
};