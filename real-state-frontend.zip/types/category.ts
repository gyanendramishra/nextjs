/*
 * Category type
 */
export type TCategory = {
  id: number;
  name: string;
  slug: string;
}