module.exports = {
  locales: ['en', 'ar'],
  defaultLocale: 'ar',
  loadLocaleFrom: (lang, ns) =>
    import(`./public/locales/${lang}/${ns}.json`).then((m) => m.default),
  pages: {
    '*': ['common'],
    '/': ['home', 'search', 'property'],
    '/[slug]/search': ['search', 'property']
  },
}