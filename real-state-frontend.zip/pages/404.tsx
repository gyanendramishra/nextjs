import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";
/**
 * import page specific  compoents
 */
import Layout from "@/components/shared/layouts/layout";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction
}

const PageNotFound = ({ t } : Props) => {
  return (
      <Layout>
          <br /><br />
          <div className="alert alert-danger" role="alert">
              <h4 className="alert-heading">404!</h4>
              <p>{ t("MESSAGES.PAGE_NOT_FOUND") }</p>
          </div>
          <br />
      </Layout>
  );
};

PageNotFound.propTypes = {
    t: PropTypes.func.isRequired,
};

export default withTranslation("common")(PageNotFound);
