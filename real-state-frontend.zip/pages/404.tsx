import useTranslation from 'next-translate/useTranslation';
/**
 * import page specific  compoents
 */
import Layout from "@/components/shared/layouts/layout";


const PageNotFound = () => {
    const { t } = useTranslation();
    return (
        <Layout>
            <br /><br />
            <div className="alert alert-danger" role="alert">
                <h4 className="alert-heading">404!</h4>
                <p>{ t("MESSAGES.PAGE_NOT_FOUND") }</p>
            </div>
            <br />
        </Layout>
    );
};

export default PageNotFound;
