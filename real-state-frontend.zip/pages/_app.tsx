import App from "next/app";
import { wrapper } from "../stores";
import { appWithTranslation } from "../i18n";
import type { AppProps, AppContext } from "next/app";

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/icons.scss";
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';
import 'swiper/components/scrollbar/scrollbar.scss';
import "../styles/global/theme.scss";


function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}


MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

export default wrapper.withRedux(appWithTranslation(MyApp));
