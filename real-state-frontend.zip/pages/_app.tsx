import App from "next/app";
import { useEffect } from 'react'
import { wrapper } from "../stores";
import type { AppProps, AppContext } from "next/app";
import useTranslation from 'next-translate/useTranslation';
import appWithI18n from 'next-translate/appWithI18n';
import i18nConfig from '../i18n';

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/icons.scss";
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';
import 'swiper/components/scrollbar/scrollbar.scss';
import "../styles/global/theme.scss";


const  MyApp = ({ Component, pageProps }: AppProps) => {
  const { lang } = useTranslation();
    /**
     * Handle app lang
     * @return void
     */

    useEffect( () => {
        (async () => {
            const direction = (lang === "en") ? "ltr" : "rtl";
            setDirection(direction, lang );
        })();
    }, [lang]);

    /**
     * Set app dircetion and language
     * @return void
    */
    const setDirection = (direction: string, lang: string):void => {
        document.documentElement.dir = direction;
        document.documentElement.lang = lang;
    }

  return <Component {...pageProps} />;
}


MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

export default appWithI18n(wrapper.withRedux(MyApp), i18nConfig as any);
