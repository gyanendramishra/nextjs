import App from "next/app";
import { wrapper } from "../stores";
import { appWithTranslation } from "../i18n";
import type { AppProps, AppContext } from "next/app";

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/theme.scss";

function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}



MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

//export default appWithTranslation(MyApp);
export default wrapper.withRedux(appWithTranslation(MyApp));
