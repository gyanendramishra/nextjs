import App from "next/app";
import { useEffect } from 'react'
import { useRouter } from "next/router";
import { useTranslation } from 'react-i18next';
import { wrapper } from "../stores";
import type { AppProps, AppContext } from "next/app";
import '../i18n';

/**
  * App global css
*/
import "../styles/scss/bootstrap.scss";
import "../styles/global/icons.scss";
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';
import 'swiper/components/scrollbar/scrollbar.scss';
import "../styles/global/theme.scss";


const  MyApp = ({ Component, pageProps }: AppProps) => {
  const { i18n } = useTranslation();
  const { locale } = useRouter();
  /**
   * Handle app lang
   * @return void
   */

  useEffect( () => {
      (async () => {
          await i18n.changeLanguage(locale as string);
      })();
  }, [locale]);

  return <Component {...pageProps} />;
}


MyApp.getInitialProps = async (appContext: AppContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

export default wrapper.withRedux(MyApp);
