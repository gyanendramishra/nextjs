import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../i18n";
import { NextApiResponse } from 'next'
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";
/**
 * import page specific  compoents
 */
import Layout from "@/components/shared/layouts/layout";

interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction;
    statusCode: NextApiResponse | any;
}

const PageError = ({ statusCode, t }: Props) => {
    return (
        <Layout>
          <div className="alert alert-danger" role="alert">
            <h4 className="alert-heading">{ statusCode }</h4>
            <p>{ t("MESSAGES.INTERNAL_ERROR") }</p>
          </div>
        </Layout>
    );
};

PageError.getInitialProps = async (res: NextApiResponse, err: any) => {
    let statusCode = null
    if (res) {
        ({ statusCode } = res)
    } else if (err) {
        ({ statusCode } = err)
    }
    return {
        namespacesRequired: ['common'],
        statusCode,
    }
};

PageError.defaultProps = {
    statusCode: null,
};

PageError.propTypes = {
    statusCode: PropTypes.number,
    t: PropTypes.func.isRequired,
}

export default withTranslation('common')(PageError)