import React, { useState } from "react";
import { useRouter } from 'next/router';
import useTranslation from 'next-translate/useTranslation';
import { /*GetStaticProps, GetStaticPaths,*/ GetServerSideProps } from 'next';

/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import PropertyArea from "@/components/listing/property-area";
import SearchFilter from "@/components/listing/search-filter";
import PropertyListing from "@/components/listing/property-listing";

/**
 * Import utill, classes, types and etc
 */
import { TFilter, TPSource, TCLocation } from "types";
import { getFilteredProperties, getFilteredAreas } from "../../../services";
import {  EPropertyDisplayMode, EPagination, getFiltersFromParams, getRequestFromFilters } from "utils";

type TResult = {
    result:Array<TPSource>;
    total: number;
}

type TProps = {
    initialProperties: TResult;
    initialAreas: Array<TCLocation>;
    initialFilters: TFilter;
}
const  Index = (props: TProps) => {
    
    const { initialProperties, initialAreas, initialFilters } = props;
    const { lang } = useTranslation();
    const router = useRouter();

    // Set the states
    const [filters, setFilters] = useState<TFilter>(initialFilters);
    const [properties, setProperties] = useState<Array<TPSource>>(initialProperties.result);
    const [areas, setAreas] = useState<Array<TCLocation>>(initialAreas);
    const [totalResult, setTotalResult] = useState<number>(initialProperties.total);
    const [proprtyDisplayMode, setProprtyDisplayMode] = useState<string>(EPropertyDisplayMode.GRID);

    /**
     * Switch property display mode
     * @param displayMode: string
     * @return void
     */
    const switchPropertyDisplayMode = (displayMode: string):void => {
        setProprtyDisplayMode(displayMode);
    }

    /**
     * Handle Pagination
     * @param selectedItem: object
     * @return void
     */
    const handlePagination = async (selectedItem: { selected: number; }) => {
        try{
            let pageNumber = selectedItem.selected;
            let filtesWithPager = {...filters, from : pageNumber*EPagination.PER_PAGE_COUNT, to : EPagination.PER_PAGE_COUNT};
            const result  = await getFilteredProperties(filtesWithPager);
            if(result.status === true){
                setProperties(result.data.result);
                setTotalResult(result.data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Handle Sorting
     * @param selectedItem: object
     * @return void
     */
    const handleSorting = async (e: React.ChangeEvent<HTMLInputElement>) => {
        try{
            const sort = e.currentTarget.value;
            let filtesWithSort = {...filters, from : 0, to : EPagination.PER_PAGE_COUNT, sort:sort};
            const result  = await getFilteredProperties(filtesWithSort);
            if(result.status === true){
                setProperties(result.data.result);
                setTotalResult(result.data.total);
                setFilters((prevState) => {
                    prevState = filters;
                    return ({
                        ...prevState
                    });
                });
            }
        }catch(error){
            console.log(error);
        }
    }

    /**
     * Get the properties by locations
     * @param cityId:string | number
     * @return void
     */
    const handleLocationSearch = async (cityId:string | number):Promise<void> => {
        let locationFilters = {};
        locationFilters = { ...locationFilters,
            type: filters.type,
            category: filters.sub_type,
            city: cityId
        }
        await router.replace({
            pathname: '/[slug]/search',
            query: locationFilters,
        },{
            pathname: `/${filters.for}/search`,
            query: locationFilters,
        });
        router.reload();
    }

    /**
     * Get the properties by filters
     * @param filters: TFilter
     * @return void
     */
    const handleSearchAfterSubmit = async (filters: TFilter) => {
        const request = await getRequestFromFilters(filters);
        // replace the url
        await router.replace({
            pathname: '/[slug]/search',
            query: request
        }, {
            pathname: `/${filters.for}/search`,
            query: request
        });

        setFilters((prevFilter)=>{
            prevFilter = filters;
            return prevFilter;
        });
        
        // Get the properties
        try{
            const properties = await getFilteredProperties(request);
            setProperties(properties.data.result || []);
            setTotalResult(properties.data.total);
        }catch(error){
            console.log("Find properties failed", error);
        }
        // Get the areas
        try{
            const areas = await getFilteredAreas(lang, filters.for, filters.sub_type);
            setAreas(areas.data || []);
        }catch(error){
            console.log(error);
        }

    }
    /**
     * Render the page
     */
    return (
        <Layout>
            <SearchFilter
                initialFilters= { initialFilters }
                handleSearch = { handleSearchAfterSubmit }
            ></SearchFilter>
            <PropertyArea
                areas = { areas }
                handleLocationSearch = { handleLocationSearch }
            ></PropertyArea>
            <PropertyListing
                searchFor= { filters.for }
                totalResult = { totalResult }
                properties= { properties }
                proprtyDisplayMode= { proprtyDisplayMode }
                handlePagination= { handlePagination }
                handleSorting= { handleSorting}
                switchPropertyDisplayMode= { switchPropertyDisplayMode }
            ></PropertyListing>
        </Layout>
    );
}

/**
 * Get server side props
 */
export const getServerSideProps:GetServerSideProps  = async (context) => {

    const initialFilters = await getFiltersFromParams(context.params, context.query) as TFilter;
    const initialRequests = await getRequestFromFilters(initialFilters);
    try{
        if(context.params == null) throw new Error("Missing params");
        const properties = await getFilteredProperties(initialRequests);
        const areas = await getFilteredAreas(context.locale as string, context.params.slug, context.query.sub_type);
        return { 
            props: { 
                initialProperties: properties.data, 
                initialAreas:  areas.data,
                initialFilters: initialFilters
            } 
        }
    }catch(error){
        console.log(error);
    }
    return { 
        props: { 
            initialProperties:  {
                result: [],
                total: 0
            }, 
            initialAreas:  [],
            initialFilters: initialFilters  
        }
    } 
}

export default Index;
