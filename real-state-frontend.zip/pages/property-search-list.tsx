import React, { useEffect, useState } from "react";

import { useRouter } from "next/router";
import { useTranslation } from 'react-i18next';
import { Formik, Field, Form, FormikHelpers } from "formik";
import ReactPaginate from 'react-paginate';
/**
 * Import page components
 */

import Layout from "@/components/shared/layouts/layout";
import PropertyListItem from "@/components/property/item-list";
import PropertyGridItem from "@/components/property/item-grid";
import PropertyArea from "@/components/listing/property-area";
import PropertySortFilter from "@/components/listing/property-sort-filter";


/**
 * Import component types
 */
import { TTranslation, TCountry, TCategory } from "../types";

/**
 * Import component utils
 */
import { bedroomList, bathroomList,priceList, sizeList} from "../utils/search-constants";

/**
 * Import page components
 */

import Autocomplete from "@/components/search/autocomplete";
import MinMaxPicker from "@/components/search/min-max-picker";

/**
 * Component styles,styles1
 */

import styles from '../styles/listing/search-filter.module.scss';

import styles1 from '../styles/listing/property-listing-main.module.scss';

import styles3 from '../styles/listing/pagination.module.scss';


/**
 * Import component services
 */
import {propertyTypes, propertySearchList,getCityArea } from "../services";
/**
 * import types and queries
 */
import { Property } from '../classes/property';
import { TPSource } from '../types';




// interface States {
//     propertySubType: [];
//     propertyTypes: TMaster;
//     filter: TFilter;
//     types:string
//     searchList:any,
//     pageCount:number;
//     itemView:boolean;
//     forType:string;
//     cityAreaList:any;
// }

type TFilter = {
    propertyForId: string;
    propertyMainTypeId: string;
    propertySubTypeId: string | null;
    noOfBedrooms: number | null;
    noOfBathrooms: number | null;
    locations: [] | null;
    price: {min:string, max:string} | null;
    size: {min:string, max:string} | null;
    sortSearch:string;
    selectedPage:number;
    from:number;
    noOfPropertiesOnPage:number;
};

type array= [];


type TMaster = {
    categories: TCategory[];
    countries: TCountry[];
};
const PropertyPage=()=>{

    const { t } = useTranslation();
    const { locale } = useRouter();

    const [filters,setFilters] = useState<TFilter>({
                propertyForId: "3",
                propertyMainTypeId: "3",
                propertySubTypeId:null,
                noOfBedrooms: null,
                noOfBathrooms:  null,
                locations: [],
                price: {min: '',max: ''},
                size: {min:'', max:''},
                sortSearch:'relevence',
                selectedPage:1,
                from:1,
                noOfPropertiesOnPage:3,
        })
    
    const [propertySubType,setPropertySubType] = useState<array>([])
    const [searchList,setSearchList] = useState<array>([])
    const [cityAreaList,setCityAreaList] = useState<object>({})
    const [pageCount,setPageCount] = useState<number>(0)
    const [itemView,setItemView] = useState<boolean>(true)
    const [forType,setForType] = useState<number>(3)
    
           

    // const { t,i18n } = this.props;
    // const { filter, propertySubType, searchList,pageCount, itemView,forType, cityAreaList } = this.state;

    /**
     * Submit property type
     * @param types
     * @return response
     */

    const getPropertyTypes = async (types:string)=>{
        
        let  type = types=='3'?"residential":"commercial";
        const response = await propertyTypes(locale as string,type);
        
        if(response.status===true){
            const { data } = response.data;
            setPropertySubType(data);
        } 
    }

    /**
     * Submit search data
     * @param formData
     * @return response
     */

    const onHandleSubmit = async (formData:TFilter)=>{
        setSearchList(await propertySearchList(formData))
        if(searchList.status){
            let totalPage = searchList.data.hits.total.value/filters.noOfPropertiesOnPage;
            setPageCount(Math.round(totalPage))
        }
    }

    /**
     * Submit search data
     * @param formData
     * @return response
     */

    const sortSearch = async (sortSearch:string)=>{
        setFilters((prevState) => {
            prevState.sortSearch = sortSearch;
            return({
              ...prevState
            })
          }
        );
        console.log('filters sort',filters)
        setSearchList(await propertySearchList(filters))
    }
    const handlePageClick=(data:any) =>{  
        const {noOfPropertiesOnPage}=filters
        const from = (data.selected*noOfPropertiesOnPage);
        setFilters((prevState) => {
            prevState.from = from;
            return({
              ...prevState
            })
          }
        );
       
        let paginationData ={from:from, noOfPropertiesOnPage:noOfPropertiesOnPage}
        onHandleSubmit(paginationData)
    }

    /**
     * set list View and grid view 
     * @param itemView
     * @return response
     */

   const setView = (itemView:boolean)=>{
        setItemView(itemView);
    }

    /**
     * Get city area list
     * 
     * @return response
     */
    const setCityArea = async ()=>{
        let forType =filters.propertyForId=='3'?'areas-for-sale':'/v1/search-box/areas-for-rent'
        setCityAreaList(await getCityArea(locale as string,forType))
    }

    useEffect(() => {
        const {propertyMainTypeId, propertyForId} = filters;
        getPropertyTypes(propertyMainTypeId);
        let data = {propertyMainTypeId:propertyMainTypeId, propertyForId:propertyForId, from:filters.from, noOfPropertiesOnPage:filters.noOfPropertiesOnPage}
        onHandleSubmit(data)
        setCityArea();
    },[]);
    
   
    /**
     * Render the page
     */
        
    return (
        <Layout title={ t('common:APP_NAME') }>
            <div className={styles.search_filter_outer}> {/* Desktop Search Filter */}
            <div className={styles.search_filter}>
                <div className={styles.container}>
                <Formik
                    initialValues={
                        filters
                    }
                    onSubmit={
                        async (values: TFilter, {  }: FormikHelpers<TFilter>) => {
                            setForType(values.propertyForId)
                            await onHandleSubmit(values);
                        }
                    }
                    >
                    {() => (
                        <Form>
                            <div className={`${styles.adv_row} ${styles.mbl_row}`}>
                                <div className={styles.adv_col1}>
                                    <Field as="select" className={styles.form_control} name="propertyForId">
                                        <option value="3">{ t("SEARCH_FOR.FOR_SALE") }</option>
                                        <option value="4">{ t("SEARCH_FOR.FOR_RENT") }</option>
                                    </Field>
                                </div>
                                <div className={styles.adv_col1}>
                                    <select className={styles.form_control} name="propertyMainTypeId" onChange={(e)=>{this.getPropertyTypes(e.target.value )}} >
                                        <option value='3'>{ t("SEARCH_TYPE.RESIDENTIAL") }</option>
                                        <option value='1'>{ t("SEARCH_TYPE.COMMERCIAL") }</option>
                                    </select>
                                </div>
                                <div className={styles.adv_col1}>
                                    <Field as="select" className={styles.form_control} name="propertySubTypeId">
                                        <option value="">{ t("LABELS.PROPERTY_TYPE") }</option>
                                        {propertySubType && propertySubType.map((value:any, index) => {
                                            return (
                                                <option key={index} value={ value.id }>{ value.name }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.adv_col1}>
                                    <Field as="select" className={styles.form_control} name="noOfBedrooms">
                                        <option value="">{ t("LABELS.BEDS") }</option>
                                        { bedroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.adv_col1}>
                                    <Field as="select" className={styles.form_control} name="noOfBathrooms">
                                        <option value="">{ t("LABELS.BATHS") }</option>
                                        { bathroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.adv_col2}>
                                    <MinMaxPicker 
                                        name="price"
                                        label={ t("LABELS.PRICE") }
                                        options={ priceList }
                                        //styles={styles}
                                    ></MinMaxPicker>
                                
                                </div>
                            </div>
                            <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
                                <div className={styles.adv_col2}>
                                    <MinMaxPicker 
                                        name="size"
                                        label={ t("LABELS.SIZE") }
                                        options={ sizeList }
                                    //     styles={styles}
                                    ></MinMaxPicker>
                                </div>
                                <div className={styles.adv_col3}> 
                                    <Autocomplete name="locations" containerClass={styles.web_autocomplete}></Autocomplete>
                                </div>
                                
                                <div className={styles.adv_col4}>
                                    <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button> <a className={`${styles.cmn_button} ${styles.btn_filter}`}>Filter</a>
                                </div>
                            </div>
                        </Form>
                    )}
                </Formik>
                </div>
            </div> {/* Desktop Search Filter */} {/* Mobile Popup Search Filter */}
            <div className={styles.search_mobile_block_outer}>
                <div className={styles.search_category_nav}>
                    <ul className="d-flex">
                        <li><a className={styles.active}>For Sale</a></li>
                        <li><a>For Rent</a></li>
                        <li><a>International</a></li>
                    </ul>
                </div> {/* FOR SALE SECTION */}
                <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
                    <div className={styles.adv_col_full}> {/*
                        <Autocomplete3></Autocomplete3> */} </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Residential</option>
                            <option>Commercial</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Property Type</option>
                            <option>Apartment</option>
                            <option>Commercial</option>
                            <option>Land</option>
                            <option>Private Island</option>
                            <option>Villa / Townhouse</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Beds</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5+</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Baths</option>
                        </select>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Price</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Price</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Size</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Size</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.adv_col_full}>
                        <button type="submit" className={styles.mbl_find_btn}>Find</button>
                    </div>
                    <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                </div> {/* FOR RENT SECTION */}
                <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
                    <div className={styles.adv_col_full}> {/*
                        <Autocomplete3></Autocomplete3> */} </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Residential</option>
                            <option>Commercial</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Property Type</option>
                            <option>Apartment</option>
                            <option>Commercial</option>
                            <option>Land</option>
                            <option>Private Island</option>
                            <option>Villa / Townhouse</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Beds</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5+</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Baths</option>
                        </select>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Price</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Price</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Size</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Size</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.adv_col_full}>
                        <button type="submit" className={styles.mbl_find_btn}>Find</button>
                    </div>
                    <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                </div> {/* INTERNATIONAL SECTION */}
                <div className={`${styles.mobile_adv_filter} ${styles.dis_none}`}>
                    <div className={styles.adv_col_full}> {/*
                        <Autocomplete3></Autocomplete3> */} </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Residential</option>
                            <option>Commercial</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Property Type</option>
                            <option>Apartment</option>
                            <option>Commercial</option>
                            <option>Land</option>
                            <option>Private Island</option>
                            <option>Villa / Townhouse</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Beds</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5+</option>
                        </select>
                    </div>
                    <div className={styles.adv_col_full}>
                        <select className={styles.form_control}>
                            <option>Baths</option>
                        </select>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Price</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Price</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.min_max_outer}>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Min: Size</option>
                            </select>
                        </div>
                        <div className={styles.wd2}> <span>to</span> </div>
                        <div className={styles.wd1}>
                            <select className={styles.form_control}>
                                <option>Max: Size</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.adv_col_full}>
                        <button type="submit" className={styles.mbl_find_btn}>Find</button>
                    </div>
                    <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}> <a className={`${styles.right_link} ${styles.mobile_link}`}>Close</a> </div>
                </div>
            </div> {/* Mobile Popup Search Filter */} </div>
            <PropertyArea cityAreaList={cityAreaList}></PropertyArea>
            <PropertySortFilter forType={forType=='3'?'For Sale':'For Rent'} getView={setView} sortSearch={sortSearch} totalCount={searchList.status?searchList.data.hits.total.value:0}></PropertySortFilter>
            <div className={styles1.property_listing_main}>
                <div className={styles1.container}>
                    <div className="row">
                        <div className="col-md-8">
                        <div className={itemView?`${styles1.list_view} ${styles1.dis_block}`:`${styles1.grid_view} ${styles1.dis_block}`}>
                            <div className="row">
                                {searchList.status &&
                                    searchList.data.hits.hits.map((property:TPSource,  index:number)=>{
                                    const rProperty = new Property(property, locale);
                                    return (
                                        <div className={itemView?'col-md-12':'col-md-6'}>
                                            {itemView?
                                            <PropertyListItem
                                                key={index}
                                                property={rProperty}
                                            ></PropertyListItem>: 
                                            <PropertyGridItem
                                                key={index}
                                                property={rProperty}
                                            ></PropertyGridItem>
                                            }
                                        </div>
                                    )})
                                }
                            </div>
                            </div>
                            <div className={styles3.pagination_block}>
                            <ReactPaginate
                            previousLabel={'<'}
                            nextLabel={'>'}
                            breakLabel={'...'}
                            pageCount={pageCount}
                            marginPagesDisplayed={10}
                            pageRangeDisplayed={3}
                            onPageChange={handlePageClick}
                            breakClassName={'page-item'}
                            breakLinkClassName={'page-link'}
                            containerClassName={styles3.pagination}
                            pageClassName={'page-item'}
                            pageLinkClassName={'page-link'}
                            previousClassName={'page-item'}
                            previousLinkClassName={'page-link'}
                            nextClassName={'page-item'}
                            nextLinkClassName={'page-link'}
                            activeClassName={'active'}
                            initialPage={0}
                            />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className={styles1.ad_block1}>
                                <a href="#"><img src="/images/Add1.svg" alt=""/></a>
                            </div>
                            <div className={styles1.ad_block2}>
                                <a href="#"><img src="/images/Add2.svg" alt=""/></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* <PropertyListingMain></PropertyListingMain> */}
        </Layout>
    )
}

export default PropertyPage;
