import React from "react";


/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";

const  List = () => {

    /**
     * Render the page
     */
    return (
        <Layout>
            <h1 style={{ margin: 500}}>Hi</h1>
        </Layout>
    );
}



export default List;
