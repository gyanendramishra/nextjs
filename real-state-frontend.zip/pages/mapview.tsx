
import Layout from "@/components/shared/layouts/Layout";
import SearchFilter from "@/components/listing/SearchFilter";
import PropertyArea from "@/components/listing/PropertyArea";
import PropertyListingMap from "@/components/listing/PropertyListingMap";

const IndexPage = () => (
  <Layout title="Listing : Dar Al Arkan">
    <SearchFilter></SearchFilter>
    <PropertyArea></PropertyArea>
    <PropertyListingMap></PropertyListingMap>
  </Layout>
);

export default IndexPage;
