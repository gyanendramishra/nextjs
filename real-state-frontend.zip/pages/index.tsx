import React from "react";
import PropTypes from "prop-types";
import { TFunction } from 'next-i18next';
import { withTranslation } from "../i18n";
import { WithTranslation as ReactI18nextWithTranslation } from "react-i18next";

/**
 * Import page components
 */
import HomeLinks from "@/components/home/home-links";
import Layout from "@/components/shared/layouts/layout";
import SearchProperties from "@/components/home/search-properties";
import DownloadApp from "@/components/home/download-app";
import RecommendedPropertiesKSA from "@/components/home/recommended-properties-ksa";
import RecommendedPropertiesInternational from "@/components/home/recommended-properties-international";
  
interface Props extends ReactI18nextWithTranslation {
    readonly t: TFunction
}
class IndexPage extends React.Component<Props> {
    /**
     * Validate prop types
     */
    public static propTypes = {
        t: PropTypes.func.isRequired,
    };

    /**
     * Get initial props
     * @return response
     */
    static async getInitialProps() {
        return {
            namespacesRequired: ["common"],
        };
    }

    /**
     * Get the server side props
     * @return response
     */
    // static getServerSideProps = async () =>{
        
    //     return { props: { serverRendered: true } }
    // }

    /**
     * Render the page
     */
    render() {
        const { t } = this.props;
        return (
            <Layout title={ t('common:APP_NAME') }>
                {/* Search properties compoent */}
                <SearchProperties></SearchProperties>
                {/* Recommended properties In KSA compoent */}
                <RecommendedPropertiesKSA></RecommendedPropertiesKSA>
                {/* Recommended properties In Internationsl compoent */}
                <RecommendedPropertiesInternational></RecommendedPropertiesInternational>
                {/* Download APP compoent */}
                <DownloadApp></DownloadApp>
                {/* Home links component */}
                <HomeLinks></HomeLinks>
            </Layout>
        )
    }
}

export default withTranslation("common")(IndexPage);
