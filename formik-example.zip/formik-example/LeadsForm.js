  // Form is based on Formik
  // Data validation is based on Yup
  // Please, be familiar with article first:
  // https://hackernoon.com/react-form-validation-with-formik-and-yup-8b76bda62e10
  
  import React from "react";
  import { Formik, Form, Field } from "formik";
  import * as Yup from "yup";
  import { Input, Select, DatePickerField } from "custom-form-elements";
  import {
    AVAILABLE_LEAD_TYPES,
  } from "./LeadsUIHelpers";

  export function LeadsForm({
    lead,
    btnRef,
    saveLead,
    formRef
  }) {

    // Validation schema
    const FormSchema = Yup.object().shape({
      lead_type: Yup.string()
         .min(1, 'Please Select a Lead Type')
         .required('Lead Type is a required field'),
      email: Yup.string()
         .email('Invalid email'),
      first_name: Yup.string()
        .max(50, "Maximum 255 symbols")
        .required("First Name is required"),
      last_name: Yup.string()
        .max(50, "Maximum 255 symbols")
        .required("Last Name is required"),
      contact_no: Yup.string()
         .required("Contact Number is required"),
    });


  return (
      <>
        <Formik
          innerRef={formRef}
          enableReinitialize={true}
          initialValues={lead}
          validationSchema={FormSchema}
          onSubmit={(values,{ setStatus, setSubmitting,setFieldError }) => {
            saveLead(values,{ setStatus, setSubmitting,setFieldError });
          }}
        >
          {({ handleSubmit }) => (
            <>
              <Form className="form form-label-right">
                <div className="form-group row">
                    <Select name="lead_type" label="Lead Type" horizontal="true">
                        {AVAILABLE_LEAD_TYPES.map((group) => (
                          <option key={group.id} value={group.id}>
                            {group.name}
                          </option>
                        ))}
                    </Select>
                </div>
                <div className="form-group row">
                  <Field
                    name="first_name"
                    component={Input}
                    placeholder="First Name"
                    label="First Name"
                    type="text"
                    horizontal="true"
                  />
                </div>
                <div className="form-group row">
                  <Field
                    name="last_name"
                    component={Input}
                    placeholder="Last Name"
                    label="Last Name"
                    type="text"
                    horizontal="true"
                  />
                </div>
                <div className="form-group row">
                  <Field
                    name="company_name"
                    component={Input}
                    placeholder="Business Name"
                    label="Business Name"
                    type="text"
                    horizontal="true"
                  />
                </div>
                <div className="form-group row">
                  <Field
                    name="contact_no"
                    component={Input}
                    placeholder="Contact Number"
                    label="Contact Number"
                    type="text"
                    horizontal="true"
                  />
                </div>
                <div className="form-group row">
                  <Field
                    name="alternate_contact_no"
                    component={Input}
                    placeholder="Alt. Contact Number"
                    label="Alt. Contact Number"
                    type="text"
                    horizontal="true"
                  />
                </div>
                <div className="form-group row">
                  <Field
                    name="email"
                    component={Input}
                    placeholder="Email"
                    label="Email"
                    type="email"
                    horizontal="true"
                  />
                </div>
                <button
                  type="submit"
                  style={{ display: "none" }}
                  ref={btnRef}
                  onSubmit={() => handleSubmit()}
                ></button>
              </Form>
            </>
          )}
        </Formik>
      </>
    );
  }
