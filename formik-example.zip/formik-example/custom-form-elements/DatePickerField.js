import React from "react";
import {useField, useFormikContext} from "formik";
import DatePicker from "react-datepicker";
import moment from 'moment';

const getFieldCSSClasses = (touched, errors) => {
  const classes = ["form-control"];
  if (touched && errors) {
    classes.push("is-invalid");
  }

  if (touched && !errors) {
    classes.push("is-valid");
  }

  return classes.join(" ");
};

export function DatePickerField({ ...props }) {
  const { setFieldValue, errors, touched } = useFormikContext();
  const [field] = useField(props);
  return (
    <>
      {props.horizontal ?
        <div className="col-xl-3 col-lg-3 col-form-label">
          {props.label && <label> {props.label}</label>}
        </div>
        :
        <>{props.label && <label> {props.label}</label>}</>
      }
      {props.horizontal ?
        <div className="col-lg-9 col-xl-6">
        <DatePicker
          className={getFieldCSSClasses(touched[field.name], errors[field.name])}
          style={{ width: "100%" }}
          {...field}
          {...props}
          selected={(field.value && new Date(field.value)) || null}
          onChange={val => {
            setFieldValue(field.name, moment(val).format('MM/DD/YYYY'));
          }}
        />
        {errors[field.name] && touched[field.name] ? (
          <div className="invalid-datepicker-feedback">
            {errors[field.name].toString()}
          </div>
        ) : ('')}
        </div>
        :
        <>
        <DatePicker
          className={getFieldCSSClasses(touched[field.name], errors[field.name])}
          style={{ width: "100%" }}
          {...field}
          {...props}
          selected={(field.value && new Date(field.value)) || null}
          onChange={val => {
            setFieldValue(field.name, moment(val).format('MM/DD/YYYY'));
          }}
        />
        {errors[field.name] && touched[field.name] ? (
          <div className="invalid-datepicker-feedback">
            {errors[field.name].toString()}
          </div>
        ) : ('')}
        </>
      }
    </>
  );
}
