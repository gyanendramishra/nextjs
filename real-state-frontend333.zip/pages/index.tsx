import React from "react";
import { GetServerSideProps } from 'next';

/**
 * import clases, services types and utills
 */
import { TPSource, TMaster } from '../types';
import { getMainSearchElements, getRecommendedKSAProperties, getRecommendedInternationalProperties } from '../services';


/**
 * Import page components
 */
import Layout from "@/components/shared/layouts/layout";
import DownloadApp from "@/components/home/download-app";
import MainSearch from "@/components/home/main-search";
import HomeLinks from "@/components/home/home-links";
import RecommendedPropertiesKSA from "@/components/home/recommended-properties-ksa";
import RecommendedPropertiesInternational from "@/components/home/recommended-properties-international";


type TProps = {
    searchElements: TMaster;
    rKSAProperties: Array<TPSource>;
    rIProperties: Array<TPSource>;
};

const  Index = (props: TProps) => {
    const { searchElements, rKSAProperties, rIProperties } = props;

    /**
     * Render the page
     */
    return (
        <Layout>
            {/* Search properties compoent */}
            <MainSearch
                searchElements = {searchElements}
            ></MainSearch>
            {/* Recommended properties In KSA compoent */}
            <RecommendedPropertiesKSA
                properties= {rKSAProperties}
            ></RecommendedPropertiesKSA>
            {/* Recommended properties In Internationsl compoent */}
            <RecommendedPropertiesInternational
                properties= {rIProperties}
            ></RecommendedPropertiesInternational>
            {/* Download APP compoent */}
            <DownloadApp></DownloadApp>
            {/* Home links component */}
            <HomeLinks></HomeLinks>
        </Layout>
    );
}

/**
 * Get static props
 */
export const getServerSideProps:GetServerSideProps = async (ctx) => {
    try{
        const mainElements = await getMainSearchElements(ctx.locale as string);
        const ksaProperties = await getRecommendedKSAProperties();
        const internationalProperties = await getRecommendedInternationalProperties();
        return { 
            props: { 
                searchElements: mainElements.data, 
                rKSAProperties: ksaProperties.data, 
                rIProperties: internationalProperties.data
            } 
        }
    }catch(error){
        console.log(error); 
    }
    return { 
        props: { 
            searchElements:  [], 
            rKSAProperties:  [], 
            rIProperties:  []
        } 
    }
    
}


export default Index;
