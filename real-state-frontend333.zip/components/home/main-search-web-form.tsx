import React, {useState} from "react";
import { Field } from "formik";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import services, types and utils
 */

import { TFilter, TMaster } from "../../types";
import { EPropertyFor, EPropertyType } from "../../utils";
import { bedroomList, bathroomList, priceList, sizeList} from "../../utils/search-constants";

/**
 * Import page components
 */
import PropertyType from "@/components/search/property-type";
import MinMaxPicker from "@/components/search/min-max-picker";
import Autocomplete from "@/components/search/autocomplete";

type TProps = {
    styles: TStyle;
    masters: TMaster;
    filters: TFilter;
    handleTypeOnChange: Function;
};

type TStyle = {
    readonly [key: string]: string;
}

const MainSearchWebForm = (props:TProps) => {

    const {
        styles, 
        filters,
        masters,
        handleTypeOnChange
    } = props;
    const { t } = useTranslation();

    const [advanceSearch, setAdvanceSearch] = useState<boolean>(false);

    /**
     * Toggle advance search
     * @return void
     */
    const toggleAdvanceSearch = async (): Promise<void> => {
        if (advanceSearch === true) {
            setAdvanceSearch(false);
        } else {
            setAdvanceSearch(true);
        }
    };

    /**
     * Render the html
     * @return void
     */
    return (
        <>
            <div className={(filters.for === EPropertyFor.INTERNATIONL) ? styles.search_inner+" "+styles.international_col: styles.search_inner}>
                <div className={styles.select_block}>
                    <Field
                        as="select"
                        name="type"
                        className={styles.form_control}
                        onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                    >
                        <option value={EPropertyType.RESIDENTIAL}>
                            {t("search:SEARCH_TYPE.RESIDENTIAL")}
                        </option>
                        <option value={ EPropertyType.COMMERCIAL }>
                            {t("search:SEARCH_TYPE.COMMERCIAL")}
                        </option>
                    </Field>
                </div>
                {(filters.for === EPropertyFor.INTERNATIONL) && (
                    <div className={`${styles.select_block} ${styles.country_col}`}>
                        <Field
                            as="select"
                            name="country"
                            className={styles.form_control}
                        >
                            <option value="">{t("search:LABELS.COUNTRY")}</option>
                            {masters.countries.map((country, index: number) => {
                                return (
                                    <option value={country.id} key={index}>
                                        {country.name}
                                    </option>
                                );
                            })}
                        </Field>
                    </div>
                )}
                <div className={styles.search_field}>
                    {/* Auto complete */}
                    <Autocomplete 
                        name="locations"
                    ></Autocomplete>         
                </div>
                <div className={styles.search_btn}>
                    <button type="submit" className={styles.find_btn}>
                        {t("search:LABELS.FIND")}
                    </button>
                </div>
            </div>
            <div className={styles.srch1}>
                { (advanceSearch === true) && (
                    <div className={styles.adv_block}>
                        <div className={styles.adv_row}>
                            <div className={styles.adv_col1}>
                                <PropertyType
                                    name="sub_type"
                                    lable = { t("search:LABELS.PROPERTY_TYPE")}
                                    category = { filters.type }
                                    styles = { styles }
                                ></PropertyType>
                            </div>
                            <div className={styles.adv_col1}>
                                <Field 
                                    as="select" 
                                    className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                    name="bedrooms" 
                                >
                                    <option value="">{ t("search:LABELS.BEDS") }</option>
                                    { bedroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </Field>
                            </div>
                            <div className={styles.adv_col1}>
                                <Field 
                                    as="select" 
                                    className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                    name="bathrooms" 
                                >
                                    <option value="">{ t("search:LABELS.BATHS") }</option>
                                    { bathroomList.map((option, index) => {
                                        return (
                                            <option key={index} value={ option }>{ option }</option>
                                        );
                                    })}
                                </Field>
                            </div>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker 
                                    name="price"
                                    label={ t("search:LABELS.PRICE") }
                                    options={ priceList }
                                ></MinMaxPicker>
                            </div>
                            <div className={styles.adv_col2}>
                                <MinMaxPicker
                                    name="size"
                                    label={ t("search:LABELS.SIZE") }
                                    options={ sizeList }
                                ></MinMaxPicker>
                            </div>
                        </div>
                    </div>
                )}
                <div className={styles.srch1_inr}>
                    <a className={styles.left_link} href="#">
                        <i className="icon-pin"></i> { t("search:LABELS.SEARCH_ON_MAP") }
                    </a>
                    <a className={`${styles.right_link} ${styles.desktop_link}`} onClick={()=> toggleAdvanceSearch()}>
                        <i className="icon-levels"></i>{advanceSearch ? t("search:LABELS.CLOSE_ADVANCED_SEARCH") : t("search:LABELS.ADVANCED_SEARCH")}
                    </a>
                </div>
            </div>
        </>
    );
}

export default MainSearchWebForm;

