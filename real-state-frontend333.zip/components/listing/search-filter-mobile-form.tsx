import React from "react";
import { Field, } from "formik";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import components
 */

import PropertyType from "@/components/search/property-type";
import Autocomplete from "@/components/search/autocomplete";

/**
 * Import utill, classes, types and etc
 */
import { TFilter } from "../../types";
import { bedroomList, bathroomList, priceList, sizeList, EPropertyFor, EPropertyType } from "../../utils";

/**
 * Import styles
 */
import styles from '../../styles/listing/search-filter.module.scss';

type TProps = {
    filters:TFilter;
    styles: TStyle;
    advancesearch: boolean;
    toggleAdvanceSearch: Function;
    changePropertyFor: Function
    handleTypeOnChange: Function;
}

type TStyle = {
    readonly [key: string]: string;
}

const SearchFilterMobileForm = (props: TProps) => {
    const { t } = useTranslation();
    const { filters, advancesearch, toggleAdvanceSearch, handleTypeOnChange, changePropertyFor } = props;

    return (
        <>
            <div className={styles.search_filter_outer}>
                <div className={styles.search_filter}>
                    <div className={styles.container}>
                        <div className={`${styles.adv_row} ${styles.mbl_row2}`}>
                            <div className={styles.mobile_residential_dropdown}>
                                <select className={styles.form_control}>
                                    <option>Residential</option>
                                    <option>Commercial</option>
                                </select>
                            </div>
                            <div className={styles.adv_col3}>
                                <Autocomplete 
                                    name="locations"
                                ></Autocomplete>
                            </div>
                            <div className={styles.adv_col4}>
                                <button type="submit" className={`${styles.cmn_button} ${styles.btn_full}`}>Find</button>
                            </div>
                        </div>
                        <div className={styles.mobile_adv_filter_btn}>
                            <a className={styles.mobile_link} onClick={ ()=> toggleAdvanceSearch() }><i className="icon-levels"></i> Advanced Search</a>
                        </div>
                    </div>
                    <div className={(advancesearch === true) ? styles.open_advance : ''}>                        
                        <div className={styles.search_mobile_block_outer}>
                            <div className={styles.search_category_nav}>
                                <ul className="d-flex">
                                    <li>
                                        <a
                                            className={ filters.for === EPropertyFor.SALE ? styles.active : "" }
                                            onClick={() => changePropertyFor(EPropertyFor.SALE)}
                                        >
                                            {t("search:SEARCH_FOR.FOR_SALE")}
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            className={ filters.for === EPropertyFor.RENT ? styles.active : "" }
                                            onClick={() => changePropertyFor(EPropertyFor.RENT)}
                                        >
                                            {t("search:SEARCH_FOR.FOR_RENT")}
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div className={`${styles.mobile_adv_filter} ${styles.dis_block}`}>
                                <div className={styles.adv_col_full}>
                                    <Autocomplete 
                                        name="locations"
                                    ></Autocomplete>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field
                                        as="select"
                                        name="type"
                                        className={styles.form_control}
                                        onChange={ (event: React.ChangeEvent<HTMLInputElement>)=>handleTypeOnChange(event) }
                                    >
                                        <option value={EPropertyType.RESIDENTIAL}>
                                            {t("search:SEARCH_TYPE.RESIDENTIAL")}
                                        </option>
                                        <option value={ EPropertyType.COMMERCIAL }>
                                            {t("search:SEARCH_TYPE.COMMERCIAL")}
                                        </option>
                                    </Field>
                                </div>
                                {(filters.for === EPropertyFor.INTERNATIONL) && (
                                    <div className={`${styles.adv_col_full} ${styles.country_col}`}>
                                        <Field
                                            as="select"
                                            name="country"
                                            className={styles.form_control}
                                        >
                                            <option>country1</option>
                                            <option>country2</option>
                                        </Field>
                                    </div>
                                )}
                                <div className={styles.adv_col_full}>
                                    <PropertyType
                                        name="sub_type"
                                        lable = { t("search:LABELS.PROPERTY_TYPE")}
                                        category = { filters.type }
                                        styles = { styles }
                                    ></PropertyType>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field 
                                        as="select" 
                                        className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                        name="bedrooms" 
                                    >
                                        <option value="">{ t("search:LABELS.BEDS") }</option>
                                        { bedroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <Field 
                                        as="select" 
                                        className={`${styles.form_control} ${(filters.type === EPropertyType.COMMERCIAL) ? 'disabled' : ''}`} 
                                        name="bathrooms" 
                                    >
                                        <option value="">{ t("search:LABELS.BATHS") }</option>
                                        { bathroomList.map((option, index) => {
                                            return (
                                                <option key={index} value={ option }>{ option }</option>
                                            );
                                        })}
                                    </Field>
                                </div>
                                <div className={styles.min_max_outer}>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="price[min]" className={styles.form_control}>
                                            { priceList.min.map((minPrice, index) => {
                                                return (
                                                    <option key={index} value={minPrice}>{ minPrice }</option>
                                                )
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.wd2}>
                                        <span>to</span>
                                    </div>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="price[max]" className={styles.form_control}>
                                            { priceList.max.map((maxPrice, index) => {
                                                return (
                                                    <option key={index} value={maxPrice}>{ maxPrice }</option>
                                                )
                                            })}
                                        </Field>
                                    </div>
                                </div>
                                <div className={styles.min_max_outer}>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="size[min]" className={styles.form_control}>
                                            { sizeList.min.map((minSize, index) => {
                                                return (
                                                    <option key={index} value={minSize}>{ minSize }</option>
                                                )
                                            })}
                                        </Field>
                                    </div>
                                    <div className={styles.wd2}>
                                        <span>to</span>
                                    </div>
                                    <div className={styles.wd1}>
                                        <Field as="select" name="size[max]" className={styles.form_control}>
                                            { sizeList.max.map((maxSize, index) => {
                                                return (
                                                    <option key={index} value={ maxSize }>{ maxSize }</option>
                                                )
                                            })}
                                        </Field>
                                    </div>
                                </div>
                                <div className={styles.adv_col_full}>
                                    <button type="submit" className={styles.mbl_find_btn}>Find</button>
                                </div>
                                <div className={`${styles.close_adv_btn} ${styles.adv_col_full}`}>
                                    <a className={`${styles.right_link} ${styles.mobile_link}`} onClick={ ()=> toggleAdvanceSearch() }>Close</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default SearchFilterMobileForm;
