import React, { useState } from "react";
import useTranslation from 'next-translate/useTranslation';

/**
 * Import utill, classes, types and etc
 */
import { ENumbers } from "utils";
import { TCLocation } from "types";

/**
 * Import styles
 */
import styles from '../../styles/listing/property-area.module.scss';


type TProps = {
  areas:Array<TCLocation>;
  handleLocationSearch: Function;
}

const PropertyArea = (props: TProps) => {
    const { areas, handleLocationSearch } = props;
    const { t } = useTranslation();

    const [showMore, setShowMore] = useState<boolean>(false);

     /**
     * Toggle area to display less or more
     * @return void
     */
    const toggleLessNMore = ():void =>{
        if(showMore === true){
            setShowMore(false);
        }else{
            setShowMore(true);
        }
    }
    /**
     * Render the html
     */
    return (
        <>
            {areas && (areas.length > 0) && (
                <div className={styles.property_area}>
                    <div className={styles.container}>
                        <div className={styles.area_inr}>
                            <ul className={ (showMore === true) ? styles.height_auto : '' }>
                                { areas.map((area, index)=>{
                                    return (
                                        <li key={index}>
                                            <a href="javascript:;" onClick={()=> handleLocationSearch(area.id)}>{ area.name }</a>
                                        </li>
                                    )}
                                )}
                            </ul>
                            { (areas.length > ENumbers.FIVE) &&
                                <div className={styles.area_rt_btn}>
                                    <a href="javascript:;" onClick={ toggleLessNMore }>
                                        { (showMore === true) ? t("search:LABELS.VIEW_LESS") : t("search:LABELS.VIEW_ALL") } <img src="/images/arrow2.svg" style={((showMore === true)) ? {transform: "rotate(180deg)"} : {}} alt=""/>
                                    </a>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            )}
        </>
     );
}

export default PropertyArea;
