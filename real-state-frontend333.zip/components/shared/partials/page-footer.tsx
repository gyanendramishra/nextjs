import React from "react";
import useTranslation from 'next-translate/useTranslation';

/**
 * component styles
 */
import styles from '../../../styles/shared/footer.module.scss';

const  PageFooter = () => {

    const { t } = useTranslation();
    
    return (
        <footer className={styles.footer}>
            <div className={styles.container}>
                <div className={styles.ftr_btm}>
                    <div className={styles.ftr_lt}>
                        <div className={styles.ftr_btm_nav}>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.ABOUT") }. </a>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.TERMS_AND_CONDITIONS") }. </a>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.PRIVACY_POLICY") }. </a>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.CUSTOMER_LOGIN") }. </a>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.CAREERS") }.</a>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.COMPANY_REGISTRATION") }. </a>
                        </div>
                        <div className={styles.ftr_btm_nav2}>
                            <a href="#">{ t("common:FOOTER_NAVIGATIONS.TERMS") }</a> | <a href="#">{ t("common:FOOTER_NAVIGATIONS.PRIVACY_POLICY") }</a>
                        </div>
                    </div>
                    <div className={styles.ftr_rt}>
                        <a className={styles.wd1} href="#">
                            <img src="/images/app-store.svg" alt=""/>
                        </a>
                        <a className={styles.wd2} href="#">
                            <img src="/images/google-pay.svg" alt=""/>
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export default PageFooter;
