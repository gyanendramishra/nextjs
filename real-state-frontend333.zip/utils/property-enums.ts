export enum EPropertyFor {
  "SALE" = "buy",
  "RENT" = "lease",
  "INTERNATIONL" = "international",
}

export enum EPropertyType {
  "COMMERCIAL" = "commercial",
  "RESIDENTIAL" = "residential",
}

export enum EPropertyFlag {
  "FEATURED" = "featured",
  "EXCLUSIVE" = "exclusive",
  "GREAT_PRICE" = "greate_price",
  "HIGH_INVESTMENT_RETURN" = "high_investment_return",
}

export enum EPropertyFlagColumn {
  "HIGH_INVESTMENT_RETURN" = "is_high_investment_return",
  "GREAT_PRICE" = "is_great_price",
  "FEATURED" = "is_featured",
  "EXCLUSIVE" = "is_exclusive",
}

export enum EPropertyDisplayMode {
  "LIST" = "LIST",
  "GRID" = "GRID",
}

export enum EPropertyForValue {
  "SALE" = 3,
  "RENT" = 4,
}

export enum EPropertyTypeValue {
  "COMMERCIAL" = 1,
  "RESIDENTIAL" = 3,
}

export enum EPropertyRegion {
  "KSA" = "ksa",
  "INTERNATIONAL" = "international",
}

export enum EPropertyRegionValue {
  "KSA" = 56,
  "INTERNATIONAL" = 57,
}

export enum EPagination {
  "PER_PAGE_COUNT" = 6,
  "PAGINATION_LINK_COUNT" = 5,
  "INITIAL_PAGE" = 0,
}

export enum EPropertySort {
  "DATE_DESC" = "date_dec",
  "RELEVENCE" = "relevence",
  "EXCLUSIVE" = "exclusive",
  "PRICE_HIGH_TO_LOW" = "price_high_to_low",
  "PRICE_LOW_TO_HIGH" = "price_low_to_high",
}

export enum EZero {
  "ZERO" = 0,
}

export enum ENumbers {
  "ZERO" = 0,
  "ONE" = 1,
  "TWO" = 2,
  "THREE" = 3,
  "FOUR" = 4,
  "FIVE" = 5,
  "SIX" = 6,
  "SEVEN" = 7,
  "EIGHT" = 8,
  "NINE" = 9,
  "TEN" = 10,
}
